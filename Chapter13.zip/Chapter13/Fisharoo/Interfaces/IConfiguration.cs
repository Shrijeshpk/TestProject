
using System;
namespace Fisharoo.Interfaces
{
    public interface IConfiguration
    {
        string SiteName { get; }
        string RootURL { get; }
        bool ReCaptcha { get; }
        
        //CHAPTER 10
        int NumberOfRecordsInPage { get; }
        
        //CHAPTER 11
        int NumberOfTagsInCloud { get; }
        string CloudSortOrder { get; }
        int TagCloudSmallestFontSize { get; }
        int TagCloudLargestFontSize { get; }

        //CHAPTER 12
        string AdminSiteURL { get; }
    }
}