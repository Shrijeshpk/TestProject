//CHAPTER 13. Moved this Interface from DataAccess project to Interfaces project to conform with architecture layering strategy
using System;
using System.Web;
using System.Collections.Generic;
namespace Fisharoo.Interfaces
{
    public interface IWebContext
    {
        void ClearSession();
        bool ContainsInSession(string key);
        void RemoveFromSession(string key);
        
        //CHAPTER 3
        bool LoggedIn { get; set; }
        string Username { get; set; }
        //CHAPTER 13
        object CurrentUser { get; set; }
        string CaptchaImageText { get; set; }
        string UsernameToVerify { get; }
        
        //CHAPTER 4
        Int32 AccountID { get; }
        bool ShowGravatar { get; }
        string RootUrl { get; }

        //CHAPTER 5
        string FriendshipRequest { get; }
        string SearchText { get; }
        Int32 AccoundIdToInvite { get; }

        //CHAPTER 6
        Int32 MessageID { get; }
        Int32 FolderID { get; }
        Int32 Page { get; }

        //CHAPTER 7
        string FilePath { get; }
        string FilePathToPhotos { get; }
        string FilePathToVideos { get; }
        string FilePathToAudios { get; }
        Int64 AlbumID { get; }
        Int32 FileTypeID { get; }

        //CHAPTER 8
        Int64 BlogID { get; }

        //CHAPTER 9
        Int32 ForumID { get; }
        Int64 PostID { get; }
        bool IsThread { get; }
        string CategoryName { get; }
        string ForumName { get; }

        //CHAPTER 10
        bool NewGroup { get; }
        Int32 GroupID { get; }
        HttpFileCollection Files { get; }
        Int32 PageNumber { get; }

        //CHAPTER 11
        void ClearSelectedRatings();
        Dictionary<int, int> SelectedRatings { get; set; }
    }
}