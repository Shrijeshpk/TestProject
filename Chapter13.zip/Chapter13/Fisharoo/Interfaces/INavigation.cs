using System.Collections.Generic;
using System.Web;

namespace Fisharoo.Interfaces
{
    public interface INavigation
    {
        SiteMapNode CurrentNode { get; }
        SiteMapNode RootNode { get; }
        List<SiteMapNode> PrimaryNodes();
        //Chapter 4
        List<SiteMapNode> SecondaryNodes();

        List<SiteMapNode> FooterNodes();
        void CheckAccessForCurrentNode();
        List<SiteMapNode> AllNodes();
    }
}