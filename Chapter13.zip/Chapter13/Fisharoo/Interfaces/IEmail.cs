

using System.Collections.Generic;
namespace Fisharoo.Interfaces
{
    public interface IEmail
    {
        void SendEmail(string From, string Subject, string Message);
        void SendEmail(string To, string CC, string BCC, string Subject, string Message);
        void SendEmail(string[] To, string[] CC, string[] BCC, string Subject, string Message);
        void SendIndividualEmailsPerRecipient(string[] To, string Subject, string Message);

        //Chapter 3
        void SendEmailAddressVerificationEmail(string Username, string To);
        void SendPasswordReminderEmail(string To, string EncryptedPassword, string Username);

        //CHAPTER 5
        void SendFriendInvitation(string toEmail, string fromFirstName, string fromLastName, string GUID, string Message);
        List<string> ParseEmailsFromText(string text);
        string SendInvitations(int accID, string FirstName, string LastName, string ToEmailArray, string Message);

        //CHAPTER 6
        void SendNewMessageNotification(string FirstName, string LastName, string ToEmail);
    }
}