//CHAPTER 13. Moved this Interface from DataAccess project to Interfaces project to conform with architecture layering strategy
namespace Fisharoo.Interfaces
{
    //CHAPTER 3
public interface IUserSession
    {
        bool LoggedIn { get; set; }
        string Username { get; set; }
        //CHAPTER 13
        object CurrentUser { get; set; }
    }
}