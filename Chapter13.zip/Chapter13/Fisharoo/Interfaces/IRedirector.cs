using System;

namespace Fisharoo.Interfaces
{
    public interface IRedirector
    {
        void GoToHomePage();
        void GoToErrorPage();

        //CHAPTER 3
        void GoToAccountLoginPage();
        void GoToAccountRegisterPage();
        void GoToAccountEditAccountPage();
        void GoToAccountRecoverPasswordPage();
        void GoToAccountAccessDenied();

        //CHAPTER 4
        void GoToProfilesProfile();
        void GoToProfilesDefault();
        void GoToProfilesManageProfile();

        //CHAPTER 5
        void GoToFriendsInviteFriends(Int32 AccountIdToInvite);
        void GoToProfilesStatusUpdates();
        void GoToProfilesStatusUpdates(Int32 AccountID);
        void GoToSearch(string SearchText);
        void GoToAccountLoginPage(string FriendInvitationKey);
        void GoToAccountRegisterPage(string FriendInvitationKey);

        //CHAPTER 6
        void GoToMailNewMessage(Int32 MessageID);

        //CHAPTER 7
        void GoToPhotosMyPhotos();
        void GoToPhotosAddPhotos(Int64 AlbumID);
        void GoToPhotos();
        void GoToPhotosViewAlbum(Int64 AlbumID);
        void GoToPhotosEditPhotos(Int64 AlbumID);
        void GoToPhotosEditAlbum(Int64 AlbumID);

        //CHAPTER 8
        void GoToBlogsPostEdit(Int64 BlogID);

        //CHAPTER 9
        void GoToForumDefaultView();
        void GoToForumsForumView(string ForumPageName, string CategoryPageName);
        void GoToForumsViewPost(string path);

        //CHAPTER 10
        void GoToGroupsManageGroup(int GroupID);
        void GoToGroupsMembers(int GroupID, int PageNumber);
        void GoToGroupsViewGroup(int GroupID);
        void GoToGroupsMembers(int GroupID);
        void GoToGroupsViewGroup(string GroupPageName);

    }
}