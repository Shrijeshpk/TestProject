﻿
using System;
using System.Collections.Generic;
using System.Net.Mail;
using Fisharoo.Entities;

namespace Fisharoo.Common
{
    public static class Extensions
    {
        public static string Encrypt(this string s, string key)
        {
            //use lower case name
            return Cryptography.Encrypt(s, key.ToLower());
        }

        public static string Decrypt(this string s, string key)
        {
            //use lower case name
            return Cryptography.Decrypt(s, key.ToLower());
        }

        //CHAPTER 4
        public static string ToMD5Hash(this string s)
        {
            return Cryptography.CreateMD5Hash(s);
        }

        //CHAPTER 11
        //http://www.experts-exchange.com/Programming/Languages/C_Sharp/Q_22571864.html
        public static List<Tag> ShuffleList(this List<Tag> listToShuffle)
        {
            Random randomClass = new Random();

            for (int k = listToShuffle.Count - 1; k > 1; --k)
            {
                int randIndx = randomClass.Next(k); //
                Tag temp = listToShuffle[k];
                listToShuffle[k] = listToShuffle[randIndx]; // move random num to end of list.
                listToShuffle[randIndx] = temp;
            }
            return listToShuffle;
        }

        //CHAPTER 13
        //TODO:Atul.Suds. Common calling into Business class. Too late, but should extension class really be here in this project?
        /*
        public static string Serialize(this MailMessage MailMessage)
        {
            string result = MailMessageService.Serialize(MailMessage);
            return result;
        }

        //CHAPTER 13
        public static string SerializeEncrypted(this MailMessage MailMessage)
        {
            string result = MailMessageService.SerializeEncrypted(MailMessage);
            return result;
        }

        //CHAPTER 13
        public static MailMessage DeserializeEncrypted(this string SerializedAndEncryptedMailMessage)
        {
            MailMessage result = MailMessageService.DeserializeEncrypted(SerializedAndEncryptedMailMessage);
            return result;
        }

        //CHAPTER 13
        public static MailMessage Deserialize(this string SerializedMailMessage)
        {
            MailMessage result = MailMessageService.Deserialize(SerializedMailMessage);
            return result;
        }
        */
    }
}
