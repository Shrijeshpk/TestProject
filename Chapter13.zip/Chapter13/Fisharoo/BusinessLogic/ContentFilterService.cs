﻿using System.Collections.Generic;
using System.Text;
using System.Web;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Common;
using Fisharoo.DataAccess;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    //CHAPTER 12
    [Export(typeof(IContentFilterService))]
    public class ContentFilterService : IContentFilterService
    {
        [Import]
        private IContentFilterRepository _contentFilterRepository;
        
        public ContentFilterService()
        {
            MEFManager.Compose(this);    
        }

        public string Filter(string StringToFilter)
        {
            List<ContentFilter> _contentFilters = _contentFilterRepository.GetContentFilters();

            StringBuilder sb = new StringBuilder(StringToFilter);

            //encode the final output for further security
            sb = new StringBuilder(HttpUtility.HtmlEncode(sb.ToString()));

            //replace all the dirty words and forbidden tags
            foreach (ContentFilter cf in _contentFilters)
            {
                sb.Replace(cf.StringToFilter, cf.ReplaceWith);
            }

            return sb.ToString();
        }
    }
}
