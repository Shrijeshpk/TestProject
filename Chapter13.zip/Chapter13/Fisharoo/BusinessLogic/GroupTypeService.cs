﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Common;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    [Export(typeof(IGroupTypeService))]
    class GroupTypeService : IGroupTypeService
    {
        [Import]
        private IGroupTypeRepository _groupTypeRepository;

        public GroupTypeService()
        {
            MEFManager.Compose(this);
        }

        public List<GroupType> GetAllGroupTypes()
        {
            return _groupTypeRepository.GetAllGroupTypes();
        }

        public List<GroupType> GetGroupTypesByGroupID(int GroupID)
        {
            return _groupTypeRepository.GetGroupTypesByGroupID(GroupID);
        }
    }
}
