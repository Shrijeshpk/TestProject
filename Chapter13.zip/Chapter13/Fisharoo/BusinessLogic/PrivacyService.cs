﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.DataAccess;
using Fisharoo.Common;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    //CHAPTER 4
    [Export(typeof(IPrivacyService))]
    public class PrivacyService : IPrivacyService
    {
        [Import]
        private IFriendService _friendService;
        [Import]
        private IPrivacyRepository _privacyRepository;

        public PrivacyService()
        {
            MEFManager.Compose(this);
        }

        public List<PrivacyFlagType> GetPrivacyFlagTypes()
        {
            return _privacyRepository.GetPrivacyFlagTypes();
        }

        public List<VisibilityLevel> GetVisibilityLevels()
        {
            return _privacyRepository.GetVisibilityLevels();
        }

        public List<PrivacyFlag> GetPrivacyFlagsByProfileID(int ProfileID)
        {
            return _privacyRepository.GetPrivacyFlagsByProfileID(ProfileID);
        }

        public void SavePrivacyFlag(PrivacyFlag privacyFlag)
        {
            _privacyRepository.SavePrivacyFlag(privacyFlag);
        }

        public bool ShouldShow(Int32 PrivacyFlagTypeID, 
                               Account AccountBeingViewed, 
                               Account Account, 
                               List<PrivacyFlag> Flags)
        {
            bool result = false;
            bool isFriend = _friendService.IsFriend(Account, AccountBeingViewed);

            //flag marked as private test
            if (Flags.Where(f => f.PrivacyFlagTypeID == PrivacyFlagTypeID && f.VisibilityLevelID == (int)VisibilityLevel.VisibilityLevels.Private).FirstOrDefault() != null)
                result = false;
            //flag marked as friends only test
            else if (Flags.Where(f => f.PrivacyFlagTypeID == PrivacyFlagTypeID && f.VisibilityLevelID == (int)VisibilityLevel.VisibilityLevels.Friends).FirstOrDefault() != null && isFriend)
                result = true;
            else if (Flags.Where(f => f.PrivacyFlagTypeID == PrivacyFlagTypeID && f.VisibilityLevelID == (int)VisibilityLevel.VisibilityLevels.Public).FirstOrDefault() != null)
                result = true;
            else
                result = false;
            return result;
        }
    }
}
