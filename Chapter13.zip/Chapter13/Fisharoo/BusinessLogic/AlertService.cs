﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using Fisharoo.Common;
using Fisharoo.DataAccess;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Interfaces;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    [Export(typeof(IAlertService))]
    public class AlertService : IAlertService
    {
        [Import]
        private IUserSession _userSession;
        [Import]
        private IAlertRepository _alertRepository;
        [Import]
        private IWebContext _webContext;
        //CHAPTER 5
        [Import]
        private IFriendRepository _friendRepository;
        //CHAPTER 5
        [Import]
        private IConfiguration _configuration;
        //CHAPTER 10
        [Import]
        private IGroupRepository _groupRepository;
        [Import]
        private IGroupMemberRepository _groupMemberRepository;

        private Account account;
        private Alert alert;
        private string alertMessage;
        private string[] tags = { "[rootUrl]" };
        public AlertService()
        {
            MEFManager.Compose(this);
        }

        private void Init()
        {
            account = _userSession.CurrentUser as Account;
            alert = new Alert();
            alert.AccountID = account.AccountID;
            alert.CreateDate = DateTime.Now;
        }

        //CHAPTER 13
        public void DeleteAlerts(List<int> alertIDs)
        {
            _alertRepository.DeleteAlerts(alertIDs);
        }

        //CHAPTER 10
        public void AddGroupMembershipRequestAlert(int accID, int grpID, string userName)
        {
            Init();
            Group group = _groupRepository.GetGroupByID(grpID);
            alert.AlertTypeID = (int)AlertType.AlertTypes.MembershipRequest;
            alertMessage = "<div class=\"AlertHeader\">" + GetProfileImage(accID) +
                           GetProfileUrl(userName) + " has requested membership to group <b>" +
                           group.Name + "</b></div>";
            
            alertMessage += "<div class=\"AlertRow\">Click this link to approve the request: ";
            alertMessage += "<a href=\"" + _configuration.RootURL +
                            "Groups/Members.aspx?GroupID=" + grpID + "\">" + _configuration.RootURL +
                            "Groups/Members.aspx?GroupID=" + grpID + "</a></div>";

            alert.Message = alertMessage;
            //alert is to be saved to the group owner's ID
            alert.AccountID = group.AccountID;
            SaveAlert(alert);
        }

        //CHAPTER 10
        public void AddGroupMembershipApprovedAlert(List<int> MemberIDs, int grpID)
        {
            
            Group group = _groupRepository.GetGroupByID(grpID);
            alertMessage = "<div class=\"AlertHeader\">Membership request to group <b><a href=\"" + _configuration.RootURL +
                            "Groups/ViewGroup.aspx?GroupID=" + grpID + "\">" +
                            group.Name + "</a></b> has been approved</div>";
            
            foreach (int accountID in MemberIDs)
            {
                Alert alert = new Alert();
                alert.AlertTypeID = (int)AlertType.AlertTypes.MembershipApproved;
                alert.AccountID = accountID;
                alert.Message = alertMessage;
                SaveAlert(alert);
            }
        }

        //CHAPTER 10
        public void AddNewBoardPostAlert(BoardCategory category, BoardForum forum, BoardPost post, BoardPost thread, Group group)
        {
            Init();
            alert.AlertTypeID = (int)AlertType.AlertTypes.NewBoardPost;
            alertMessage = "<div class=\"AlertHeader\">" + GetProfileImage(account.AccountID) +
                           GetProfileUrl(account.Username) + " has just added a new post: <b>" +
                           post.Name + "</b></div>";

            alertMessage += "<div class=\"AlertRow\"><a href=\"" + _webContext.RootUrl + "forums/" + category.PageName +
                           "/" + forum.PageName + "/" + thread.PageName + ".aspx" + "\">" + _webContext.RootUrl +
                           "forums/" + category.PageName + "/" + forum.PageName + "/" + thread.PageName +
                           ".aspx</a></div>";
            alert.Message = alertMessage;
            //CHAPTER 13: Don't sent Alert to self
            //SaveAlert(alert);
            SendAlertToGroup(alert, group);
        }

        //CHAPTER 10
        public void AddNewBoardThreadAlert(BoardCategory category, BoardForum forum, BoardPost post, Group group)
        {
            Init();
            alert.AlertTypeID = (int)AlertType.AlertTypes.NewBoardThread;
            alertMessage = "<div class=\"AlertHeader\">" + GetProfileImage(account.AccountID) +
                           GetProfileUrl(account.Username) + " has just added a new thread on the board: <b>" +
                           post.Name + "</b></div>";

            alertMessage += "<div class=\"AlertRow\"><a href=\"" + _webContext.RootUrl + "forums/" + category.PageName +
                           "/" + forum.PageName + "/" + post.PageName + ".aspx" + "\">" + _webContext.RootUrl +
                           "forums/" + category.PageName + "/" + forum.PageName + "/" + post.PageName +
                           ".aspx</a></div>";
            alert.Message = alertMessage;
            //CHAPTER 13: Don't sent Alert to self
            //SaveAlert(alert);
            SendAlertToGroup(alert, group);
        }

        //CHAPTER 9
        public void AddNewBoardPostAlert(BoardCategory category, BoardForum forum, BoardPost post, BoardPost thread)
        {
            Init();
            alert.AlertTypeID = (int)AlertType.AlertTypes.NewBoardPost;
            alertMessage = "<div class=\"AlertHeader\">" + GetProfileImage(account.AccountID) +
                           GetProfileUrl(account.Username) + " has just added a new post to: <b>" +
                           post.Name + "</b></div>";

            alertMessage += "<div class=\"AlertRow\"><a href=\"" + _webContext.RootUrl + "forums/" + category.Name +
                           "/" + forum.Name + ".aspx/" + thread.PostID + "\">" + _webContext.RootUrl +
                           "forums/" + category.Name + "/" + forum.Name + ".aspx/" + thread.PostID + "</a></div>";
            alert.Message = alertMessage;
            //CHAPTER 13: Don't sent Alert to self
            //SaveAlert(alert);
            SendAlertToFriends(alert);
        }

        //CHAPTER 9
        public void AddNewBoardThreadAlert(BoardCategory category, BoardForum forum, BoardPost post)
        {
            Init();
            alert.AlertTypeID = (int)AlertType.AlertTypes.NewBoardThread;
            alertMessage = "<div class=\"AlertHeader\">" + GetProfileImage(account.AccountID) +
                           GetProfileUrl(account.Username) + " has just added a new thread on the board: <b>" +
                           post.Name + "</b></div>";

            alertMessage += "<div class=\"AlertRow\"><a href=\"" + _webContext.RootUrl + "forums/" + category.Name +
                           "/" + forum.Name + ".aspx/" + post.PostID + "\">" + _webContext.RootUrl +
                           "forums/" + category.Name + "/" + forum.Name + ".aspx/" + post.PostID + "</a></div>";
            alert.Message = alertMessage;
            //CHAPTER 13: Don't sent Alert to self
            //SaveAlert(alert);
            SendAlertToFriends(alert);
        }

        //CHAPTER 8
        public void AddNewBlogPostAlert(Blog blog)
        {
            Account currentUser = _userSession.CurrentUser as Account;
            alert = new Alert();
            alert.CreateDate = DateTime.Now;
            alert.AccountID = currentUser.AccountID;
            alert.AlertTypeID = (int)AlertType.AlertTypes.NewBlogPost;
            alertMessage = "<div class=\"AlertHeader\">" + GetProfileImage(currentUser.AccountID) +
                           GetProfileUrl(currentUser.Username) + " has just added a new blog post: <b>" +
                           blog.Title + "</b></div>";
            alert.Message = alertMessage;
            //CHAPTER 13: Don't sent Alert to self
            //SaveAlert(alert);
            SendAlertToFriends(alert);
        }

        //CHAPTER 8
        public void AddUpdatedBlogPostAlert(Blog blog)
        {
            Account currentUser = _userSession.CurrentUser as Account;
            alert = new Alert();
            alert.CreateDate = DateTime.Now;
            alert.AccountID = currentUser.AccountID;
            alert.AlertTypeID = (int)AlertType.AlertTypes.NewBlogPost;
            alertMessage = "<div class=\"AlertHeader\">" + GetProfileImage(currentUser.AccountID) +
                           GetProfileUrl(currentUser.Username) + " has updated the <b>" + blog.Title +
                           "</b> blog post!</div>";
            alert.Message = alertMessage;
            //CHAPTER 13: Don't sent Alert to self
            //SaveAlert(alert);
            SendAlertToFriends(alert);
        }


        //CHAPTER 5
        public void AddStatusUpdateAlert(StatusUpdate statusUpdate)
        {
            Account currentUser = _userSession.CurrentUser as Account;
            alert = new Alert();
            alert.CreateDate = DateTime.Now;
            alert.AccountID = currentUser.AccountID;
            alert.AlertTypeID = (int)AlertType.AlertTypes.StatusUpdate;
            alertMessage = "<div class=\"AlertHeader\">" + GetProfileImage(currentUser.AccountID) + GetProfileUrl(currentUser.Username) + " " + statusUpdate.Status + "</div>";
            alert.Message = alertMessage;
            //CHAPTER 13: Don't sent Alert to self
            //SaveAlert(alert);
            SendAlertToFriends(alert);
        }

        //CHAPTER 5
        public void AddFriendRequestAlert(Account FriendRequestFrom, Account FriendRequestTo, Guid requestGuid, string Message)
        {
            alert = new Alert();
            alert.CreateDate = DateTime.Now;
            alert.AccountID = FriendRequestTo.AccountID;
            alertMessage = "<div class=\"AlertHeader\">" + GetProfileImage(FriendRequestFrom.AccountID) + GetProfileUrl(FriendRequestFrom.Username) + " would like to be friends!</div>";
            alertMessage += "<div class=\"AlertRow\">";
            alertMessage += FriendRequestFrom.FirstName + " " + FriendRequestFrom.LastName +
                            " would like to be friends with you!  Click this link to add this user as a friend: ";
            alertMessage += "<a href=\"" + _configuration.RootURL +
            "Friends/ConfirmFriendshipRequest.aspx?InvitationKey=" + requestGuid.ToString() + "\">" + _configuration.RootURL +
            "Friends/ConfirmFriendshipRequest.aspx?InvitationKey=" + requestGuid.ToString() + "</a><HR>" + Message + "</div>";

            alert.Message = alertMessage;
            alert.AlertTypeID = (int)AlertType.AlertTypes.FriendRequest;
            SaveAlert(alert);
        }

        //CHAPTER 5
        public void AddFriendAddedAlert(Account FriendRequestFrom, Account FriendRequestTo)
        {
            alert = new Alert();
            alert.CreateDate = DateTime.Now;
            alert.AccountID = FriendRequestFrom.AccountID;
            alertMessage = "<div class=\"AlertHeader\">" + GetProfileImage(FriendRequestTo.AccountID) + GetProfileUrl(FriendRequestTo.Username) + " is now your friend!</div>";
            alertMessage += "<div class=\"AlertRow\">" + GetSendMessageUrl(FriendRequestTo.AccountID) + "</div>";
            alert.Message = alertMessage;
            alert.AlertTypeID = (int)AlertType.AlertTypes.FriendAdded;
            SaveAlert(alert);

            alert = new Alert();
            alert.CreateDate = DateTime.Now;
            alert.AccountID = FriendRequestTo.AccountID;
            alertMessage = "<div class=\"AlertHeader\">" + GetProfileImage(FriendRequestFrom.AccountID) + GetProfileUrl(FriendRequestFrom.Username) + " is now your friend!</div>";
            alertMessage += "<div class=\"AlertRow\">" + GetSendMessageUrl(FriendRequestFrom.AccountID) + "</div>";
            alert.Message = alertMessage;
            alert.AlertTypeID = (int)AlertType.AlertTypes.FriendAdded;
            SaveAlert(alert);

            alert.AccountID = FriendRequestFrom.AccountID;
            SendAlertToFriends(alert);

            alert.AccountID = FriendRequestTo.AccountID;
            SendAlertToFriends(alert);
        }

        public void AddAccountCreatedAlert()
        {
            Init();
            alertMessage = "<div class=\"AlertHeader\">" + GetProfileUrl(account.Username) + " just signed up!</div>";
            alertMessage += "<div class=\"AlertRow\">" + GetSendMessageUrl(account.AccountID) + "</div>";
            alert.Message = alertMessage;
            alert.AlertTypeID = (int)AlertType.AlertTypes.AccountCreated;
            SaveAlert(alert);
        }

        public void AddAccountModifiedAlert()
        {
            Init();
            alertMessage = "<div class=\"AlertHeader\">" + GetProfileUrl(account.Username) +
                            " modified their account.</div>";
            alert.Message = alertMessage;
            alert.AlertTypeID = (int)AlertType.AlertTypes.AccountModified;
            //CHAPTER 13: Don't sent Alert to self
            //SaveAlert(alert);
            SendAlertToFriends(alert);
        }

        public void AddProfileCreatedAlert()
        {
            Init();
            alertMessage = "<div class=\"AlertHeader\">" + GetProfileUrl(account.Username) +
                            " just created their profile!</div>";
            alertMessage += "<div class=\"AlertRow\">" + GetSendMessageUrl(account.AccountID) + "</div>";
            alert.Message = alertMessage;
            alert.AlertTypeID = (int)AlertType.AlertTypes.ProfileCreated;
            SaveAlert(alert);
        }

        public void AddProfileModifiedAlert()
        {
            Init();
            alertMessage = "<div class=\"AlertHeader\">" + GetProfileUrl(account.Username) +
                            " modified their profile.</div>";
            alert.Message = alertMessage;
            alert.AlertTypeID = (int)AlertType.AlertTypes.ProfileModified;
            //CHAPTER 13: Don't sent Alert to self
            //SaveAlert(alert);
            SendAlertToFriends(alert);
        }

        //CHAPTER 9. Modified image size so that less space is taken to display it
        public void AddNewAvatarAlert()
        {
            Init();
            alertMessage =
                "<div class=\"AlertHeader\"><img src=\"[rootUrl]images/ProfileAvatar/ProfileImage.aspx?AccountID=" +
                account.AccountID.ToString() + "\" width=\"50\" height=\"50\" align=\"absmiddle\">" + GetProfileUrl(account.Username) + " added a new avatar.</div>";
            alert.Message = alertMessage;
            alert.AlertTypeID = (int)AlertType.AlertTypes.NewAvatar;
            SaveAlert(alert);
        }

        public List<Alert> GetAlertsByAccountID(Int32 AccountID)
        {
            List<Alert> result = new List<Alert>();
            List<Alert> alerts = _alertRepository.GetAlertsByAccountID(AccountID);
            foreach (Alert alert in alerts)
            {
                foreach (string s in tags)
                {
                    switch (s)
                    {
                        case "[rootUrl]":
                            alert.Message = alert.Message.Replace("[rootUrl]", _webContext.RootUrl);
                            result.Add(alert);
                            break;
                    }
                }
            }
            return result;
        }

        private void SaveAlert(Alert alert)
        {
            _alertRepository.SaveAlert(alert);
        }

        //CHAPTER 10
        private void SendAlertToGroup(Alert alert, Group group)
        {
            List<int> groupMembers = _groupMemberRepository.GetMemberAccountIDsByGroupID(group.GroupID);
            foreach (int id in groupMembers)
            {
                alert.AlertID = 0;
                alert.AccountID = id;
                SaveAlert(alert);
            }
        }

        //CHAPTER 5
        private void SendAlertToFriends(Alert alert)
        {
            List<Friend> friends = _friendRepository.GetFriendsByAccountID(alert.AccountID);
            foreach (Friend friend in friends)
            {
                Alert friendAlert = new Alert();
                friendAlert.AccountID = friend.MyFriendsAccountID;
                friendAlert.Message = alert.Message;
                friendAlert.AlertTypeID = alert.AlertTypeID;
                friendAlert.CreateDate = alert.CreateDate;
                SaveAlert(friendAlert);
            }
        }

        //CHAPTER 5
        private string GetProfileImage(Int32 AccountID)
        {
            return "<img width=\"50\" height=\"50\" src=\"[rootUrl]images/ProfileAvatar/ProfileImage.aspx?AccountID=" +
                AccountID.ToString() + "&w=50&h=50\" align=\"absmiddle\">";
        }

        private string GetProfileUrl(string Username)
        {
            return "<a href=\"[rootUrl]" + Username + "\">" + Username + "</a>";
        }

        //CHAPTER 6
        private string GetSendMessageUrl(Int32 AccountID)
        {
            return "<a href=\"[rootUrl]/mail/newmessage.aspx?AccountID=" + AccountID.ToString() +
                   "\">Click here to send message</a>";
        }
    }
}
