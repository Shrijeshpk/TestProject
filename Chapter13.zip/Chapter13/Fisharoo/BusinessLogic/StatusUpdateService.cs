﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Common;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    //CHAPTER 5
    [Export(typeof(IStatusUpdateService))]
    public class StatusUpdateService : IStatusUpdateService
    {
        [Import]
        private IStatusUpdateRepository _statusUpdateRepository;

        public StatusUpdateService()
        {
            MEFManager.Compose(this);
        }

        public void SaveStatusUpdate(StatusUpdate statusUpdate)
        {
            _statusUpdateRepository.SaveStatusUpdate(statusUpdate);
        }

        public List<StatusUpdate> GetTopNStatusUpdatesByAccountID(int AccountID, int Number)
        {
            return _statusUpdateRepository.GetTopNStatusUpdatesByAccountID(AccountID, Number);
        }

        public List<StatusUpdate> GetStatusUpdatesByAccountID(Int32 AccountID)
        {
            return _statusUpdateRepository.GetStatusUpdatesByAccountID(AccountID);
        }
    }
}
