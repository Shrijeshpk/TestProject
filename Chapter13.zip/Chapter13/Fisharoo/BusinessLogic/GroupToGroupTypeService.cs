﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Common;

namespace Fisharoo.BusinessLogic
{
    [Export(typeof(IGroupToGroupTypeService))]
    public class GroupToGroupTypeService : IGroupToGroupTypeService
    {
        [Import]
        IGroupToGroupTypeRepository _groupToGroupTypeRepository;

        public GroupToGroupTypeService()
        {
            MEFManager.Compose(this);
        }

        public void SaveGroupTypesForGroup(List<long> SelectedGroupTypeIDs, int GroupID)
        {
            _groupToGroupTypeRepository.SaveGroupTypesForGroup(SelectedGroupTypeIDs, GroupID);
        }
    }
}
