﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess;
using Fisharoo.Interfaces;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Common;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    //CHAPTER 13
    [Export("IEmailService")]
    public class DBMailService : IEmailService
    {
        [Import]
        private IEmailRepository _emailRepository;
        [Import]
        private IConfiguration _configuration;
        private Connection _conn;
        public DBMailService()
        {
            _conn = new Connection();
            MEFManager.Compose(this);
        }

        public void Send(MailMessage Message)
        {
            Message.Subject = _configuration.SiteName + " - " + Message.Subject;

            MailQueue_Receiving mq = new MailQueue_Receiving();
            mq.CreateDate = DateTime.Now;
            mq.SerializedMailMessage = Message.Body; //TODO:Atul.Suds. Fix this call. Message.Serialize();
            mq.SendDate = Convert.ToDateTime("1/1/2000");

            _emailRepository.Save(mq);
        }

        public void ProcessEmails()
        {
            //make sure we are only processing this in one thread! 
            //otherwise we might lose emails
            lock (this)
            {
                   
                    List<pr_MailQueue_SwapReceivingAndWorking_GetWorking_Result> results =
                        new List<pr_MailQueue_SwapReceivingAndWorking_GetWorking_Result>();

                    results = _emailRepository.GetMailQueueToProcess();
                    
                    foreach (var result in results)
                    {
                        MailMessage mm = XMLService.Deserialize<MailMessage>(result.SerializedMailMessage);
                        SmtpClient smtp = new SmtpClient();
                        smtp.Send(mm);
                    }
                    
                    _emailRepository.MoveMailQueueWorkingToHistory();
               }
 
            }
        }
    }

