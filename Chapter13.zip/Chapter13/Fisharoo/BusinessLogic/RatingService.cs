﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Common;
using Fisharoo.DataAccess;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    [Export(typeof(IRatingService))]
    public class RatingService : IRatingService
    {
        [Import]
        IRatingRepository _ratingRepository;

        public RatingService()
        {
            MEFManager.Compose(this);
        }

        public int GetCurrentRating(int SystemObjectID, long SystemObjectRecordID)
        {
            return _ratingRepository.GetCurrentRating(SystemObjectID, SystemObjectRecordID); ;
        }

        public bool HasRatedBefore(int SystemObjectID, long SystemObjectRecordID, int AccountID)
        {
            return _ratingRepository.HasRatedBefore(SystemObjectID, SystemObjectRecordID, AccountID);
        }

        public void SaveRatings(List<Rating> ratings)
        {
            _ratingRepository.SaveRatings(ratings);
        }
    }
}
