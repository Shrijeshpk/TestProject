﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Common;
using Fisharoo.DataAccess;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    [Export(typeof(ICommentsService))]
    public class CommentsService : ICommentsService
    {
        [Import]
        private ICommentsRepository _commentsRepository;

        public CommentsService()
        {
            MEFManager.Compose(this);
        }

        public List<Comment> GetCommentsBySystemObject(int SystemObjectID, long SystemObjectRecordID)
        {
            return _commentsRepository.GetCommentsBySystemObject(SystemObjectID, SystemObjectRecordID);
        }

        public long SaveComment(Comment comment)
        {
            return _commentsRepository.SaveComment(comment);
        }
    }
}
