﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Common;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    [Export(typeof(ISystemObjectTagService))]
    public class SystemObjectTagService : ISystemObjectTagService
    {
        [Import]
        ISystemObjectTagRepository _systemObjectTagRepository;

        public SystemObjectTagService()
        {
            MEFManager.Compose(this);
        }

        public List<SystemObjectTagWithObject> GetSystemObjectsByTagID(int TagID)
        {
            return _systemObjectTagRepository.GetSystemObjectsByTagID(TagID);
        }
    }
}
