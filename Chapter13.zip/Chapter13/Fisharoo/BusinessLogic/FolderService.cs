﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Common;
using Fisharoo.DataAccess;
using Fisharoo.Interfaces;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    //CHAPTER 7
    [Export(typeof(IFolderService))]
    //CHAPTER 13 - For Caching
    [Export(typeof(ICache))]
    public class FolderService : IFolderService
    {
        [Import]
        private IFriendRepository _friendRepository;
        [Import]
        private IFolderRepository _folderRepository;
        [Import]
        private ICache _cacheService;

        public FolderService()
        {
            MEFManager.Compose(this);
        }

        public List<Folder> GetFriendsFolders(Int32 AccountID)
        {
            List<Friend> friends = _friendRepository.GetFriendsByAccountID(AccountID);
            List<Folder> folders = _folderRepository.GetFriendsFolders(friends);
            folders.OrderBy(f => f.CreateDate).Reverse();
            return folders;
        }

        //CHAPTER 7
        public void DeleteFolder(Folder folder)
        {
            //CHAPTER 13 - first removing the folder from the cache
            if (_cacheService.Exists(folder.AccountID.ToString()))
            {
                _cacheService.Delete(folder.AccountID.ToString());
            }

            //actual physical delete
            _folderRepository.DeleteFolder(folder);
        }

        public List<Folder> GetFoldersByAccountID(int AccountID)
        {
            //CHAPTER 13, Implemented a sample for Caching
            List<Folder> cachedFolders = _cacheService.Get(AccountID.ToString()) as List<Folder>;
            if (cachedFolders != null)
            {
                return cachedFolders;
            }
            else
            {
                cachedFolders = _folderRepository.GetFoldersByAccountID(AccountID);
                _cacheService.Set(AccountID.ToString(), cachedFolders);
                return cachedFolders;
            }
        }

        public Folder GetFolderByID(Int64 FolderID)
        {
            return _folderRepository.GetFolderByID(FolderID);
        }

        public Int64 SaveFolder(Folder folder)
        {
            return _folderRepository.SaveFolder(folder);
        }
    }
}
