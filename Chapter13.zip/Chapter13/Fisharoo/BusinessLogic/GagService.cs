﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Common;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    [Export(typeof(IGagService))]
    public class GagService : IGagService
    {
        [Import]
        private IGagRepository _gagRepository;

        public GagService()
        {
            MEFManager.Compose(this);
        }

        public Gag SaveGag(Gag gag)
        {
            return _gagRepository.SaveGag(gag);
        }
    }
}
