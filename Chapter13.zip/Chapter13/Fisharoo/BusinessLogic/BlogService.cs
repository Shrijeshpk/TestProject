﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Common;
using Fisharoo.DataAccess;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    [Export(typeof(IBlogService))]
    public class BlogService : IBlogService
    {
        [Import]
        IBlogRepository _blogRespository;

        public BlogService()
        {
            MEFManager.Compose(this);
        }

        public void DeleteBlog(long BlogID)
        {
            _blogRespository.DeleteBlog(BlogID);
        }

        public List<Blog> GetBlogsByAccountID(int AccountID)
        {
            return _blogRespository.GetBlogsByAccountID(AccountID);
        }
        
        public Blog GetBlogByPageName(string PageName, Int32 AccountID)
        {
            return _blogRespository.GetBlogByPageName(PageName, AccountID);
        }

        public List<Blog> GetLatestBlogs()
        {
            return _blogRespository.GetLatestBlogs();
        }

        public bool CheckPageNameIsUnique(Blog blog)
        {
            return _blogRespository.CheckPageNameIsUnique(blog);
        }

        public Blog GetBlogByBlogID(long BlogID)
        {
            return _blogRespository.GetBlogByBlogID(BlogID);
        }

        public long SaveBlog(Blog blog)
        {
            return _blogRespository.SaveBlog(blog);
        }
    }
}
