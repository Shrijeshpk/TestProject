﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;
using Fisharoo.Common;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.DataAccess;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    [Export(typeof(IBoardPostService))]
    public class BoardPostService:IBoardPostService
    {
        [Import]
        private IBoardPostRepository _postRepository;

        public BoardPostService()
        {
           MEFManager.Compose(this);
        }

        public List<BoardPost> GetThreadsByForumID(Int32 ForumID)
        {
            return _postRepository.GetThreadsByForumID(ForumID);
        }

        public List<BoardPost> GetPostsByThreadID(Int64 ThreadID)
        {
            return _postRepository.GetPostsByThreadID(ThreadID);
        }

        public BoardPost GetPostByID(long PostID)
        {
            return _postRepository.GetPostByID(PostID);
        }

        public Int64 SavePost(BoardPost boardPost)
        {
            return _postRepository.SavePost(boardPost);
        }
        //CHAPTER 10
        public void DeletePostsByForumID(int ForumID)
        {
            _postRepository.DeletePostsByForumID(ForumID);
        }
     }  
}
