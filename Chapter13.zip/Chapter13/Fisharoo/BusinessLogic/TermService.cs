﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.Entities;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Common;

namespace Fisharoo.BusinessLogic
{
    [Export(typeof(ITermService))]
    public class TermService : ITermService
    {
        [Import]
        private ITermRepository _termRepository;

        public TermService()
        {
            MEFManager.Compose(this);
        }

        public Term GetCurrentTerm()
        {
            return _termRepository.GetCurrentTerm();
        }
    }
}
