﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Common;
using Fisharoo.DataAccess;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    [Export(typeof(IFileService))]
    public class FileService : IFileService
    {
        [Import]
        IFileRepository _fileRepository;

        public FileService()
        {
            MEFManager.Compose(this);
        }

        public void DeleteFilesInFolder(string FilePath, Folder folder)
        {
            _fileRepository.DeleteFilesInFolder(FilePath, folder);
        }

        public List<File> GetFilesByFolderID(long FolderID)
        {
            return _fileRepository.GetFilesByFolderID(FolderID);
        }

        public Int64 SaveFile(File file)
        {
            return _fileRepository.SaveFile(file);
        }

        public void UpdateDescriptions(Dictionary<int, string> fileDescriptions)
        {
            _fileRepository.UpdateDescriptions(fileDescriptions);
        }
    }
}
