﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.Interfaces;
using Fisharoo.Common;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    //CHAPTER 13
    [Export(typeof(IEmailService))]
    public class EmailService : IEmailService
    {
        [Import]
        private IConfiguration _configuration;

        public EmailService()
        {
            MEFManager.Compose(this);
        }

        public void Send(MailMessage Message)
        {
            Message.Subject = _configuration.SiteName + " - " + Message.Subject;
            SmtpClient smtp = new SmtpClient();
            smtp.Send(Message);
        }

        public void ProcessEmails()
        {
            throw (new Exception("ProcessEmails is not implemented by this class!"));
        }
    }
}
