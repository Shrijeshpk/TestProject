﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Common;
using Fisharoo.DataAccess;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Interfaces;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    //CHAPTER 10
    [Export(typeof(IGroupService))]
    public class GroupService : IGroupService
    {
        [Import]
        private IGroupRepository _groupRepository;
        [Import]
        private IGroupMemberRepository _groupMemberRepository;
        [Import]
        private IWebContext _webContext;
        [Import]
        private IBoardForumRepository _forumRepository;
        [Import]
        private IGroupForumRepository _groupForumRepository;

        public GroupService()
        {
            MEFManager.Compose(this);
        }

        public bool IsOwnerOrAdministrator(Int32 AccountID, Int32 GroupID)
        {
            bool result = false;
            if (IsOwner(AccountID, GroupID) || IsAdministrator(AccountID, GroupID))
                result = true;
            return result;
        }

        public bool IsOwner(Int32 AccountID, Int32 GroupID)
        {
            return _groupRepository.IsOwner(AccountID, GroupID);    
        }

        public bool IsAdministrator(Int32 AccountID, Int32 GroupID)
        {
            return _groupMemberRepository.IsAdministrator(AccountID, GroupID);
        }

        public bool IsMember(Int32 AccountID, Int32 GroupID)
        {
            return _groupMemberRepository.IsMember(AccountID, GroupID);
        }

        public int SaveGroup(Group group)
        {
            int result = 0;
            if(group.GroupID > 0)
            {
                result = _groupRepository.SaveGroup(group);
            }
            else
            {
                result = _groupRepository.SaveGroup(group);

                Account currentUser = _webContext.CurrentUser as Account;
                BoardForum forum = new BoardForum();
                forum.CategoryID = 4; //group forums container
                forum.CreateDate = DateTime.Now;
                forum.LastPostByAccountID = currentUser.AccountID;
                forum.LastPostByUsername = currentUser.Username;
                forum.LastPostDate = DateTime.Now;
                forum.Name = group.Name;
                forum.PageName = group.PageName;
                forum.PostCount = 0;
                forum.Subject = group.Name;
                forum.ThreadCount = 0;
                forum.UpdateDate = DateTime.Now;
                int ForumID = _forumRepository.SaveForum(forum);

                //create relationship between the group and forum
                GroupForum gf = new GroupForum();
                gf.ForumID = ForumID;
                gf.GroupID = group.GroupID;
                gf.CreateDate = DateTime.Now;
                _groupForumRepository.SaveGroupForum(gf);
            }

            return result;
        }

        public bool CheckIfGroupPageNameExists(string PageName)
        {
           return _groupRepository.CheckIfGroupPageNameExists(PageName);
        }

        public List<Group> GetLatestGroups()
        {
            return _groupRepository.GetLatestGroups();
        }

        public Group GetGroupByID(int GroupID)
        {
            return _groupRepository.GetGroupByID(GroupID);
        }

        public Group GetGroupByPageName(string PageName)
        {
            return _groupRepository.GetGroupByPageName(PageName);
        }

        public List<Group> GetGroupsOwnedByAccount(int AccountID)
        {
            return _groupRepository.GetGroupsOwnedByAccount(AccountID);
        }

        public Group GetGroupByForumID(int ForumID)
        {
            return _groupRepository.GetGroupByForumID(ForumID);
        }

        public void DeleteGroup(int GroupID)
        {
            _groupRepository.DeleteGroup(GroupID);
        }
    }
}
