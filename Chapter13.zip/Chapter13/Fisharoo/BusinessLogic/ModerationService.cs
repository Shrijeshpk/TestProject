﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Common;
using Fisharoo.DataAccess.Repositories;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    [Export(typeof(IModerationService))]
    public class ModerationService : IModerationService
    {
        [Import]
        private IModerationRepository _moderationRepository;

        public ModerationService()
        {
            MEFManager.Compose(this);
        }

        public List<Moderation> GetModerationsGlobal()
        {
            return _moderationRepository.GetModerationsGlobal();
        }

        public void SaveModerationResults(List<ModerationResult> results, int ActionByAccountID, string ActionByUsername)
        {
            _moderationRepository.SaveModerationResults(results, ActionByAccountID, ActionByUsername);
        }


        public Moderation SaveModeration(Moderation moderation)
        {
            return _moderationRepository.SaveModeration(moderation);
        }

        public bool HasFlaggedThisAlready(int AccountID, int SystemObjectID, long SystemObjectRecordID)
        {
            return _moderationRepository.HasFlaggedThisAlready(AccountID, SystemObjectID, SystemObjectRecordID);
        }
    }
}
