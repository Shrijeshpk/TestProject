﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Common;
using Fisharoo.DataAccess;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    [Export(typeof(IBoardService))]
    public class BoardService : IBoardService
    {
        [Import]
        private IBoardCategoryRepository _categoryRepository;
        [Import]
        private IBoardForumRepository _forumRepository;
        
        public BoardService()
        {
            MEFManager.Compose(this);
        }

        public List<BoardCategory> GetCategoriesWithForums()
        {
            List<BoardCategory> categories = _categoryRepository.GetAllCategories();
            List<BoardForum> forums = _forumRepository.GetAllForums();
            for(int i = 0;i<categories.Count();i++)
            {
                categories[i].Forums = forums.Where(f => f.CategoryID == categories[i].CategoryID).ToList();
            }
            return categories;
        }
    }
}
