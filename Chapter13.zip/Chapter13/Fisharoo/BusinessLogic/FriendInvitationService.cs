﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Common;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    [Export(typeof(IFriendInvitationService))]
    public class FriendInvitationService : IFriendInvitationService
    {
        [Import]
        private IFriendInvitationRepository _friendInvitationRepository;

        public FriendInvitationService()
        {
            MEFManager.Compose(this);
        }

        public FriendInvitation GetFriendInvitationByGUID(Guid guid)
        {
            return _friendInvitationRepository.GetFriendInvitationByGUID(guid);
        }
    }
}
