﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Common;
using Fisharoo.DataAccess;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    [Export(typeof(IGroupMemberService))]
    public class GroupMemberService : IGroupMemberService
    {
        [Import]
        private IGroupMemberRepository _groupMemberRepository;

        public GroupMemberService()
        {
            MEFManager.Compose(this);
        }

        public void DeleteGroupMembers(List<int> MembersToDelete, int GroupID)
        {
            _groupMemberRepository.DeleteGroupMembers(MembersToDelete, GroupID);
        }

        public void ApproveGroupMembers(List<int> MembersToApprove, int GroupID)
        {
            _groupMemberRepository.ApproveGroupMembers(MembersToApprove, GroupID);
        }

        public void PromoteGroupMembersToAdmin(List<int> MembersToPromote, int GroupID)
        {
            _groupMemberRepository.PromoteGroupMembersToAdmin(MembersToPromote, GroupID);
        }

        public void DemoteGroupMembersFromAdmin(List<int> MembersToDemote, int GroupID)
        {
            _groupMemberRepository.DemoteGroupMembersFromAdmin(MembersToDemote, GroupID);
        }

        public void DeleteAllGroupMembersForGroup(int GroupID)
        {
            _groupMemberRepository.DeleteAllGroupMembersForGroup(GroupID);
        }

        public void SaveGroupMember(GroupMember groupMember)
        {
            _groupMemberRepository.SaveGroupMember(groupMember);
        }
    }
}
