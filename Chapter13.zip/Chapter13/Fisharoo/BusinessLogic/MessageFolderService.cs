﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Common;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    [Export(typeof(IMessageFolderService))]
    public class MessageFolderService : IMessageFolderService
    {
        [Import]
        IMessageFolderRepository _messageFolderRepository;

        public MessageFolderService()
        {
            MEFManager.Compose(this);
        }

        public List<MessageFolder> GetMessageFoldersByAccountID(int AccountID)
        {
            return _messageFolderRepository.GetMessageFoldersByAccountID(AccountID);
        }
    }
}
