﻿using System;
using System.ComponentModel.Composition;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Common;
using Fisharoo.DataAccess;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Interfaces;
using System.Collections.Generic;
using System.Reflection;
using System.ServiceModel.Activation;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    [AspNetCompatibilityRequirements(RequirementsMode =
                       AspNetCompatibilityRequirementsMode.Required)]
    [Export(typeof(IAccountService))]
    public class AccountService : IAccountService
    {
        [Import]
        private IAccountRepository _accountRepository;
        [Import]
        private IUserSession _userSession;
        [Import]
        private IRedirector _redirector;
        [Import]
        private IEmail _email;
        [Import]
        private IWebContext _webContext;
        [Import]
        private IFriendService _friendService;
        
        
        public AccountService()
        {
           MEFManager.Compose(this);
           Assembly.Load("FisharooDataAccess");
        }

        public bool UsernameInUse(string Username)
        {
            Account account = _accountRepository.GetAccountByUsername(Username);
            if (account != null)
                return true;
            return false;
        }

        public bool EmailInUse(string Email)
        {
            Account account = _accountRepository.GetAccountByEmail(Email);
            if (account != null)
                return true;
                
            return false;
        }

        //CHAPTER 13 - This method is no longer required
        public void Logout()
        {
            _userSession.LoggedIn = false;
            _userSession.CurrentUser = null;
            _userSession.Username = "";
            _redirector.GoToAccountLoginPage();
        }

        //public string Login(string Username, string Password, bool isAdminApplication)
        public Account Login(string Username, string Password, bool isAdminApplication)
        {
          
            Password = Password.Encrypt(Username);
            // _log.Debug(this, Password);
            Account account = _accountRepository.GetAccountByUsername(Username);

            //if there is only one account returned - good
            if (account != null)
            {
                //password matches
                if (account.Password == Password)
                {

                    //CHAPTER 12. Added to handle Admin application
                    if (isAdminApplication)
                    {
                        foreach (AccountPermission ap in account.AccountPermissions)
                        {
                            if (ap.Permission.Name.Equals("ADMINISTRATOR"))
                                return account;
                        }
                       // if (account.HasPermission("ADMINISTRATOR"))
                       // {
                                //CHAPTER 13
                       //         return account; 
                        //}
                    }
                    // else
                    //    return null;// "This is not an Administrator user and cannot access this site";

                    //CHAPTER 13
                    return account;
                }
                return null;
            }
            return null;
        }
        
        private bool CheckPermission(string Name, Account act)
        {
            foreach (Permission p in act.Permissions)
            //  foreach(AccountPermission p in AccountPermissions)
            {
                if (p.Name == Name)
                    return true;
            }
            return false;
        }

        public void SaveAccount(Account account)
        {
            _accountRepository.SaveAccount(account);
        }

        public Account GetAccountByEmail(string Email)
        {
            return _accountRepository.GetAccountByEmail(Email);
        }

        public void AddPermission(Account account, Permission permission)
        {
            _accountRepository.AddPermission(account, permission);
        }

        //CHAPTER 4
        public Account GetAccountByID(Int32 AccountID)
        {
            Account account = _accountRepository.GetAccountByID(AccountID);
            return account;
        }

        public Account GetAccountByUsername(string Username)
        {
            return _accountRepository.GetAccountByUsername(Username);
        }

        //CHAPTER 5
        public List<Account> SearchAccounts(string SearchText)
        {
            return _accountRepository.SearchAccounts(SearchText);
        }

        //CHAPTER 10
        public List<Account> GetApprovedAccountsByGroupID(int GroupID, int PageNumber, int NumberOfRecordsInPage)
        {
            return _accountRepository.GetApprovedAccountsByGroupID(GroupID, PageNumber, NumberOfRecordsInPage);
        }

        public List<Account> GetAccountsToApproveByGroupID(int GroupID)
        {
            return _accountRepository.GetAccountsToApproveByGroupID(GroupID);
        }

        //CHAPTER 11
        public void SaveAccount(Account account, BoardPost.ScoreInput value)
        {
            //existing account..update account
            if(account.AccountID > 0)
            {
                switch (value)
                {
                    case BoardPost.ScoreInput.ReplyPost:
                        account.Score = account.Score + 1;
                        break;
                    case BoardPost.ScoreInput.VoteUseful:
                        account.Score = account.Score + 5;
                        break;
                    case BoardPost.ScoreInput.VoteNotUseful:
                        if (account.Score > 5)
                            account.Score -= 5;
                        else
                            account.Score = 0;
                        break;
                    case BoardPost.ScoreInput.MarkedAsAnswer:
                        account.Score = account.Score + 10;
                        break;
                    default:
                        break;
                }
            }
            else //new account
            {
                // above conditions wont exists
            }
            _accountRepository.SaveAccount(account);
        }

        //CHAPTER 13
        public List<Account> GetAllAccounts(int PageNumber)
        {
            return _accountRepository.GetAllAccounts(PageNumber);
        }
    }
}
