﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Common;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    [Export(typeof(IMessageRecipientService))]
    public class MessageRecipientService : IMessageRecipientService
    {
        [Import]
        IMessageRecipientRepository _messageRecipientRepository;

        public MessageRecipientService()
        {
            MEFManager.Compose(this);
        }

        public void DeleteMessageRecipient(MessageRecipient messageRecipient)
        {
            _messageRecipientRepository.DeleteMessageRecipient(messageRecipient);
        }
    }
}
