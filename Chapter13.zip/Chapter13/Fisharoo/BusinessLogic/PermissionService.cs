﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess;
using Fisharoo.Entities;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Common;

namespace Fisharoo.BusinessLogic
{
    [Export(typeof(IPermissionService))]
    public class PermissionService : IPermissionService
    {
        [Import]
        private IPermissionRepository _permissionRepository;

        public PermissionService()
        {
            MEFManager.Compose(this);
        }

        public Permission GetPermissionByName(string Name)
        {
            return _permissionRepository.GetPermissionByName(Name);
        }
    }
}
