﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Common;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    [Export(typeof(IBoardCategoryService))]
    public class BoardCategoryService : IBoardCategoryService
    {
        [Import]
        private IBoardCategoryRepository _categoryRepository;

        public BoardCategoryService()
        {
            MEFManager.Compose(this);
        }

        public BoardCategory GetCategoryByCategoryID(int CategoryID)
        {
            return _categoryRepository.GetCategoryByCategoryID(CategoryID);
        }
    }
}
