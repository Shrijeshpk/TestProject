﻿using System;
using System.ComponentModel.Composition;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Common;
using Fisharoo.DataAccess;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Interfaces;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    [Export(typeof(IProfileService))]
    public class ProfileService : IProfileService
    {
        [Import]
        private IProfileRepository _profileRepository;
        [Import]
        private IAlertService _alertService;
        [Import]
        private IProfileAttributeRepository _profileAttributeRepository;
        [Import]
        private IUserSession _userSession;
        public ProfileService()
        {
           MEFManager.Compose(this);
        }

        public Profile LoadProfileByAccountID(Int32 AccountID)
        {
            Profile profile = null;
            profile = _profileRepository.GetProfileByAccountID(AccountID);
            return profile;
        }

        public void SaveProfile(Profile profile)
        {
            _profileRepository.SaveProfile(profile);
            Account currentUser = _userSession.CurrentUser as Account;
            currentUser.Profile = profile;
        }
    }
}
