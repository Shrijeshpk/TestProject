﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.DataAccess;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic.Interfaces
{
    public interface IFriendInvitationService
    {
        FriendInvitation GetFriendInvitationByGUID(Guid guid);
    }
}
