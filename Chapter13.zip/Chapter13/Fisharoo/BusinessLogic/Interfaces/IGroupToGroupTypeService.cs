﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fisharoo.BusinessLogic.Interfaces
{
    public interface IGroupToGroupTypeService
    {
        void SaveGroupTypesForGroup(List<long> SelectedGroupTypeIDs, int GroupID);
    }
}
