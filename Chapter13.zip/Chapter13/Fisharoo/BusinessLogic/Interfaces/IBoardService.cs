using System.Collections.Generic;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic.Interfaces
{
    //CHAPTER 9
    public interface IBoardService
    {
        List<BoardCategory> GetCategoriesWithForums();
    }
}