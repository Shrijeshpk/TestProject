using System;
using Fisharoo.DataAccess;
using System.Collections.Generic;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic.Interfaces
{
    //CHAPTER 10
    public interface IGroupService
    {
        bool CheckIfGroupPageNameExists(string PageName);
        List<Group> GetLatestGroups();
        Group GetGroupByID(Int32 GroupID);
        Group GetGroupByPageName(string PageName);
        List<Group> GetGroupsOwnedByAccount(Int32 AccountID);
        Group GetGroupByForumID(int ForumID);
        void DeleteGroup(int GroupID);
        int SaveGroup(Group group);
        bool IsOwnerOrAdministrator(Int32 AccountID, Int32 GroupID);
        bool IsOwner(Int32 AccountID, Int32 GroupID);
        bool IsAdministrator(Int32 AccountID, Int32 GroupID);
        bool IsMember(Int32 AccountID, Int32 GroupID);
    }
}