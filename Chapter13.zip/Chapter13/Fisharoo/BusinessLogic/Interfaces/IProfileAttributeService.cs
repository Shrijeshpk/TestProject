using System;
using System.Collections.Generic;
using Fisharoo.DataAccess;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic.Interfaces
{
    public interface IProfileAttributeService
    {
        List<ProfileAttributeType> GetProfileAttributeTypes();
        List<ProfileAttribute> GetProfileAttributesByProfileID(Int32 ProfileID);
    }
}