using System;
using System.Collections.Generic;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic.Interfaces
{
    public interface IFolderService
    {
        List<Folder> GetFriendsFolders(Int32 AccountID);
        //CHAPTER 7
        void DeleteFolder(Folder folder);
        List<Folder> GetFoldersByAccountID(Int32 AccountID);
        Folder GetFolderByID(Int64 FolderID);
        Int64 SaveFolder(Folder folder);
    }
}