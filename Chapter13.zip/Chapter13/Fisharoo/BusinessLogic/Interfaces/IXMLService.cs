
namespace Fisharoo.BusinessLogic.Interfaces
{
    //CHAPTER 13
    public interface IXMLService
    {
    }
}