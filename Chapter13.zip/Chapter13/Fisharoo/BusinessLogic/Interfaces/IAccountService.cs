
using Fisharoo.DataAccess;
using System;
using System.Collections.Generic;
using System.ServiceModel;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic.Interfaces
{
    [ServiceContract]
    public interface IAccountService
    {
        [OperationContract]
        bool UsernameInUse(string Username);
        [OperationContract]
        bool EmailInUse(string Email);
        //CHAPTER 12 - Modified
        //[OperationContract]
        //string Login(string Username, string Password, bool isAdminApplication = false);
        //CHAPTER 13 - modified return parameter
        [OperationContract]
        Account Login(string Username, string Password, bool isAdminApplication = false);

        [OperationContract]
        void Logout();
        [OperationContract]
        void SaveAccount(Account account);
        [OperationContract]
        Account GetAccountByEmail(string Email);
        [OperationContract]
        void AddPermission(Account account, Permission permission);

        //Chapater 4
        [OperationContract]
        Account GetAccountByID(Int32 AccountID);
        [OperationContract]
        Account GetAccountByUsername(string Username);

        //CHAPTER 5
        [OperationContract]
        List<Account> SearchAccounts(string SearchText);

        //CHAPTER 10
        [OperationContract]
        List<Account> GetApprovedAccountsByGroupID(int GroupID, int PageNumber, int NumberOfRecordsInPage);
        [OperationContract]
        List<Account> GetAccountsToApproveByGroupID(int GroupID);
        
        //Chapater 11
        [ServiceKnownType(typeof(BoardPost))]
        [OperationContract (Name = "SaveAccountWithScore") ]
        void SaveAccount(Account account, BoardPost.ScoreInput value);

        //Chapater 13
        [OperationContract]
        List<Account> GetAllAccounts(Int32 PageNumber);
    }
}