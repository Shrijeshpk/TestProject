﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.DataAccess;

namespace Fisharoo.BusinessLogic.Interfaces
{
    public interface IGroupForumService
    {
        void DeleteGroupForum(int ForumID, int GroupID);
    }
}
