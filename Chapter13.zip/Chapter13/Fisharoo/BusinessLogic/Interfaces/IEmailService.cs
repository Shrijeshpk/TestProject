using System.Net.Mail;

namespace Fisharoo.BusinessLogic.Interfaces
{
    //CHAPTER 13
    public interface IEmailService
    {
        void Send(MailMessage Message);
        void ProcessEmails();
    }
}