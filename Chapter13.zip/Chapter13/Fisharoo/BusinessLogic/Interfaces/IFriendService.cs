using System;
using Fisharoo.DataAccess;
using System.Collections.Generic;
using System.ServiceModel;
using Fisharoo.Entities;
 

namespace Fisharoo.BusinessLogic.Interfaces
{
    [ServiceContract]
    public interface IFriendService
    {
        [OperationContract]
        bool CreateFriendFromFriendInvitation(Guid InvitationKey, Account InvitationTo, bool ExistingMember);
        [OperationContract]
        bool IsFriend(Account account, Account accountBeingViewed);
        [OperationContract]
        List<Account> GetFriendsAccountsByAccountID(Int32 AccountID);
        [OperationContract]
        void DeleteFriendByID(Int32 AccountIDToRemoveFriendFrom, Int32 FriendIDToRemove);

        
    }

}