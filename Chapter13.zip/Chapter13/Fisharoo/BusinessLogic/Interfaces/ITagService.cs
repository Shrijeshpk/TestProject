﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic.Interfaces
{
    //CHAPTER 11
    public interface ITagService
    {
        void AddTag(string TagName, int SystemObjectID, long SystemObjectRecordID);
        List<Tag> CalculateFontSize(List<Tag> Tags);
        Tag GetTagByName(string Name);
        List<Tag> GetTagsGlobal(int TagsToTake);
        List<Tag> GetTagsBySystemObject(int SystemObjectID, int TagsToTake);
        List<Tag> GetTagsBySystemObjectAndRecordID(int SystemObjectID, long SystemObjectRecordID);
    }
}
