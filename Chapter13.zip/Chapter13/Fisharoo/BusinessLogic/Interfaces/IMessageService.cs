
using System.Collections.Generic;
using Fisharoo.Entities;
using System;
namespace Fisharoo.BusinessLogic.Interfaces
{
    public interface IMessageService
    {
        List<MessageWithRecipient> GetMessagesByAccountID(Int32 AccountID, Int32 PageNumber, MessageFolders Folder);
        MessageWithRecipient GetMessageByMessageID(Int32 MessageID, Int32 RecipientAccountID);
        int GetPageCount(MessageFolders messageFolder, Int32 RecipientAccountID);
        void SendMessage(string Body, string Subject, string[] To);
    }
}