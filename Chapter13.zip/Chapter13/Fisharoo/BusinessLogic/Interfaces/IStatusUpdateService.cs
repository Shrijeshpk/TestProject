﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic.Interfaces
{
    //CHAPTER 5
    public interface IStatusUpdateService
    {
        void SaveStatusUpdate(StatusUpdate statusUpdate);
        List<StatusUpdate> GetTopNStatusUpdatesByAccountID(Int32 AccountID, Int32 Number);
        List<StatusUpdate> GetStatusUpdatesByAccountID(Int32 AccountID);
    }
}
