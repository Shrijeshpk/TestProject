﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic.Interfaces
{
    public interface ICommentsService
    {
        List<Comment> GetCommentsBySystemObject(int SystemObjectID, long SystemObjectRecordID);
        long SaveComment(Comment comment);
    }
}
