﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic.Interfaces
{
    public interface IRatingService
    {
        int GetCurrentRating(int SystemObjectID, long SystemObjectRecordID);
        bool HasRatedBefore(int SystemObjectID, long SystemObjectRecordID, int AccountID);
        void SaveRatings(List<Rating> ratings);
    }
}
