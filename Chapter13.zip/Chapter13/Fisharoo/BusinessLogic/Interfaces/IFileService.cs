﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic.Interfaces
{
    //CHAPTER 7
    public interface IFileService
    {
        void DeleteFilesInFolder(string FilePath, Folder folder);
        List<File> GetFilesByFolderID(Int64 FolderID);
        Int64 SaveFile(File file);
        void UpdateDescriptions(Dictionary<int, string> fileDescriptions);
    }
}
