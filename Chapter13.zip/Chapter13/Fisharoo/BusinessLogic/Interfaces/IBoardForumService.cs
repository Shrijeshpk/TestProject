﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic.Interfaces
{
    public interface IBoardForumService
    {
        BoardForum GetForumByName(string Name);
        //CHAPTER 10
        void DeleteForum(BoardForum boardForum);
        BoardForum GetForumByGroupID(Int32 GroupID);
    }
}
