﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic.Interfaces
{
    public interface IBoardPostService
    {
        List<BoardPost> GetThreadsByForumID(Int32 ForumID);
        List<BoardPost> GetPostsByThreadID(Int64 ThreadID);
        BoardPost GetPostByID(Int64 PostID);
        Int64 SavePost(BoardPost boardPost);
        //CHAPTER 10
        void DeletePostsByForumID(int ForumID);
    }

    
}
