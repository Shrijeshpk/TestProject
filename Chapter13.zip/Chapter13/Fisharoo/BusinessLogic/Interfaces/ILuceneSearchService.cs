using System;
using System.Collections.Generic;

namespace Fisharoo.BusinessLogic.Interfaces
{
    //CHAPTER 13
    public interface ILuceneSearchService
    {
        event EventHandler RecordAddedEvent;
        List<SearchResult> Search(string InputText);
        void BuildIndexesThread();
    }
}