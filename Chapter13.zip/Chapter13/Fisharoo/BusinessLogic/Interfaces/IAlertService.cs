using System;
using System.Collections.Generic;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic.Interfaces
{
    public interface IAlertService
    {
        void AddAccountCreatedAlert();
        void AddAccountModifiedAlert();
        void AddProfileCreatedAlert();
        void AddProfileModifiedAlert();
        void AddNewAvatarAlert();
        List<Alert> GetAlertsByAccountID(Int32 AccountID);

        //CHAPTER 5
        void AddFriendAddedAlert(Account FriendRequestFrom, Account FriendRequestTo);
        void AddFriendRequestAlert(Account FriendRequestFrom, Account FriendRequestTo, Guid requestGuid, string Message);
        void AddStatusUpdateAlert(StatusUpdate statusUpdate);

        //CHAPTER 9
        void AddNewBoardPostAlert(BoardCategory category, BoardForum forum, BoardPost post, BoardPost thread);
        void AddNewBoardThreadAlert(BoardCategory category, BoardForum forum, BoardPost post);

        //CHAPTER 10
        void AddGroupMembershipRequestAlert(int accID, int grpID, string userName);
        void AddGroupMembershipApprovedAlert(List<int> MemberIDs, int grpID);
        void AddNewBoardThreadAlert(BoardCategory category, BoardForum forum, BoardPost post, Group group);
        void AddNewBoardPostAlert(BoardCategory category, BoardForum forum, BoardPost post, BoardPost thread, Group group);

        //CHAPTER 13
        void DeleteAlerts(List<int> alertIDs);
    }
}