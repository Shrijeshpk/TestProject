﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic.Interfaces
{
    public interface IGroupMemberService
    {
        void DeleteGroupMembers(List<int> MembersToDelete, int GroupID);
        void ApproveGroupMembers(List<int> MembersToApprove, int GroupID);
        void PromoteGroupMembersToAdmin(List<int> MembersToPromote, int GroupID);
        void DemoteGroupMembersFromAdmin(List<int> MembersToDemote, int GroupID);
        void DeleteAllGroupMembersForGroup(int GroupID);
        void SaveGroupMember(GroupMember groupMember);
    }
}
