﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.Entities;

using Fisharoo.DataAccess.Repositories;

namespace Fisharoo.BusinessLogic.Interfaces
{
    //CHAPTER 13
    public interface IModerationService
    {
        List<Moderation> GetModerationsGlobal();
        void SaveModerationResults(List<ModerationResult> results, int ActionByAccountID, string ActionByUsername);
        Moderation SaveModeration(Moderation moderation);
        bool HasFlaggedThisAlready(int AccountID, int SystemObjectID, long SystemObjectRecordID);
    }
}
