
namespace Fisharoo.BusinessLogic.Interfaces
{
    //CHAPTER 12
    public interface IContentFilterService
    {
        string Filter(string StringToFilter);
    }
}