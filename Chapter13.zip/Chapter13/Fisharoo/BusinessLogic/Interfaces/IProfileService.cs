using System;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic.Interfaces
{
    public interface IProfileService
    {
        Profile LoadProfileByAccountID(Int32 AccountID);
        void SaveProfile(Profile profile);
    }
}