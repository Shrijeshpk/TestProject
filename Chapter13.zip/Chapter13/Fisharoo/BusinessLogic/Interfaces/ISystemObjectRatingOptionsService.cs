﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic.Interfaces
{
    public interface ISystemObjectRatingOptionsService
    {
        List<SystemObjectRatingOption> GetSystemObjectRatingOptionsBySystemObjectID(int SystemObjectID);
    }
}
