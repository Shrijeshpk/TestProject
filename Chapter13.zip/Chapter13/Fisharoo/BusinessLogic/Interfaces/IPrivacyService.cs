using System;
using System.Collections.Generic;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic.Interfaces
{
    //CHAPTER 4
    public interface IPrivacyService
    {
        List<PrivacyFlagType> GetPrivacyFlagTypes();
        List<VisibilityLevel> GetVisibilityLevels();
        List<PrivacyFlag> GetPrivacyFlagsByProfileID(Int32 ProfileID);
        void SavePrivacyFlag(PrivacyFlag privacyFlag);
        bool ShouldShow(Int32 PrivacyFlagTypeID,
                        Account AccountBeingViewed,
                        Account Account,
                        List<PrivacyFlag> Flags);
    }
}