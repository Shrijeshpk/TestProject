﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic.Interfaces
{
    //CHAPTER 8
    public interface IBlogService
    {
        bool CheckPageNameIsUnique(Blog blog);
        void DeleteBlog(Int64 BlogID);
        List<Blog> GetBlogsByAccountID(Int32 AccountID);
        Blog GetBlogByBlogID(Int64 BlogID);
        Blog GetBlogByPageName(string PageName, Int32 AccountID);
        List<Blog> GetLatestBlogs();
        Int64 SaveBlog(Blog blog);
    }
}
