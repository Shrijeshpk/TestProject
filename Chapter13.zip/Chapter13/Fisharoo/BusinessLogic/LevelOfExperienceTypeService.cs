﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.Common;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    //CHAPTER 4
    [Export(typeof(ILevelOfExperienceTypeService))]
    public class LevelOfExperienceTypeService : ILevelOfExperienceTypeService
    {
        [Import]
        private ILevelOfExperienceTypeRepository _levelOfExperienceTypeRepository;

        public LevelOfExperienceTypeService()
        {
            MEFManager.Compose(this);
        }

        public List<LevelOfExperienceType> GetAllLevelOfExperienceTypes()
        {
            return _levelOfExperienceTypeRepository.GetAllLevelOfExperienceTypes();
        }
    }
}
