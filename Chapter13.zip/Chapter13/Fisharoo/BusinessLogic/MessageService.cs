﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.Common;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Interfaces;
using Fisharoo.DataAccess;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    [Export(typeof(IMessageService))]
    public class MessageService : IMessageService
    {
        [Import]
        private IUserSession _userSession;
        [Import]
        private IMessageRepository _messageRepository;
        [Import]
        private IMessageRecipientRepository _messageRecipientRepository;
        [Import]
        private IAccountRepository _accountRepository;
        [Import]
        private IEmail _email;
        public MessageService()
        {
            MEFManager.Compose(this);
        }

        public List<MessageWithRecipient> GetMessagesByAccountID(Int32 AccountID, Int32 PageNumber, MessageFolders Folder)
        {
            return _messageRepository.GetMessagesByAccountID(AccountID, PageNumber, Folder);
        }

        public MessageWithRecipient GetMessageByMessageID(Int32 MessageID, Int32 RecipientAccountID)
        {
            return _messageRepository.GetMessageByMessageID(MessageID, RecipientAccountID);
        }

        public int GetPageCount(MessageFolders messageFolder, Int32 RecipientAccountID)
        {
            return _messageRepository.GetPageCount(messageFolder, RecipientAccountID);
        }

        public void SendMessage(string Body, string Subject, string[] To)
        {
            Account currentUser = _userSession.CurrentUser as Account;
            Message m = new Message();
            m.Body = Body;
            m.Subject = Subject;
            m.CreateDate = DateTime.Now;
            m.MessageTypeID = (int)MessageTypes.Message;
            m.SentByAccountID = currentUser.AccountID;
            Int64 messageID = _messageRepository.SaveMessage(m);

            //create a copy in the sent items folder for this user
            MessageRecipient sendermr = new MessageRecipient();
            sendermr.AccountID = currentUser.AccountID;
            sendermr.MessageFolderID = (int) MessageFolders.Sent;
            sendermr.MessageRecipientTypeID = (int) MessageRecipientTypes.TO;
            sendermr.MessageID = messageID;
            sendermr.MessageStatusTypeID = (int)MessageStatusTypes.Unread;
            _messageRecipientRepository.SaveMessageRecipient(sendermr);

            //send to people in the To field
            foreach (string s in To)
            {
                Account toAccount = null;
                if (s.Contains("@"))
                    toAccount = _accountRepository.GetAccountByEmail(s);
                else
                    toAccount = _accountRepository.GetAccountByUsername(s);

                if(toAccount != null)
                {
                    MessageRecipient mr = new MessageRecipient();
                    mr.AccountID = toAccount.AccountID;
                    mr.MessageFolderID = (int)MessageFolders.Inbox;
                    mr.MessageID = messageID;
                    mr.MessageRecipientTypeID = (int) MessageRecipientTypes.TO;
                    mr.MessageStatusTypeID = (int)MessageStatusTypes.Unread;
                    _messageRecipientRepository.SaveMessageRecipient(mr);
                    Account acc = _userSession.CurrentUser as Account;
                    _email.SendNewMessageNotification(acc.FirstName, acc.LastName, toAccount.Email);
                }               
            }
        }
    }
}
