﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Common;
using Fisharoo.DataAccess;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    [Export(typeof(ISystemObjectRatingOptionsService))]
    public class SystemObjectRatingOptionsService : ISystemObjectRatingOptionsService
    {
        [Import]
        private ISystemObjectRatingOptionsRepository _systemObjectRatingOptionsRepository;

        public SystemObjectRatingOptionsService()
        {
            MEFManager.Compose(this);
        }

        public List<SystemObjectRatingOption> GetSystemObjectRatingOptionsBySystemObjectID(int SystemObjectID)
        {
            return _systemObjectRatingOptionsRepository.GetSystemObjectRatingOptionsBySystemObjectID(SystemObjectID);
        }
    }
}
