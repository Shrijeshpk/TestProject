﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess;
using Fisharoo.DataAccess.Interfaces;

namespace Fisharoo.BusinessLogic
{
    [Export(typeof(IGroupForumService))]
    public class GroupForumService : IGroupForumService
    {
        [Import]
        IGroupForumRepository _groupForumRepository;

        public void DeleteGroupForum(int ForumID, int GroupID)
        {
            _groupForumRepository.DeleteGroupForum(ForumID, GroupID);
        }
    }
}
