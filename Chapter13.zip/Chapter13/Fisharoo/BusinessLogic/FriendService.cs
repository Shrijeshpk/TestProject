﻿using System;
using System.Linq;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Common;
using Fisharoo.DataAccess;
using System.Collections.Generic;
using System.ServiceModel.Activation;
using Fisharoo.Entities;


namespace Fisharoo.BusinessLogic
{
    //CHAPTER 13
        [AspNetCompatibilityRequirements(RequirementsMode =
                       AspNetCompatibilityRequirementsMode.Required)]
    //CHAPTER 5
    [Export(typeof(IFriendService))]
    public class FriendService : IFriendService
    {
        [Import]
        private IFriendInvitationRepository _friendInvitationRepository;
        [Import]
        private IFriendRepository _friendRepository;
        [Import]
        private IAlertService _alertService;
        [Import]
        private IAccountRepository _accountRepository;

        public FriendService()
        {
            MEFManager.Compose(this);
        }

        public bool IsFriend(Account account, Account accountBeingViewed)
        {
            if (account == null)
                return false;

            if (accountBeingViewed == null)
                return false;

            if (account.AccountID == accountBeingViewed.AccountID)
                return true;
            else
            {
                Friend friend = _friendRepository.GetFriendsByAccountID(accountBeingViewed.AccountID)
                                .Where(f => f.MyFriendsAccountID == account.AccountID).FirstOrDefault();
                if (friend != null)
                    return true;
            }
            return false;
         }

        public bool CreateFriendFromFriendInvitation(Guid InvitationKey, Account InvitationTo, bool ExistingMember)
        {
            //update friend invitation request
            FriendInvitation friendInvitation = _friendInvitationRepository.GetFriendInvitationByGUID(InvitationKey);
            //validate if the friend request is for the same person who has logged in
            //however if this is a new member (new registration), then don't validate as the 
            //person may use a different email during registration
            if(ExistingMember && (friendInvitation.Email != InvitationTo.Email))
                return false;

            friendInvitation.BecameAccountID = InvitationTo.AccountID;
            _friendInvitationRepository.SaveFriendInvitation(friendInvitation);
            _friendInvitationRepository.CleanUpFriendInvitationsForThisEmail(friendInvitation);

            //create friendship
            Friend friend = new Friend();
            friend.AccountID = friendInvitation.AccountID;
            friend.MyFriendsAccountID = InvitationTo.AccountID;
            _friendRepository.SaveFriend(friend);

            Account InvitationFrom = _accountRepository.GetAccountByID(friendInvitation.AccountID);
            _alertService.AddFriendAddedAlert(InvitationFrom, InvitationTo);
            return true;
            //CHAPTER 6
            //TODO: MESSAGING - Add message to inbox regarding new friendship!
        }

        public List<Account> GetFriendsAccountsByAccountID(Int32 AccountID)
        {
            return _friendRepository.GetFriendsAccountsByAccountID(AccountID);
        }

        public void DeleteFriendByID(Int32 AccountIDToRemoveFriendFrom, Int32 FriendIDToRemove)
        {
            _friendRepository.DeleteFriendByID(AccountIDToRemoveFriendFrom, FriendIDToRemove);
        }
    }
}
