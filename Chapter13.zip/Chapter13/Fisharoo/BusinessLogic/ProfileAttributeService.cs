﻿using System;
using System.Collections.Generic;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.DataAccess.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.Common;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    [Export(typeof(IProfileAttributeService))]
    public class ProfileAttributeService : IProfileAttributeService
    {
        [Import]
        private IProfileAttributeRepository _profileAttributeRepository;
        public ProfileAttributeService()
        {
            MEFManager.Compose(this);
        }

        public List<ProfileAttributeType> GetProfileAttributeTypes()
        {
            return _profileAttributeRepository.GetProfileAttributeTypes();
        }

        public List<ProfileAttribute> GetProfileAttributesByProfileID(Int32 ProfileID)
        {
            List<ProfileAttribute> attributes;
            attributes = _profileAttributeRepository.GetProfileAttributesByProfileID(ProfileID);
            return attributes;
        }       
    }
}
