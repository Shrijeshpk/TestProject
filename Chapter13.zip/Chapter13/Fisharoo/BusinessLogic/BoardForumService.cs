﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.BusinessLogic.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.DataAccess;
using Fisharoo.Common;
using Fisharoo.Entities;

namespace Fisharoo.BusinessLogic
{
    [Export(typeof(IBoardForumService))]
    public class BoardForumService : IBoardForumService
    {
        [Import]
        private IBoardForumRepository _forumRepository;

        public BoardForumService()
        {
            MEFManager.Compose(this);
        }

        public void DeleteForum(BoardForum boardForum)
        {
            _forumRepository.DeleteForum(boardForum);
        }

        public BoardForum GetForumByName(string Name)
        {
            return _forumRepository.GetForumByName(Name);
        }

        public BoardForum GetForumByGroupID(int GroupID)
        {
            return _forumRepository.GetForumByGroupID(GroupID);
        }
    }
}
