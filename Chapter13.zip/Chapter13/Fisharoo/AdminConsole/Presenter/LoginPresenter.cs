﻿using System.ComponentModel.Composition;
using System.Web;
using Fisharoo.AdminConsole.Interface;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Common;
using Fisharoo.Entities;


namespace Fisharoo.AdminConsole.Presenter
{
    public class LoginPresenter
    {
        private ILogin _view;
        [Import]
        private IAccountService _accountService;

        public void Init(ILogin view)
        {
            _view = view;
            MEFManager.Compose(this);
        }

        public void LogIn(string Username, string Password)
        {
            //string msg = _accountService.Login(Username, Password, true);
            Fisharoo.Entities.Account account = _accountService.Login(Username, Password, true);
            if(account != null)
            //if(msg == "valid")
                HttpContext.Current.Response.Redirect("~/Default.aspx");
            else
                _view.ShowMessage("This is not an Administrator user and cannot access this site");
        }
    }
}
