﻿using System;
namespace Fisharoo.AdminConsole.Interface
{
    public interface ILogin
    {
        void ShowMessage(string Message);
    }
}
