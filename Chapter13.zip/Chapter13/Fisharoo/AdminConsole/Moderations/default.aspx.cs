﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Web.UI.WebControls;
using Fisharoo.AdminConsole.Moderations.Interface;
using Fisharoo.AdminConsole.Moderations.Presenters;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Common;
using Fisharoo.DataAccess.Repositories;
using Fisharoo.Interfaces;
using Fisharoo.Entities;

namespace Fisharoo.AdminConsole.Moderations
{
    public partial class _default : System.Web.UI.Page, IDefault
    {
        private DefaultPresenter _presenter;
        [Import]
        private IUploadService _uploadService;
        [Import]
        protected IConfiguration _configuration;
        
        public _default()
        {
            MEFManager.Compose(this);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            _presenter = new DefaultPresenter();
            _presenter.Init(this, IsPostBack);
        }

        protected void repModeration_ItemDataBound(object sender, RepeaterItemEventArgs e)
        {
            if(e.Item.ItemType == ListItemType.AlternatingItem || e.Item.ItemType == ListItemType.Item)
            {
                PlaceHolder phContent = e.Item.FindControl("phContent") as PlaceHolder;
                Moderation moderation = e.Item.DataItem as Moderation;


                string file = _uploadService.GetFullFilePathByFileID(moderation.SystemObjectRecordID, File.Sizes.S);

                if(moderation.SystemObjectID == 5)
                {
                    Image img = new Image();
                    img.ImageUrl = _configuration.RootURL + "files/photos/" + file;
                    phContent.Controls.Add(img);
                }

                HyperLink lnkURL = e.Item.FindControl("lnkURL") as HyperLink;
                lnkURL.NavigateUrl = _configuration.RootURL + moderation.AccountUsername;
                lnkURL.Text = moderation.AccountUsername;

                Literal litSystemObjectID = e.Item.FindControl("litSystemObjectID") as Literal;
                litSystemObjectID.Text = moderation.SystemObjectID.ToString();

                Literal litSystemObjectRecordID = e.Item.FindControl("litSystemObjectRecordID") as Literal;
                litSystemObjectRecordID.Text = moderation.SystemObjectRecordID.ToString();

                Literal litAccountID = e.Item.FindControl("litAccountID") as Literal;
                litAccountID.Text = moderation.AccountID.ToString();

                Literal litAccountUsername = e.Item.FindControl("litAccountUsername") as Literal;
                litAccountUsername.Text = moderation.AccountUsername;
            }
        }

        public void LoadData(List<Moderation> moderations)
        {
            repModeration.DataSource = moderations;
            repModeration.DataBind();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            List<ModerationResult> results = new List<ModerationResult>();
            foreach (RepeaterItem item in repModeration.Controls)
            {
                if(item.ItemType == ListItemType.AlternatingItem || item.ItemType == ListItemType.Item)
                {
                    CheckBox chkApprove = item.FindControl("chkApprove") as CheckBox;
                    CheckBox chkDeny = item.FindControl("chkDeny") as CheckBox;
                    Literal litSystemObjectID = item.FindControl("litSystemObjectID") as Literal;
                    Literal litSystemObjectRecordID = item.FindControl("litSystemObjectRecordID") as Literal;
                    TextBox txtGagDate = item.FindControl("txtGagDate") as TextBox;
                    TextBox txtReason = item.FindControl("txtReason") as TextBox;
                    Literal litAccountID = item.FindControl("litAccountID") as Literal;
                    Literal litAccountUsername = item.FindControl("litAccountUsername") as Literal;

                    if(chkDeny.Checked || chkApprove.Checked)
                    {
                        ModerationResult mr = new ModerationResult();
                        mr.SystemObjectID = Convert.ToInt32(litSystemObjectID.Text);
                        mr.SystemObjectRecordID = Convert.ToInt64(litSystemObjectRecordID.Text);

                        if (chkApprove.Checked)
                        {
                            mr.IsApproved = true;
                            results.Add(mr);
                        }

                        //deny wins
                        if (chkDeny.Checked)
                        {
                            mr.IsApproved = false;
                            results.Add(mr);
                        }
                    }

                    if(!string.IsNullOrEmpty(txtGagDate.Text))
                    {
                        _presenter.GagUserUntil(Convert.ToInt32(litAccountID.Text), 
                            litAccountUsername.Text, 
                            DateTime.Parse(txtGagDate.Text), 
                            txtReason.Text);
                    }
                }
            }

            if(results.Count() > 0)
                _presenter.SaveModerationResults(results);
        }

        public void ClearData()
        {
            repModeration.Controls.Clear();
        }
    }
}
