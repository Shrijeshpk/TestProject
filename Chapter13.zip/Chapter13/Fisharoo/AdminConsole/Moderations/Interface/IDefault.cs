﻿using System;
using System.Collections.Generic;
using System.Text;
using Fisharoo.Entities;

namespace Fisharoo.AdminConsole.Moderations.Interface
{
    public interface IDefault
    {
        void LoadData(List<Moderation> moderations);
        void ClearData();
    }
}
