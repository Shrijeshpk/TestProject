﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using Fisharoo.AdminConsole.Moderations.Interface;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Common;
using Fisharoo.DataAccess.Repositories;
using Fisharoo.Entities;
using Fisharoo.Interfaces;

namespace Fisharoo.AdminConsole.Moderations.Presenters
{
    public class DefaultPresenter
    {
        private IDefault _view;
        [Import]
        private IModerationService _moderationService;
        [Import]
        private IGagService _gagService;
        [Import]
        private IWebContext _webContext;

        public DefaultPresenter()
        {
            MEFManager.Compose(this);
        }

        public void Init(IDefault view, bool IsPostBack)
        {
            _view = view;
            if (!IsPostBack)
            {
                LoadData();
            }
        }

        public void GagUserUntil(int AccountID, string AccountUsername, DateTime GagTillDate, string Reason)
        {
            Gag gag = new Gag();
            gag.AccountID = AccountID;
            gag.CreateDate = DateTime.Now;
            gag.AccountUsername = AccountUsername;
            gag.GagUntilDate = GagTillDate;
            gag.Reason = Reason;
            Fisharoo.Entities.Account currentUser = _webContext.CurrentUser as Fisharoo.Entities.Account;
            gag.GaggedByAccountID = currentUser.AccountID;
            _gagService.SaveGag(gag);
        }

        public void LoadData()
        {
            _view.LoadData(_moderationService.GetModerationsGlobal());
        }

        public void SaveModerationResults(List<ModerationResult> results)
        {
            Fisharoo.Entities.Account currentUser = _webContext.CurrentUser as Fisharoo.Entities.Account;
            _moderationService.SaveModerationResults(results, currentUser.AccountID, currentUser.Username);
            _view.ClearData();
            LoadData();
        }
    }
}
