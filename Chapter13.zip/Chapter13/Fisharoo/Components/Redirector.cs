﻿using System.Web;
using System.ComponentModel.Composition;
using Fisharoo.Interfaces;
using System;

namespace Fisharoo.Components
{
    [Export(typeof(IRedirector))]
    public class Redirector : IRedirector
    {
        //CHAPTER 10 
        public void GoToGroupsManageGroup(int GroupID)
        {
            Redirect("~/Groups/ManageGroup.aspx?GroupID=" + GroupID.ToString());
        }
        //CHAPTER 10
        public void GoToGroupsMembers(int GroupID, int PageNumber)
        {
            Redirect("~/Groups/Members.aspx?GroupID=" + GroupID.ToString() + "&PageNumber=" + PageNumber.ToString());
        }
        //CHAPTER 10
        public void GoToGroupsViewGroup(int GroupID)
        {
            Redirect("~/Groups/ViewGroup.aspx?GroupID=" + GroupID.ToString());
        }
        //CHAPTER 10
        public void GoToGroupsMembers(int GroupID)
        {
            Redirect("~/Groups/Members.aspx?GroupID=" + GroupID.ToString());
        }
        //CHAPTER 10
        public void GoToGroupsViewGroup(string GroupPageName)
        {
            Redirect("~/Groups/" + GroupPageName + ".aspx");
        }

        //CHAPTER 9
        public void GoToForumDefaultView()
        {
            Redirect("~/Forums/Default.aspx");
        }
        //CHAPTER 9
        public void GoToForumsViewPost(string path)
        {
            Redirect(path);
        }
        //CHAPTER 9
        public void GoToForumsForumView(string ForumName, string CategoryName)
        {
            Redirect("~/Forums/" + CategoryName + "/" + ForumName + ".aspx");
        }
        //CHAPTER 8
        public void GoToBlogsPostEdit(Int64 BlogID)
        {
            Redirect("~/Blogs/Post.aspx?BlogID=" + BlogID.ToString());
        }
        //CHAPTER 7
        public void GoToPhotosMyPhotos()
        {
            Redirect("~/Photos/MyPhotos.aspx");
        }

        //CHAPTER 7
        public void GoToPhotosEditAlbum(Int64 AlbumID)
        {
            Redirect("~/Photos/EditAlbum.aspx?AlbumID=" + AlbumID.ToString());
        }

        //CHAPTER 7
        public void GoToPhotosEditPhotos(Int64 AlbumID)
        {
            Redirect("~/Photos/EditPhotos.aspx?AlbumID=" + AlbumID.ToString());
        }

        //CHAPTER 7
        public void GoToPhotosViewAlbum(Int64 AlbumID)
        {
            Redirect("~/Photos/ViewAlbum.aspx?AlbumID=" + AlbumID.ToString());
        }

        //CHAPTER 7
        public void GoToPhotos()
        {
            Redirect("~/Photos/Default.aspx");
        }

        //CHAPTER 7
        public void GoToPhotosAddPhotos(Int64 AlbumID)
        {
            Redirect("~/Photos/AddPhotos.aspx?AlbumID=" + AlbumID.ToString());
        }

        //CHAPTER 6
        public void GoToMailNewMessage(Int32 MessageID)
        {
            Redirect("~/Mail/NewMessage.aspx?MessageID=" + MessageID.ToString());
        }

        //CHAPTER 5
        public void GoToProfilesStatusUpdates()
        {
            Redirect("~/Profiles/StatusUpdates.aspx");
        }

        //CHAPTER 5
        public void GoToProfilesStatusUpdates(Int32 AccountID)
        {
            Redirect("~/Profiles/StatusUpdates.aspx?" + AccountID.ToString());
        }

        //CHAPTER 5
        public void GoToSearch(string SearchText)
        {
            Redirect("~/Search.aspx?s=" + SearchText);
        }

        //CHAPTER 5
        public void GoToFriendsInviteFriends(Int32 AccoundIdToInvite)
        {
            Redirect("~/Friends/InviteFriends.aspx?AccountIdToInvite=" + AccoundIdToInvite.ToString());
        }

        //ChAPTER 5
        public void GoToAccountRegisterPage(string FriendInvitationKey)
        {
            Redirect("~/Accounts/Register.aspx?InvitationKey=" + FriendInvitationKey);
        }

        //CHAPTER 5
        public void GoToAccountLoginPage(string FriendInvitationKey)
        {
            Redirect("~/Accounts/Login.aspx?InvitationKey=" + FriendInvitationKey);
        }

        //CHAPTER 4
        public void GoToProfilesProfile()
        {
            Redirect("~/Profiles/Profile.aspx");
        }

        //CHAPTER 4
        public void GoToProfilesDefault()
        {
            Redirect("~/Profiles/Default.aspx");
        }

        //CHAPTER 4
        public void GoToProfilesManageProfile()
        {
            Redirect("~/Profiles/ManageProfile.aspx");
        }
        //CHAPTER 3
        public void GoToAccountAccessDenied()
        {
            Redirect("~/Accounts/AccessDenied.aspx");
        }

        //CHAPTER 3
        public void GoToAccountRecoverPasswordPage()
        {
            Redirect("~/Accounts/RecoverPassword.aspx");
        }

        //CHAPTER 3
        public void GoToAccountEditAccountPage()
        {
            Redirect("~/Accounts/EditAccount.aspx");
        }

        //CHAPTER 3
        public void GoToAccountLoginPage()
        {
            Redirect("~/Accounts/Login.aspx");
        }

        //CHAPTER 3
        public void GoToAccountRegisterPage()
        {
            Redirect("~/Accounts/Register.aspx");
        }

        public void GoToHomePage()
        {
            Redirect("~/Default.aspx");
        }

        public void GoToErrorPage()
        {
            Redirect("~/Error.aspx");
        }

        private void Redirect(string path)
        {
            HttpContext.Current.Response.Redirect(path);
        }
    }
}
