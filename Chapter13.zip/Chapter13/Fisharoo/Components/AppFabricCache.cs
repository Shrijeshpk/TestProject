﻿using System;
using System.Collections.Generic;
using System.Web.Caching;
using System.ComponentModel.Composition;
using Fisharoo.Interfaces;
using Fisharoo.Components.Properties;
using Microsoft.ApplicationServer.Caching;

namespace Fisharoo.Components
{
    [Export(typeof(ICache))]
    public class AppFabriCache : ICache
    {
        private static DataCache dataCache;
        private static TimeSpan timeSpan = new TimeSpan(
            Settings.Default.DefaultCacheDuration_Days,
            Settings.Default.DefaultCacheDuration_Hours,
            Settings.Default.DefaultCacheDuration_Minutes, 0);

        private static DataCacheFactory dataCacheFactory;
        private static string namedCache = "FisharooCachedData";

        static AppFabriCache()
        {
            if (dataCacheFactory != null)
            {
                dataCacheFactory = new DataCacheFactory();
                dataCache = dataCacheFactory.GetCache("FisharooCachedData");
            }
        }

        public object Get(string cache_key)
        {
            return dataCache.Get(cache_key);
        }

        public List<string> GetCacheKeys()
        {
            throw new Exception("method is not supported");
        }

        public void Set(string cache_key, object cache_object)
        {
            dataCache.Put(cache_key, cache_object);
        }

        public void Set(string cache_key, object cache_object, DateTime expiration)
        {
            throw new Exception("method is not supported");
        }

        public void Set(string cache_key, object cache_object, TimeSpan expiration)
        {
            dataCache.Put(cache_key, cache_object, expiration);
        }

        public void Set(string cache_key, object cache_object, DateTime expiration, CacheItemPriority priority)
        {
            throw new Exception("method is not supported");
            //dataCache.Put(cache_key, cache_object);
        }

        public void Set(string cache_key, object cache_object, TimeSpan expiration, CacheItemPriority priority)
        {
            throw new Exception("method is not supported");
        }

        public void Delete(string cache_key)
        {
            if (Exists(cache_key))
                dataCache.Remove(cache_key);
        }

        public bool Exists(string cache_key)
        {
            if (dataCache[cache_key] != null)
                return true;
            else
                return false;
        }

        public void Flush()
        {
            throw new Exception("method is not supported");
        }
    }
}
