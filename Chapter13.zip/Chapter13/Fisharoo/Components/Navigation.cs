﻿using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Web;
using Fisharoo.Common;
using Fisharoo.Entities;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Interfaces;
using System.Web.Routing;

namespace Fisharoo.Components
{
    [Export(typeof(INavigation))]
    public class Navigation : INavigation
    {
        [Import]
        private IUserSession _userSession;
        [Import]
        private IRedirector _redirector;
        private Account _account;

        public Navigation()
        {
            MEFManager.Compose(this);
            _account = _userSession.CurrentUser as Account;
        }

        public List<SiteMapNode> AllNodes()
        {
            List<SiteMapNode> nodes = new List<SiteMapNode>();
            nodes.Add(SiteMap.RootNode);
            foreach (SiteMapNode node in SiteMap.RootNode.GetAllNodes())
            {
                if (CheckAccessForNode(node) && NodeIsVisible(node))
                    nodes.Add(node);
            }
            return nodes;
        }

        public List<SiteMapNode> PrimaryNodes()
        {
            List<SiteMapNode> primaryNodes = new List<SiteMapNode>();
            foreach (SiteMapNode node in AllNodes())
            {
                if (node["topnav"] != null && CheckAccessForNode(node) && NodeIsVisible(node))
                    primaryNodes.Add(node);
            }
            return primaryNodes;
        }

        public List<SiteMapNode> SecondaryNodes()
        {
            List<SiteMapNode> result = new List<SiteMapNode>();
            SiteMapNode parentNode;

            //is the current node the root node? aka home page
            if (CurrentNode == SiteMap.RootNode)
            {
                return GetRootSecondaryNodes();
            }
            //is the current node a topnav node?
            else if (CurrentNode["topnav"] != null)
            {
                parentNode = CurrentNode;
                foreach (SiteMapNode node in parentNode.ChildNodes)
                {
                    if (CheckAccessForNode(node) && NodeIsVisible(node))
                        result.Add(node);
                }

            }
            //not a topnav node...find the topnav node
            else
            {
                parentNode = CurrentNode.ParentNode;

                if (parentNode == SiteMap.RootNode)
                    return GetRootSecondaryNodes();

                for (int i = 0; i == 5; i++)
                {
                    if (parentNode["topnav"] != null)
                        break;
                    else
                        parentNode = parentNode.ParentNode;
                }
                foreach (SiteMapNode node in parentNode.ChildNodes)
                {
                    if (CheckAccessForNode(node) && NodeIsVisible(node))
                        result.Add(node);
                }
            }
            return result;
        }

        private List<SiteMapNode> GetRootSecondaryNodes()
        {
            List<SiteMapNode> secondaryNodes = new List<SiteMapNode>();
            foreach (SiteMapNode node in AllNodes())
            {
                if (node["rootSecondaryNav"] != null && NodeIsVisible(node) && CheckAccessForNode(node))
                    secondaryNodes.Add(node);
            }
            return secondaryNodes;
        }

        public List<SiteMapNode> FooterNodes()
        {
            List<SiteMapNode> footerNodes = new List<SiteMapNode>();
            foreach (SiteMapNode node in AllNodes())
            {
                if (node["footernav"] != null && NodeIsVisible(node) && CheckAccessForNode(node))
                    footerNodes.Add(node);
            }
            return footerNodes;
        }

        private bool NodeIsVisible(SiteMapNode node)
        {
            if (node["visible"] != null && node["visible"] == "1")
                return true;
            return false;
        }

        private bool CheckAccessForNode(SiteMapNode node)
        {
            if (!node.Roles.Contains("PUBLIC"))
            {
                if (_account != null && _account.AccountPermissions != null && _account.AccountPermissions.Count > 0)
                {
                    foreach (string role in node.Roles)
                    {
                      //  if (!_account.HasPermission(role))
                        foreach (AccountPermission ap in _account.AccountPermissions)
                        {
                            if (ap.Permission.Name.Equals(role))
                                return true;
                        }
                        return false;
                    }
                }
                else
                    return false;
            }
            return true;
        }

        public void CheckAccessForCurrentNode()
        {
            bool result = CheckAccessForNode(CurrentNode);
            if (result)
                return;
            else
                _redirector.GoToAccountAccessDenied();
        }

        public SiteMapNode RootNode
        {
            get { return SiteMap.RootNode; }
        }

        public SiteMapNode CurrentNode
        {
            get
            {
                //CHAPTER 4
                //Modified below logic for URL routing support
                //if on a valid node already, just return it
                if (SiteMap.CurrentNode != null)
                    return SiteMap.CurrentNode;

                //if routed, then will not be on a valid node. so need to find which node this maps to
                //can hard code as there are limited routes, but let's write a generic method
                PageRouteHandler routable = HttpContext.Current.Request.RequestContext.RouteData.RouteHandler as PageRouteHandler;

                if (routable != null)
                    return SiteMap.Provider.FindSiteMapNodeFromKey(routable.VirtualPath);

                //if no mapping found, return null. should not come here ideally
                return null;
            }
        }
    }
}
