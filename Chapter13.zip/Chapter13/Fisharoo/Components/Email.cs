﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Net.Mail;
using System.Text.RegularExpressions;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Common;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Entities;
using Fisharoo.Interfaces;


namespace Fisharoo.Components
{
    [Export(typeof(IEmail))]
    public class Email : IEmail
    {
        const string TO_EMAIL_ADDRESS = @"website@fisharoo.com";
        const string FROM_EMAIL_ADDRESS = @"website@fisharoo.com";
        [Import]
        private IConfiguration _configuration;

        //CHAPTER 5
        [Import]
        private IFriendInvitationRepository _friendInvitationRepository;
        [Import]
        private IAccountRepository _accountRepository;
        [Import]
        private IAlertService _alertService;
        [Import]
        private IUserSession _userSession;

        //CHAPTER 13
        [Import]
        private IEmailService _emailService;

        public Email()
        {
            MEFManager.Compose(this);
        }

        //CHAPTER 6
        public void SendNewMessageNotification(string FirstName, string LastName, string ToEmail)
        {
            foreach (string s in ToEmail.Split(new char[] { ',', ';' }))
            {
                string message = FirstName + " " + LastName +
                " has sent you a message on " + _configuration.SiteName + "!  Please log in at " + _configuration.SiteName +
                " to view the message.<HR>";

                SendEmail(s, "", "", FirstName + " " + LastName +
                    " has sent you a message on " +
                    _configuration.SiteName + "!", message);
            }
        }

        //CHAPTER 5
        public string SendInvitations(int accID, string FirstName, string LastName, string ToEmailArray, string Message)
        {
            string resultMessage = Message;
            foreach (string s in ToEmailArray.Split(','))
            {
                FriendInvitation friendInvitation = new FriendInvitation();

                friendInvitation.AccountID = accID;
                
                friendInvitation.Email = s;
                friendInvitation.GUID = Guid.NewGuid();
                friendInvitation.BecameAccountID = 0;
                _friendInvitationRepository.SaveFriendInvitation(friendInvitation);

                //add alert to existing users alerts
                Account account = _accountRepository.GetAccountByEmail(s);
                if (account != null)
                {
                    Account currentUser = _userSession.CurrentUser as Account;
                    _alertService.AddFriendRequestAlert(currentUser, account, friendInvitation.GUID,
                                                        Message);
                }

                //CHAPTER 6
                //TODO: MESSAGING - if this email is already in our system add a message through messaging system
                //if(email in system)
                //{
                //      add message to messaging system
                //}
                //else
                //{
                //      send email
                SendFriendInvitation(s, FirstName, LastName, friendInvitation.GUID.ToString(), Message);
                //}
                resultMessage += "• " + s + "<BR>";
            }
            return resultMessage;
        }

        //CHAPTER 5
        public List<string> ParseEmailsFromText(string text)
        {
            List<string> emails = new List<string>();
            string strRegex = @"\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*";
            Regex re = new Regex(strRegex, RegexOptions.Multiline);
            foreach (Match m in re.Matches(text))
            {
                string email = m.ToString();
                if (!emails.Contains(email))
                    emails.Add(email);
            }
            return emails;
        }

        //CHAPTER 5
        public void SendFriendInvitation(string toEmail, string fromFirstName, string fromLastName, string GUID, string Message)
        {
            Message = fromFirstName + " " + fromLastName +
            " has invited you to join us at " + _configuration.SiteName + "!<HR><a href=\"" + _configuration.RootURL +
            "Friends/ConfirmFriendshipRequest.aspx?InvitationKey=" + GUID + "\">" + _configuration.RootURL +
            "Friends/ConfirmFriendshipRequest.aspx?InvitationKey=" + GUID + "</a><HR>" + Message;

            SendEmail(toEmail, "", "", fromFirstName + " " + fromLastName +
                " has invited you to join us at " +
                _configuration.SiteName + "!", Message);
        }


        public void SendEmail(string From, string Subject, string Message)
        {
            MailMessage mm = new MailMessage(From,TO_EMAIL_ADDRESS);
            mm.Subject = Subject;
            mm.Body = Message;

            Send(mm);
        }

        public void SendEmail(string To, string CC, string BCC, string Subject, string Message)
        {
            MailMessage mm = new MailMessage(FROM_EMAIL_ADDRESS,To);
            if(!string.IsNullOrEmpty(CC))
                mm.CC.Add(CC);

            if (!string.IsNullOrEmpty(BCC))
                mm.Bcc.Add(BCC);

            mm.Subject = Subject;
            mm.Body = Message;
            mm.IsBodyHtml = true;

            Send(mm);
        }

        public void SendEmail(string[] To, string[] CC, string[] BCC, string Subject, string Message)
        {
            MailMessage mm = new MailMessage();
            foreach (string to in To)
            {
                mm.To.Add(to);   
            }
            foreach (string cc in CC)
            {
                mm.CC.Add(cc);
            }
            foreach (string bcc in BCC)
            {
                mm.Bcc.Add(bcc);
            }
            mm.From = new MailAddress(FROM_EMAIL_ADDRESS);
            mm.Subject = Subject;
            mm.Body = Message;
            mm.IsBodyHtml = true;

            Send(mm);
        }

        public void SendIndividualEmailsPerRecipient(string[] To, string Subject, string Message)
        {
            foreach (string to in To)
            {
                MailMessage mm = new MailMessage(FROM_EMAIL_ADDRESS,to);
                mm.Subject = Subject;
                mm.Body = Message;
                mm.IsBodyHtml = true;

                Send(mm);
            }
        }

        private void Send(MailMessage Message)
        {
            //During developement we will not be sending mails
#if !DEBUG
            //SmtpClient smtp = new SmtpClient();
            //smtp.Send(Message);
            //CHAPTER 13
            _emailService.Send(Message);
#endif
        }

        //Chapter 3
        public void SendPasswordReminderEmail(string To, string EncryptedPassword, string Username)
        {
            string Message = "Here is the password you requested: " + EncryptedPassword.Decrypt(Username);
            
            SendEmail(To, "", "", "Password Reminder", Message);
        }

        public void SendEmailAddressVerificationEmail(string Username, string To)
        {
            MEFManager.Compose(this);
            string encryptedName = Username.Encrypt("verify");

            string msg = "Please click on the link below or paste it into a browser to verify your email account.<BR><BR>" +
                            "<a href=\"" + _configuration.RootURL + "Account/VerifyEmail.aspx?a=" +
                            encryptedName + "\">" +
                            _configuration.RootURL + "Account/VerifyEmail.aspx?a=" +
                            encryptedName + "</a>";

            SendEmail(To, "", "", "Account created! Email verification required.", msg);
        }
    }
}
