﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Interfaces;
using Fisharoo.Common;

namespace Fisharoo.Components
{
    //CHAPTER 3
    [Export(typeof(IUserSession))]
    public class UserSession : IUserSession
    {
        [Import]
        private IWebContext _webContext; 

        public UserSession()
        {
            MEFManager.Compose(this);
        }

        public bool LoggedIn
        {
            get
            {
                return _webContext.LoggedIn;
            }
            set
            {
                _webContext.LoggedIn = value;
            }
        }

        //CHAPTER 13. Modified return type
        public object CurrentUser
        {
            get
            {
                return _webContext.CurrentUser;
            }
            set
            {
                _webContext.CurrentUser = value;
            }
        }

        public string Username
        {
            get
            {
                return _webContext.Username;
            }

            set
            {
                _webContext.Username = value;
            }
        }
    }
}
