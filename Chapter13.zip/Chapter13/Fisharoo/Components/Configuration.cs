﻿using System;
using System.Configuration;
using System.ComponentModel.Composition;
using Fisharoo.Interfaces;

namespace Fisharoo.Components
{
    [Export(typeof(IConfiguration))]
    public class Configuration : IConfiguration
    {
        public string SiteName
        {
            get { return getAppSetting(typeof(string), "SiteName").ToString(); }
        }

        public string RootURL
        {
            get { return getAppSetting(typeof(string), "RootURL").ToString(); }
        }

        public bool ReCaptcha
        {
            get { return ((bool)getAppSetting(typeof(bool), "reCaptcha")); }
        }

        //CHAPTER 10
        public int NumberOfRecordsInPage
        {
            get { return (int)getAppSetting(typeof(int), "NumberOfRecordsInPage"); }
        }

        //CHAPTER 11
        public int TagCloudLargestFontSize
        {
            get { return (int)getAppSetting(typeof(int), "TagCloudLargestFontSize"); }
        }

        public int TagCloudSmallestFontSize
        {
            get { return (int)getAppSetting(typeof(int), "TagCloudSmallestFontSize"); }
        }

        public string CloudSortOrder
        {
            get { return getAppSetting(typeof(string), "CloudSortOrder").ToString(); }
        }

        public int NumberOfTagsInCloud
        {
            get { return (int)getAppSetting(typeof(int), "NumberOfTagsInCloud"); }
        }

        //CHAPTER 12
        public string AdminSiteURL
        {
            get { return getAppSetting(typeof(string), "AdminSiteURL").ToString(); }
        }

        private object getAppSetting(Type expectedType, string key)
        {
            string value = ConfigurationManager.AppSettings.Get(key);
            if (value == null)
            {
                throw new Exception(string.Format("AppSetting: {0} is not configured.", key));
            }

            try
            {
                if (expectedType.Equals(typeof(int)))
                {
                    return int.Parse(value);
                }

                if (expectedType.Equals(typeof(string)))
                {
                    return value;
                }

                if (expectedType.Equals(typeof(bool)))
                {
                    return Convert.ToBoolean(value);
                }


                throw new Exception("Type not supported.");
            }
            catch (Exception ex)
            {
                throw new Exception(string.Format("Config key:{0} was expected to be of type {1} but was not.", key, expectedType),
                                    ex);
            }
        }
    }
}
