﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fisharoo.Entities
{
    //CHAPTER 7
    public partial class  FileSystemFolder
    {
        public enum Paths
        {
            Photos = 1,
            Videos = 2,
            Audios = 3
        }
    }
}
