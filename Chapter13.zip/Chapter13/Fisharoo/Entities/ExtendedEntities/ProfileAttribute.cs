﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fisharoo.Entities
{
    //CHAPTER 4
    public partial class ProfileAttribute
    {
        public ProfileAttributeType profileAttributeType { get; set; }
    }
}
