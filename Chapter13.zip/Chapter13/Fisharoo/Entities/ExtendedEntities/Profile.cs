﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fisharoo.Entities
{
    public partial class Profile
    {
        public List<ProfileAttribute> Attributes { get; set; }
        public LevelOfExperienceType levelOfExperienceType { get; set; }
        
        public Profile()
        {
            Attributes = new List<ProfileAttribute>();
        }
    }
}
