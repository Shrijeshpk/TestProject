﻿using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;

namespace Fisharoo.Entities
{
    //[DataContract name]
    [KnownType(typeof(Profile))]
    [KnownType(typeof(Permission))]
    public partial class Account
    {
        private List<Permission> _permissions = new List<Permission>();
        //Chapter 4
        private Profile _profile;

        public Account()
        {
           List<Permission> _permissions = new List<Permission>();
        }

        //Chapter 4
        [DataMember]
        public Profile Profile
        {
            get { return _profile; }
            set { _profile = value; }
        }

        [DataMember]
        public List<Permission> Permissions
        {
            get 
            {
                if (_permissions == null)
                    return new List<Permission>();
                else
                    return _permissions;
            }
        }

        
        public void AddPermission(Permission permission)
        {
            _permissions.Add(permission);
        }


        //public bool HasPermission(string Name)
        //{
        //    foreach (Permission p in _permissions)
        //    //  foreach(AccountPermission p in AccountPermissions)
        //    {
        //        if (p.Name == Name)
        //            return true;
        //    }
        //    return false;
        //}
    }
}
