﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fisharoo.Entities
{
    public enum GroupTypes
    {
        
    }

    public partial class GroupType
    {
    }
}
