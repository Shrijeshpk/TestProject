﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fisharoo.Entities
{
    public partial class FriendshipDefinition
    {
        public FriendshipDefinitionType friendshipDefinitionType { get; set; }
    }
}
