﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fisharoo.Entities
{
    public partial class BoardPost
    {
        public enum ScoreInput
        {
            ReplyPost = 1,
            VoteUseful = 2,
            VoteNotUseful = 3,
            MarkedAsAnswer = 4
        }
    }
}
