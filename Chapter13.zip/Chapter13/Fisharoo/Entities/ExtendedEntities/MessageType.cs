﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fisharoo.Entities
{
    public enum MessageTypes
    {
        FriendRequest = 1,
        FriendConfirm = 2,
        Message = 3
    }

    public partial class MessageType
    {
        
    }
}
