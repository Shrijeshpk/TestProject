﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fisharoo.Entities
{
    public enum MessageFolders
    {
        Inbox = 1,
        Sent = 2,
        Trash = 3,
        Spam = 4
    }

    public partial class MessageFolder
    {
    }
}
