﻿using System;
using System.Collections.Generic;
//using System.Data.Linq;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Fisharoo.Entities
{
    [KnownType(typeof(FriendshipDefinition))]    
    public partial class Friend
    {
        [DataMember]
        public List<FriendshipDefinition> friendshipDefinitions { get; set; }
    }
 }
