﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Fisharoo.Entities
{
    public enum MessageRecipientTypes
    {
        TO = 1,
        CC = 2,
        BCC = 3
    }

    public partial class MessageRecipientType
    {
        
    }
}
