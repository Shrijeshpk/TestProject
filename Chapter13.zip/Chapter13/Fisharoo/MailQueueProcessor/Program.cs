﻿using System.ComponentModel.Composition;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Common;

namespace Fisharoo.MailQueueProcessor
{
public class Program
{
    [Import]
    private static IEmailService _emailService;

    static void Main(string[] args)
    {
        MEFManager.Compose(null);
       _emailService.ProcessEmails();
    }
}
}
