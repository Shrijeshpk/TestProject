﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.Web.HelperClasses;

namespace Fisharoo.Web.Groups.Interfaces
{
    public interface IDefault
    {
        void LoadData(List<PEGroup> groups);
        void ShowMessage(string message);
    }
}
