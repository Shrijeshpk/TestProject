﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.Entities;

namespace Fisharoo.Web.Groups.Interfaces
{
    public interface IManageGroup
    {
        void LoadGroup(Group group, List<GroupType> selectedTypes);
        void ShowMessage(string Message);
        void LoadGroupTypes(List<GroupType> types);
    }
}
