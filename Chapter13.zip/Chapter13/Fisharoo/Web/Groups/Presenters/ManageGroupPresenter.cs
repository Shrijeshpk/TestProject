﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Web;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Common;
using Fisharoo.Interfaces;
using Fisharoo.Web.Groups.Interfaces;
using Fisharoo.Entities;

namespace Fisharoo.Web.Groups.Presenters
{
    public class ManageGroupPresenter
    {
        private IManageGroup _view;
        [Import]
        private IRedirector _redirector;
        [Import]
        private IWebContext _webContext;
        [Import]
        private IGroupService _groupService;
        [Import]
        private IUploadService _uploadService;
        [Import]
        private IBoardForumService _forumService;
        [Import]
        private IFileService _fileService;
        [Import]
        private IGroupToGroupTypeService _groupToGroupTypeService;
        [Import]
        private IGroupTypeService _groupTypeService;

        public ManageGroupPresenter()
        {
            MEFManager.Compose(this);
        }

        public void Init(IManageGroup view, bool IsPostBack)
        {
            _view = view;
            Account currentUser = _webContext.CurrentUser as Account;
            //security check for group
            if (_webContext.GroupID > 0 && !_groupService.IsOwnerOrAdministrator(currentUser.AccountID, _webContext.GroupID))
                _redirector.GoToAccountAccessDenied();

            if(!IsPostBack)
                view.LoadGroupTypes(_groupTypeService.GetAllGroupTypes());

            if (_webContext.GroupID > 0 && !IsPostBack)
                view.LoadGroup(_groupService.GetGroupByID(_webContext.GroupID),
                               _groupTypeService.GetGroupTypesByGroupID(_webContext.GroupID));
        }

        public void SaveGroup(Group group, HttpPostedFile file, List<long> selectedGroupTypeIDs)
        {
            if (group.Description.Length > 2000)
            {
                _view.ShowMessage("Your description is " + group.Description.Length.ToString() +
                                  " characters long and can only be 2000 characters!");
            }
            else
            {
                Account currentUser = _webContext.CurrentUser as Account;
                group.AccountID = currentUser.AccountID;
                group.PageName = group.PageName.Replace(" ", "-");
                //if this is a new group then check to see if the page name is in use
                if (group.GroupID == 0 && _groupService.CheckIfGroupPageNameExists(group.PageName))
                {
                    _view.ShowMessage("The page name you specified is already in use!");
                }
                else
                {
                    if (file.ContentLength > 0)
                    {
                        List<Int64> fileIDs = _uploadService.UploadPhotos(1, currentUser.AccountID,
                                                                        _webContext.Files, 1);
                        //should only be one item uploaded!
                        if (fileIDs.Count == 1)
                            group.FileID = fileIDs[0];
                    }
                    group.GroupID = _groupService.SaveGroup(group);
                    _groupToGroupTypeService.SaveGroupTypesForGroup(selectedGroupTypeIDs,group.GroupID);
                    _redirector.GoToGroupsViewGroup(group.PageName);
                }
            }
        }

        public string GetImagePathByID(Int64 ImageID)
        {
            return _uploadService.GetFullFilePathByFileID(ImageID, File.Sizes.S);
        }
    }
}
