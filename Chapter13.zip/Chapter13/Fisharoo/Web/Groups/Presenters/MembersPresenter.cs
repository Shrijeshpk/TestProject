﻿using System.Collections.Generic;
using System.ComponentModel.Composition;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Common;
using Fisharoo.Interfaces;
using Fisharoo.Web.Groups.Interfaces;
using Fisharoo.Entities;

namespace Fisharoo.Web.Groups.Presenters
{
    public class MembersPresenter
    {
        private IMembers _view;
        [Import]
        private IAccountService _accountService;
        [Import]
        private IGroupMemberService _groupMemberService;
        [Import]
        private IGroupService _groupService;
        [Import]
        private IWebContext _webContext;
        [Import]
        private IRedirector _redirector;
        [Import]
        private IConfiguration _configuration;
        [Import]
        private IAlertService _alertService;

        public MembersPresenter()
        {
            MEFManager.Compose(this);
        }

        public void Init(IMembers view, bool IsPostBack)
        {
            _view = view;
            Account currentUser = _webContext.CurrentUser as Account;
            //do we show the buttons?
            if(currentUser == null)
                _view.SetButtonsVisibility(false);
            else if (_groupService.IsOwnerOrAdministrator(currentUser.AccountID, _webContext.GroupID))
                _view.SetButtonsVisibility(true);
            else
                _view.SetButtonsVisibility(false);

            if(!IsPostBack)
                LoadData();
        }

        public void Next()
        {
            _redirector.GoToGroupsMembers(_webContext.GroupID,(_webContext.PageNumber + 1));
        }

        public void Previous()
        {
            _redirector.GoToGroupsMembers(_webContext.GroupID,(_webContext.PageNumber - 1));
        }

        public void LoadData()
        {
            _view.LoadData(_accountService.GetApprovedAccountsByGroupID(_webContext.GroupID, _webContext.PageNumber, _configuration.NumberOfRecordsInPage),
                           _accountService.GetAccountsToApproveByGroupID(_webContext.GroupID));
        }

        public void ApproveMembers(List<int> MemberIDs)
        {
            _groupMemberService.ApproveGroupMembers(MemberIDs, _webContext.GroupID);
            LoadData();
            _view.ShowMessage("Members approved!");
            _alertService.AddGroupMembershipApprovedAlert(MemberIDs, _webContext.GroupID);
        }

        public void DeleteMembers(List<int> MemberIDs)
        {
            _groupMemberService.DeleteGroupMembers(MemberIDs, _webContext.GroupID);
            LoadData();
            _view.ShowMessage("Members deleted!");
        }

        public void PromoteMembers(List<int> MemberIDs)
        {
            _groupMemberService.PromoteGroupMembersToAdmin(MemberIDs,_webContext.GroupID);
            LoadData();
            _view.ShowMessage("Members promoted!");
        }

        public void DemoteMembers(List<int> MemberIDs)
        {
            _groupMemberService.DemoteGroupMembersFromAdmin(MemberIDs,_webContext.GroupID);
            LoadData();
            _view.ShowMessage("Members demoted!");
        }

        public void Back()
        {
            _redirector.GoToGroupsViewGroup(_webContext.GroupID);
        }
    }
}
