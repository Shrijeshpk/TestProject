﻿using System;
using System.ComponentModel.Composition;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Common;
using Fisharoo.Entities;
using Fisharoo.Interfaces;
using Fisharoo.Web.Groups.Interfaces;

namespace Fisharoo.Web.Groups.Presenters
{
    public class ViewGroupPresenter
    {
        private IViewGroup _view; 
        [Import]
        private IWebContext _webContext;
        [Import]
        private IRedirector _redirector;
        [Import]
        private IBoardForumService _boardForumService;
        [Import]
        private IBoardCategoryService _boardCategoryService;
        [Import]
        private IGroupMemberService _groupMemberService;
        [Import]
        private IGroupService _groupService;
        [Import]
        private IUploadService _uploadService;
        [Import]
        private IAlertService _alertService;

        public ViewGroupPresenter()
        {
            MEFManager.Compose(this);
        }

        public void Init(IViewGroup view, bool IsPostBack, string groupname)
        {
            _view = view;
            if(!IsPostBack)
                LoadData(groupname);
        }

        public void LoadData(string groupname)
        {
            Group group = _groupService.GetGroupByPageName(groupname);

            string url = "/files/photos/" + _uploadService.GetFullFilePathByFileID(group.FileID, File.Sizes.S);
            _view.LoadData(group, url);

            if(_webContext.CurrentUser != null)
                _view.ShowRequestMembership(true);
            else
                _view.ShowRequestMembership(false);

            //is this public or private data?
            if (group.IsPublic)
            {
                _view.ShowPrivate(true);
                _view.ShowPublic(true);
            }
            else if (ViewerIsMember(group.GroupID))
            {
                _view.ShowPrivate(true);
                _view.ShowPublic(true);
            }
            else
            {
                _view.ShowPrivate(false);
                _view.ShowPublic(true);
            }
        }

        public void GoToForum(string groupID)
        {
            BoardForum forum = _boardForumService.GetForumByGroupID(Convert.ToInt32(groupID));
            BoardCategory category = _boardCategoryService.GetCategoryByCategoryID(forum.CategoryID);
            _redirector.GoToForumsForumView(forum.Name,category.Name);
        }

        public void RequestMembership(string groupID)
        {
            Account currentUser = _webContext.CurrentUser as Account;
            if (currentUser != null)
            {
                GroupMember gm = new GroupMember();
                gm.AccountID = currentUser.AccountID;
                gm.GroupID = Convert.ToInt32(groupID);
                gm.CreateDate = DateTime.Now;
                gm.IsAdmin = false;
                gm.IsApproved = false;
                _groupMemberService.SaveGroupMember(gm);
                _view.ShowMessage("Membership requested successfully!");
                _alertService.AddGroupMembershipRequestAlert(gm.AccountID, gm.GroupID, currentUser.Username);
            }
        }

        public void ViewMembers(string groupID)
        {
            _redirector.GoToGroupsMembers(Convert.ToInt32(groupID));
        }

        private bool ViewerIsMember(int groupID)
        {
            bool result = false;
            Account currentUser = _webContext.CurrentUser as Account;
            if (currentUser != null)
            {
                if (_groupService.IsOwner(currentUser.AccountID, groupID))
                    result = true;
                else if (_groupService.IsMember(currentUser.AccountID, groupID))
                    result = true;
            }
            return result;
        }
    }
}
