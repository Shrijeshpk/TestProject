﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Common;
using Fisharoo.Entities;
using Fisharoo.Interfaces;
using Fisharoo.Web.Groups.Interfaces;
using Fisharoo.Web.HelperClasses;

namespace Fisharoo.Web.Groups.Presenters
{
    public class DefaultPresenter
    {
        private IDefault _view;
        [Import]
        private IRedirector _redirector;
        [Import]
        private IWebContext _webContext;
        [Import]
        private IGroupService _groupService;
        [Import]
        private IUploadService _uploadService;

        public DefaultPresenter()
        {
            MEFManager.Compose(this);
        }

        public void Init(IDefault view)
        {
            _view = view;
            List<Group> list = _groupService.GetLatestGroups();
            _view.LoadData(Translator.GroupToPEGroup(list));
        }

        public string GetImageByID(Int64 ImageID, File.Sizes Size)
        {
            return _uploadService.GetFullFilePathByFileID(ImageID, Size);
        }
    }
}
