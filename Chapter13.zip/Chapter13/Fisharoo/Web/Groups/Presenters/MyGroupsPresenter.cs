﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Common;
using Fisharoo.Interfaces;
using Fisharoo.Entities;
using Fisharoo.Web.Groups.Interfaces;
using Fisharoo.Web.HelperClasses;

namespace Fisharoo.Web.Groups.Presenters
{
    public class MyGroupsPresenter
    {
        private IMyGroups _view;
        [Import]
        private IRedirector _redirector;
        [Import]
        private IWebContext _webContext;
        [Import]
        private IGroupService _groupService;
        [Import]
        private IUploadService _uploadService;
        [Import]
        private IBoardForumService _boardForumService;
        [Import]
        private IBoardPostService _boardPostService;
        [Import]
        private IGroupForumService _groupForumService;
        [Import]
        private IGroupMemberService _groupMemberService;

        public MyGroupsPresenter()
        {
            MEFManager.Compose(this);
        }

        public void Init(IMyGroups view)
        {
            _view = view;
            LoadData();
        }

        public void LoadData()
        {
            Account currentUser = _webContext.CurrentUser as Account;
            List<Group> list = _groupService.GetGroupsOwnedByAccount(currentUser.AccountID);
            _view.LoadData(Translator.GroupToPEGroup(list));
        }

        public string GetImageByID(Int64 ImageID, File.Sizes Size)
        {
            return _uploadService.GetFullFilePathByFileID(ImageID, Size);
        }

        public void GoToGroup(string GroupPageName)
        {
            _redirector.GoToGroupsViewGroup(GroupPageName);
        }

        public void DeleteGroup(int GroupID)
        {
            BoardForum forum = _boardForumService.GetForumByGroupID(GroupID);
            if (forum != null)
            {
                _boardPostService.DeletePostsByForumID(forum.ForumID);
                _groupForumService.DeleteGroupForum(forum.ForumID, GroupID);
                _boardForumService.DeleteForum(forum);
            }
            _groupMemberService.DeleteAllGroupMembersForGroup(GroupID);
            _groupService.DeleteGroup(GroupID);
            LoadData();
        }

        public void EditGroup(int GroupID)
        {
            _redirector.GoToGroupsManageGroup(GroupID);
        }
    }
}
