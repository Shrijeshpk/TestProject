﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using Fisharoo.Web.Groups.Interfaces;
using Fisharoo.Web.Groups.Presenters;
using Fisharoo.Web.HelperClasses;
using Fisharoo.Entities;

namespace Fisharoo.Web.Groups
{
    public partial class Default : System.Web.UI.Page, IDefault 
    {
        private DefaultPresenter _presenter;
        protected void Page_Load(object sender, EventArgs e)
        {
            _presenter = new DefaultPresenter();
            _presenter.Init(this);
        }

        public void LoadData(List<PEGroup> groups)
        {
            lvGroups.DataSource = groups;
            lvGroups.DataBind();
        }

        public void ShowMessage(string message)
        {
            lblMessage.Text = message;
        }

        protected void lvGroups_ItemDataBound(object sender, ListViewItemEventArgs e)
        {
            if(e.Item.ItemType == ListViewItemType.DataItem)
            {
                Image imgGroupImage = e.Item.FindControl("imgGroupImage") as Image;
                Literal litImageID = e.Item.FindControl("litImageID") as Literal;
                Literal litPageName = e.Item.FindControl("litPageName") as Literal;
                HyperLink linkPageName = e.Item.FindControl("linkPageName") as HyperLink;
                linkPageName.NavigateUrl = Page.GetRouteUrl("GroupRoute", new { groupname = ((PEGroup)e.Item.DataItem).PageName }); 

                imgGroupImage.ImageUrl = "/files/photos/" + _presenter.GetImageByID(Convert.ToInt64(litImageID.Text),File.Sizes.S);
            }
        }
    }
}
