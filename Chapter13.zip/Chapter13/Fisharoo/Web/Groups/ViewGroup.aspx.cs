﻿using System;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Common;
using Fisharoo.Entities;
using Fisharoo.Web.Groups.Interfaces;
using Fisharoo.Web.Groups.Presenters;

namespace Fisharoo.Web.Groups
{
    public partial class ViewGroup : System.Web.UI.Page, IViewGroup
    {
        private ViewGroupPresenter _presenter;

        protected void Page_Load(object sender, EventArgs e)
        {
            MEFManager.Compose(this);

            _presenter = new ViewGroupPresenter();
            string groupname = Page.RouteData.Values["groupname"] as string;
            _presenter.Init(this, IsPostBack, groupname);
        }

        public void LoadData(Group group, string url)
        {
            ((SiteMaster)Master).Title = group.Name;
            imgGroupLogo.ImageUrl = url;
            litGroupID.Text = group.GroupID.ToString();
            lblCreateDate.Text = group.CreateDate.ToShortDateString();
            lblUpdateDate.Text = group.UpdateDate.ToShortDateString();
            lblDescription.Text = group.Description;
            lblBody.Text = group.Body;
        }

        public void ShowPublic(bool Visible)
        {
            //pnlPublic.Visible = Visible;    
        }

        public void ShowPrivate(bool Visible)
        {
            pnlPrivate.Visible = Visible;
            lblPrivateMessage.Visible = !Visible;
        }

        public void ShowRequestMembership(bool Visible)
        {
            lbRequestMembership.Visible = Visible;
        }

        protected void lbForum_Click(object sender, EventArgs e)
        {
            _presenter.GoToForum(litGroupID.Text);
        }

        protected void lbRequestMembership_Click(object sender, EventArgs e)
        {
            _presenter.RequestMembership(litGroupID.Text);
        }

        public void ShowMessage(string Message)
        {
            lblMessage.Text = Message;
        }

        protected void lbViewMembers_Click(object sender, EventArgs e)
        {
            _presenter.ViewMembers(litGroupID.Text);
        }
    }
}
