﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Web;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Common;
using Fisharoo.Entities;
using Fisharoo.Interfaces;
using Fisharoo.Web.HelperClasses;
using Fisharoo.Web.Mail.Interfaces;

namespace Fisharoo.Web.Mail.Presenters
{
    public class DefaultPresenter
    {
        private IDefault _view;
        [Import]
        private IMessageService _messageService;
        [Import]
        private IMessageRecipientService _messageRecipientService;
        [Import]
        private IUserSession _userSession;
        [Import]
        private IWebContext _webContext;

        public DefaultPresenter()
        {
            MEFManager.Compose(this);
        }

        public void Init(IDefault view)
        {
            _view = view;
            Account currentUser = _userSession.CurrentUser as Account;
            if (currentUser != null)
            {
                List<MessageWithRecipient> list = _messageService.GetMessagesByAccountID(currentUser.AccountID,
                                                                             _webContext.Page, (MessageFolders)_webContext.FolderID);
                _view.LoadMessages(Translator.MessageWithRecipientToPEMessage(list));
                _view.DisplayPageNavigation(_messageService.GetPageCount((MessageFolders) _webContext.FolderID, currentUser.AccountID),
                    (MessageFolders) _webContext.FolderID, _webContext.Page);
            }
        }

        public void DeleteSelected()
        {
            List<Int32> messages = _view.ExtractSelectedMessages();
            Account currentUser = _userSession.CurrentUser as Account;
            foreach (int i in messages)
            {
                MessageWithRecipient m = _messageService.GetMessageByMessageID(i, currentUser.AccountID);
                _messageRecipientService.DeleteMessageRecipient(m.MessageRecipient);
            }
            HttpContext.Current.Response.Redirect("~/mail/default.aspx?folder=" + _webContext.FolderID + "&page=" + _webContext.Page);
        }

        public void MarkSelectedAsUnread()
        {
            List<Int32> messages = _view.ExtractSelectedMessages();
        }
    }
}
