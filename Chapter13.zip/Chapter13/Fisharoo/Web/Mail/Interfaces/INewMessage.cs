﻿using Fisharoo.Entities;

namespace Fisharoo.Web.Mail.Interfaces
{
    public interface INewMessage
    {
        void LoadReply(MessageWithRecipient message);
        void LoadTo(string Username);
    }
}
