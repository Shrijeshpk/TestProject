﻿using Fisharoo.Entities;

namespace Fisharoo.Web.Mail.Interfaces
{
    public interface IReadMessage
    {
        void LoadMessage(MessageWithRecipient message);
    }
}
