﻿using System;
using System.Collections.Generic;
using Fisharoo.Entities;
using Fisharoo.Web.HelperClasses;

namespace Fisharoo.Web.Mail.Interfaces
{
    public interface IDefault
    {
        void LoadMessages(List<PEMessage> Messages);
        List<Int32> ExtractSelectedMessages();
        void DisplayPageNavigation(Int32 PageCount, MessageFolders folder, Int32 CurrentPage);
    }
}
