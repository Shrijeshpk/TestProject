﻿using System;
using Fisharoo.Web.Mail.Interfaces;
using Fisharoo.Web.Mail.Presenters;
using Fisharoo.Entities;

namespace Fisharoo.Web.Mail
{
    public partial class NewMessage : System.Web.UI.Page, INewMessage 
    {
        private NewMessagePresenter _presenter;
        protected void Page_Load(object sender, EventArgs e)
        {
            _presenter = new NewMessagePresenter();
            _presenter.Init(this, IsPostBack);
        }

        protected void btnSend_Click(object sender, EventArgs e)
        {
            string[] to = txtTo.Text.Split(new char[] {',', ';'});
            _presenter.SendMessage(txtSubject.Text,txtMessage.Text,to);

            pnlSendMessage.Visible = false;
            pnlSent.Visible = true;
        }

        public void LoadReply(MessageWithRecipient message)
        {
            txtSubject.Text = "RE: " + message.Message.Subject;
            txtTo.Text = message.Sender.Username;
            txtMessage.Text = "<BR><BR><HR>Sent On: " + message.Message.CreateDate.ToString() + "<BR>Subject: " + message.Message.Subject + "<BR>Message: " + message.Message.Body;
        }

        public void LoadTo(string Username)
        {
            txtTo.Text = Username;
        }
    }
}
