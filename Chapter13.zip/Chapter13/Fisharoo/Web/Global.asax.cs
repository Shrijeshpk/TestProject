﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.SessionState;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.IO;
using Fisharoo.Common;
using Fisharoo.Interfaces;
using System.Web.Routing;


namespace Fisharoo.Web
{
    public class Global : System.Web.HttpApplication
    {
        [Import]
        public IRedirector redir;

        [Import]
        public ILogger log;

        void Application_Start(object sender, EventArgs e)
        {
            // Code that runs on application startup
            MEFManager.Compose(this);
            log.EnsureInitialized();
            RegisterRoutes(RouteTable.Routes);
        }

        public static void RegisterRoutes(RouteCollection routeCollection)
        {
            //CHAPTER 4
            //friendly URL for direct profile access - http://server/appname/profiles/username
            routeCollection.MapPageRoute("ProfileRoute", "profiles/{username}", "~/Profiles/Profile.aspx");
            
            //CHAPTER 8
            //friendly url for direct blog access - http://server/appname/blogs/username/blogpage
            routeCollection.MapPageRoute("BlogRoute", "blogs/{username}/{blogpage}.aspx", "~/Blogs/ViewPost.aspx");

            //CHAPTER 9
            //friendly URL for new forum post - http://server/appname/forums/categoryname/forumname.aspx/new
            routeCollection.MapPageRoute("NewThreadRoute", "forum/{categoryname}/{forumname}.aspx/new", "~/Forums/Post.aspx");
            //friendly URL for reply to a thread/post - http://server/appname/forums/categoryname/forumname.aspx/postid/reply
            routeCollection.MapPageRoute("ReplyThreadRoute", "forums/{categoryname}/{forumname}.aspx/{postid}/reply", "~/Forums/Post.aspx");
            //friendly URL for direct thread/post access - http://server/appname/forums/categoryname/forumname/postid
            routeCollection.MapPageRoute("ThreadRoute", "forums/{categoryname}/{forumname}.aspx/{postid}", "~/Forums/ViewPost.aspx");
            //friendly URL for forum access - http://server/appname/forums/categoryname/forumname.aspx
            routeCollection.MapPageRoute("ForumRoute", "forums/{categoryname}/{forumname}.aspx", "~/Forums/ViewForum.aspx");

            //CHAPTER 10
            routeCollection.MapPageRoute("GroupRoute", "groups/{groupname}.aspx", "~/Groups/ViewGroup.aspx");

            //CHAPTER 11
            //friendly URL for direct tag access - http://server/appname/tags/tagname
            routeCollection.MapPageRoute("TagRoute", "tags/{tagname}", "~/Tags/Tags.aspx");
        }

        void Application_End(object sender, EventArgs e)
        {
            //  Code that runs on application shutdown

        }

        void Application_Error(object sender, EventArgs e)
        {
            // Code that runs when an unhandled error occurs
            
            //Initializing MEF container
            MEFManager.Compose(this);
            
            log.Error(sender, "Error caught by the Global.asax: " + Server.GetLastError().Message);
            redir.GoToErrorPage();
        }

        void Session_Start(object sender, EventArgs e)
        {
            // Code that runs when a new session is started

        }

        void Session_End(object sender, EventArgs e)
        {
            // Code that runs when a session ends. 
            // Note: The Session_End event is raised only when the sessionstate mode
            // is set to InProc in the Web.config file. If session mode is set to StateServer 
            // or SQLServer, the event is not raised.

        }

    }
}
