using System.Collections.Generic;
using Fisharoo.Entities;
//using Fisharoo.Web.AccountProxy;

namespace Fisharoo.Web.Interfaces
{
    public interface ISearch
    {
        void LoadAccounts(List<Account> Accounts);
    }
}