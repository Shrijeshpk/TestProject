﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fisharoo.Web.HelperClasses
{
    public class PEGroup
    {
        public string Name { get; set; }
        public string PageName { get; set; }
        public string FileID { get; set; }
        public string GroupID { get; set; }

        public PEGroup(string n, string pName, long ID, int gID)
        {
            Name = n;
            PageName = pName;
            FileID = ID.ToString();
            GroupID = gID.ToString();
        }
    }
}