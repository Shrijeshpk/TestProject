﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fisharoo.Web.HelperClasses
{
    public class PEBoardForum
    {
        public string Name { get; set; }
        public string Subject { get; set; }
        public long ThreadCount { get; set; }
        public long PostCount { get; set; }
        public string LastPostByUsername { get; set; }
        public string LastPostDate { get; set; }
        public string PageName { get; set; }
        public string CategoryName { get; set; }

        public PEBoardForum(string n, string sub, long tCount, long pCount, string postBy, DateTime date, string pgName, string categoryName) 
        {
            Name = n;
            Subject = sub;
            ThreadCount = tCount;
            PostCount = PostCount;
            LastPostByUsername = postBy;
            LastPostDate = date.ToShortDateString();
            PageName = pgName;
            CategoryName = categoryName;
        }
    }
}