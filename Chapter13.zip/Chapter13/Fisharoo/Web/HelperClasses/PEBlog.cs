﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fisharoo.Web.HelperClasses
{
    public class PEBlog
    {
        public string Title { get; set; }
        public string Username { get; set; }
        public string CreateDate { get; set; }
        public string BlogID { get; set; }
        public string PageName { get; set; }
        public string Subject { get; set; }

        public PEBlog(string t, string name, DateTime dt, long ID, string pgName, string sub)
        {
            Title = t;
            Username = name;
            CreateDate = dt.ToString();
            BlogID = ID.ToString();
            PageName = pgName;
            Subject = sub;
        }
    }
}