﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Drawing;
using System.IO;
using System.Web;
using Fisharoo.Common;
using Fisharoo.Entities;
using Fisharoo.Interfaces;
using File = Fisharoo.Entities.File;
using Fisharoo.BusinessLogic.Interfaces;

namespace Fisharoo.Web.HelperClasses
{
    public class FileProcessor
    {
        public string ImageFolder = "";

        Dictionary<string, int> sizesToMake = new Dictionary<string, int>();
        private int sizeTiny = 50;
        private int sizeSmall = 200;
        private int sizeMedium = 500;
        private int sizeLarge = 1000;

        [Import]
        private IUserSession _userSession;
        [Import]
        private IWebContext _webContext;
        [Import]
        private IFileService _fileService;
        [Import]
        private IAccountService _accountService;

        int NewWidth = 0;
        int NewHeight = 0;

        string saveToFolder = "files";

        public void Process(string filePath)
        {
            MEFManager.Compose(this);
            FileInfo F = new FileInfo(filePath);

            sizesToMake.Add("T", sizeTiny);
            sizesToMake.Add("S", sizeSmall);
            sizesToMake.Add("M", sizeMedium);
            sizesToMake.Add("L", sizeLarge);

            //determine save to folder (currently running in context of Handlers folder
            switch (_webContext.FileTypeID)
            //switch (1)
            {
                case 1:
                    saveToFolder = "../Files/Photos/";
                    break;

                case 2:
                    saveToFolder = "../Files/Videos/";
                    break;

                case 3:
                    saveToFolder = "../Files/Audios/";
                    break;
            }
            

            //make sure the directory is ready for use
            saveToFolder += DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString() + "/";
            if (!Directory.Exists(HttpContext.Current.Server.MapPath(saveToFolder)))
                Directory.CreateDirectory(HttpContext.Current.Server.MapPath(saveToFolder));

            Account account = _accountService.GetAccountByID(_webContext.AccountID);

            //HttpFileCollection uploadedFiles = Request.Files;

            string Path = HttpContext.Current.Server.MapPath(saveToFolder);
            //for (int i = 0; i < uploadedFiles.Count; i++)
            {
                //HttpPostedFile F = uploadedFiles[i];
                //if (uploadedFiles[i] != null && F.ContentLength > 0)
                if(F.Length > 0)
                {
                    string folderID = _webContext.AlbumID.ToString();
                    string fileType = "1";
                    string uploadedFileName = F.Name; //F.FileName.Substring(F.FileName.LastIndexOf("\\") + 1);
                    string extension = F.Extension;// uploadedFileName.Substring(uploadedFileName.LastIndexOf(".") + 1);
                    Guid guidName = Guid.NewGuid();
                    //string fullFileName = Path + "/" + guidName.ToString() + "__O." + extension;
                    string fullFileName = Path + guidName.ToString() + "__O" + extension;
                    bool goodFile = true;

                    //create the file

                    File fileEntity = new File();

                    #region "Determine file type"
                    switch (fileType)
                    {
                        case "1":
                            fileEntity.FileSystemFolderID = (int)FileSystemFolder.Paths.Photos;
                            switch (extension.ToLower())
                            {
                                case ".jpg":
                                    fileEntity.FileTypeID = (int)File.Types.JPG;
                                    break;
                                case ".gif":
                                    fileEntity.FileTypeID = (int)File.Types.GIF;
                                    break;
                                case ".jpeg":
                                    fileEntity.FileTypeID = (int)File.Types.JPEG;
                                    break;
                                default:
                                    goodFile = false;
                                    break;
                            }
                            break;

                        case "2":
                            fileEntity.FileSystemFolderID = (int)FileSystemFolder.Paths.Videos;
                            switch (extension.ToLower())
                            {
                                case ".wmv":
                                    fileEntity.FileTypeID = (int)File.Types.WMV;
                                    break;
                                case ".flv":
                                    fileEntity.FileTypeID = (int)File.Types.FLV;
                                    break;
                                case ".swf":
                                    fileEntity.FileTypeID = (int)File.Types.SWF;
                                    break;
                                default:
                                    goodFile = false;
                                    break;
                            }
                            break;

                        case "3":
                            fileEntity.FileSystemFolderID = (int)FileSystemFolder.Paths.Audios;
                            switch (extension.ToLower())
                            {
                                case ".wav":
                                    fileEntity.FileTypeID = (int)File.Types.WAV;
                                    break;
                                case ".mp3":
                                    fileEntity.FileTypeID = (int)File.Types.MP3;
                                    break;
                                case ".flv":
                                    fileEntity.FileTypeID = (int)File.Types.FLV;
                                    break;
                                default:
                                    goodFile = false;
                                    break;
                            }
                            break;
                    }
                    #endregion

                    fileEntity.Size = F.Length;// F.ContentLength;
                    fileEntity.AccountID = account.AccountID;
                    fileEntity.DefaultFolderID = Convert.ToInt32(folderID);
                    fileEntity.FileName = uploadedFileName;
                    fileEntity.FileSystemName = guidName;
                    fileEntity.Description = "";
                    fileEntity.IsPublicResource = false;

                    if (goodFile)
                    {
                        _fileService.SaveFile(fileEntity);

                        F.MoveTo(fullFileName);
                        //F.SaveAs(fullFileName);

                        if (Convert.ToInt32(fileType) == ((int)Folder.Types.Photo))
                        {
                            Resize(F, saveToFolder, guidName, extension);
                        }
                    }
                }
            }
        }

        //public void Resize(HttpPostedFile F, string SaveToFolder, Guid SystemFileNamePrefix, string Extension)
        public void Resize(FileInfo F, string SaveToFolder, Guid SystemFileNamePrefix, string Extension)
        {
            //Makes all the different sizes in the sizesToMake collection
            foreach (KeyValuePair<string, int> pair in sizesToMake)
            {
                //using (System.Drawing.Image image = System.Drawing.Image.FromStream(F.InputStream))
                //determine the thumbnail sizes
                //using (Bitmap bitmap = new Bitmap(image))
                using (Bitmap bitmap = new Bitmap(F.FullName))
                {
                    decimal Ratio;
                    if (bitmap.Width > bitmap.Height)
                    {
                        Ratio = (decimal)pair.Value / bitmap.Width;
                        NewWidth = pair.Value;
                        decimal Temp = bitmap.Height * Ratio;
                        NewHeight = (int)Temp;
                    }
                    else
                    {
                        Ratio = (decimal)pair.Value / bitmap.Height;
                        NewHeight = pair.Value;
                        decimal Temp = bitmap.Width * Ratio;
                        NewWidth = (int)Temp;
                    }
                }

                //using (System.Drawing.Image image = System.Drawing.Image.FromStream(F.InputStream))
                using (Image image = Image.FromFile(F.FullName))
                {
                    using (Bitmap bitmap = new Bitmap(image, NewWidth, NewHeight))
                    {
                        //bitmap.Save(HttpContext.Current.Server.MapPath(SaveToFolder + "/" + SystemFileNamePrefix.ToString() + "__" + pair.Key + "." + Extension), image.RawFormat);
                        bitmap.Save(HttpContext.Current.Server.MapPath(SaveToFolder + SystemFileNamePrefix.ToString() + "__" + pair.Key + Extension), image.RawFormat);
                    }
                }
            }
        }
    }
}