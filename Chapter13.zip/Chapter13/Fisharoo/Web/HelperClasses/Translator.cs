﻿using System.Collections.Generic;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Interfaces;
using Fisharoo.Entities;

namespace Fisharoo.Web.HelperClasses
{
    public class Translator
    {
        //CHAPTER 5
        public static List<PEStatusUpdate> StateUpdateToPEStatusUpdate(List<StatusUpdate> stList)
        {
            List<PEStatusUpdate> peList = new List<PEStatusUpdate>();
            foreach (StatusUpdate item in stList)
            {
                peList.Add(new PEStatusUpdate(item.CreateDate, item.Status));
            }
            return peList;
        }

        //CHAPTER 6
        public static List<PEMessage> MessageWithRecipientToPEMessage(List<MessageWithRecipient> msgList)
        {
            List<PEMessage> peList = new List<PEMessage>();
            foreach (MessageWithRecipient item in msgList)
            {
                peList.Add(new PEMessage(item.Sender.Username, item.Message.Subject, item.Message.MessageID));
            }
            return peList;
        }

        //CHAPTER 7
        public static List<PEFolder> FolderToPEFolder(List<Folder> fldrList)
        {
            List<PEFolder> peList = new List<PEFolder>();
            foreach (Folder item in fldrList)
            {
                peList.Add(new PEFolder(item.Name, item.Username, item.Location, item.Description, item.FolderID, item.FullPathToCoverImage));
            }
            return peList;
        }

        //CHAPTER 7
        public static List<PEFile> FileToPEFile(List<File> fileList)
        {
            List<PEFile> peList = new List<PEFile>();
            foreach (File item in fileList)
            {
                peList.Add(new PEFile(item.FileName, item.Description, item.CreateDate, item.FileSystemName, item.FileID, item.Extension));
            }
            return peList;
        }

        //CHAPTER 7
        public static PEWebContext WebContextToPEWebContext(IWebContext _webContext, Folder.Types type)
        {
            Account currentUser = _webContext.CurrentUser as Account;
            PEWebContext ctx = new PEWebContext(
                                    _webContext.RootUrl, _webContext.AlbumID, type, currentUser.AccountID );
            return ctx;
        }

        //CHAPTER 8
        public static List<PEBlog> BlogToPEBlog(List<Blog> blogList)
        {
            List<PEBlog> peList = new List<PEBlog>();
            foreach (Blog item in blogList)
            {
                peList.Add(new PEBlog(item.Title, item.Account.Username, item.CreateDate, item.BlogID, item.PageName, item.Subject));
            }
            return peList;
        }

        //CHAPTER 9
        public static List<PEBoardCategory> BoardCategoryToPEBoardCategory(List<BoardCategory> boardList)
        {
            List<PEBoardCategory> peList = new List<PEBoardCategory>();
            foreach (BoardCategory item in boardList)
            {
                List<PEBoardForum> frList = Translator.BoardForumToPEBoardForum(item.Forums, item.Name);
                peList.Add(new PEBoardCategory(item.Name, item.Subject, 
                                item.ThreadCount, item.PostCount, item.LastPostByUsername, item.LastPostDate,
                                frList));
            }
            return peList;
        }

        //CHAPTER 9
        public static List<PEBoardForum> BoardForumToPEBoardForum(List<BoardForum> forumList, string categoryName)
        {
            List<PEBoardForum> peList = new List<PEBoardForum>();
            foreach (BoardForum item in forumList)
            {
                peList.Add(new PEBoardForum(item.Name, item.Subject, item.ThreadCount, item.PostCount, item.LastPostByUsername, item.LastPostDate, item.PageName, categoryName));
            }
            return peList;
        }

        //CHAPTER 11. Added accountservice parameter
        //CHAPTER 9
        public static List<PEBoardPost> BoardPostToPEBoardPost(List<BoardPost> boardList, IAccountService _accountService, bool displayMarkAnswer = false)
        {
            List<PEBoardPost> peList = new List<PEBoardPost>();
            foreach (BoardPost item in boardList)
            {
                int Score = _accountService.GetAccountByID(item.AccountID).Score;
                peList.Add(new PEBoardPost(item.Name, item.Username, item.AccountID, item.CreateDate, 
                    item.UpdateDate, item.PostID, item.ViewCount, item.ReplyCount, item.VoteCount, item.IsAnswer,
                    item.ReplyByUsername, item.ReplyByAccountID, item.Post, item.PageName, item.AccountID, displayMarkAnswer, Score));
            }
            return peList;
        }

        //CHAPTER 9
        public static PEBoardPost BoardPostToPEBoardPost(BoardPost bp, int Score)
        {
            PEBoardPost pe = new PEBoardPost(bp.Name, bp.Username, bp.AccountID, bp.CreateDate,
                        bp.UpdateDate, bp.PostID, bp.ViewCount, bp.ReplyCount, bp.VoteCount, bp.IsAnswer, bp.ReplyByUsername,
                        bp.ReplyByAccountID, bp.Post, bp.PageName, bp.AccountID, false, Score);
            
            return pe;
        }

        //CHAPTER 10
        public static List<PEGroup> GroupToPEGroup(List<Group> groupList)
        {
            List<PEGroup> peList = new List<PEGroup>();
            foreach (Group item in groupList)
            {
                peList.Add(new PEGroup(item.Name, item.PageName, item.FileID, item.GroupID));
            }
            return peList;
        }

        //CHAPTER 11
        public static List<PESystemObjectRatingOption> SystemObjectRatingOptionTOPESystemObjectRatingOption(List<SystemObjectRatingOption> sysList)
        {
            List<PESystemObjectRatingOption> peList = new List<PESystemObjectRatingOption>();
            foreach (SystemObjectRatingOption item in sysList)
            {
                peList.Add(new PESystemObjectRatingOption(item.Name, item.Description, item.SystemObjectRatingOptionID));
            }
            return peList;
        }

        public static List<PESystemObjectTagWithObject> SystemObjectTagWithObjectToPESystemObjectTagWithObject(List<SystemObjectTagWithObject> sysList)
        {
            List<PESystemObjectTagWithObject> peList = new List<PESystemObjectTagWithObject>();
            foreach (SystemObjectTagWithObject item in sysList)
            {
                peList.Add(new PESystemObjectTagWithObject(item.File.FileName, item.Folder.Name, item.File.DefaultFolderID, item.File.CreateDate, item.File.FileSystemName, item.File.Extension, item.SystemObjectTag.SystemObjectID));
            }
            return peList;
        }

        public static List<string> AccountsToUserNames(List<Account> accList)
        {
            List<string> peList = new List<string>();
            foreach (Account item in accList)
            {
                peList.Add(item.Username);
            }
            return peList;
        }
    }
}