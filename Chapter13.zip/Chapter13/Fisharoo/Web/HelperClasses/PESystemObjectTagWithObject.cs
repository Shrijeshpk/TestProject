﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fisharoo.Web.HelperClasses
{
    public class PESystemObjectTagWithObject
    {
        public string FileName { get; set; }
        public string FolderName { get; set; }
        public string DefaultFolderID { get; set; }
        public string URL { get; set; }
        public int SystemObjectID { get; set; }

        public PESystemObjectTagWithObject(string file, string folder, long folderID, DateTime date, Guid fileSysName, string extn, int sysID)
        {
            FileName = file;
            FolderName = folder;
            DefaultFolderID = folderID.ToString();
            URL = date.Year.ToString() + date.Month.ToString() + "/" + fileSysName + "__O." + extn;
            SystemObjectID = sysID;                 
        }
    }
}