﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fisharoo.Web.HelperClasses
{
    public class PESystemObjectRatingOption
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string SystemObjectRatingOptionID { get; set; }

        public PESystemObjectRatingOption(string n, string desc, int ID)
        {
            Name = n;
            Description = desc;
            SystemObjectRatingOptionID = ID.ToString();
        }
    }
}