﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fisharoo.Web.HelperClasses
{
    //CHAPTER 9
    public class PEBoardCategory
    {
        public string Name { get; set; }
        public string Subject { get; set; }
        public int ThreadCount { get; set; }
        public int PostCount { get; set; }
        public string LastPostByUsername { get; set; }
        public string LastPostDate { get; set; }
        public List<PEBoardForum> Forums { get; set; }

        public PEBoardCategory(string n, string sub, int tCount, int pCount, string postBy, DateTime date, List<PEBoardForum> list)
        {
            Name = n;
            Subject = sub;
            ThreadCount = tCount;
            PostCount = pCount;
            LastPostByUsername = postBy;
            LastPostDate = date.ToShortDateString();
            Forums = list;
        }

    }
}