﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fisharoo.Web.HelperClasses
{
    public class PEMessage
    {
        public string Username { get; set; }
        public long MessageID { get; set; }
        public string Subject { get; set; }

        public PEMessage(string user, string sub, long ID)
        {
            Username = user;
            Subject = sub;
            MessageID = ID;
        }
    }
}