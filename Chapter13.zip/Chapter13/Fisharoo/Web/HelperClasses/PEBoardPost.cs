﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.Composition;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Common;

namespace Fisharoo.Web.HelperClasses
{
    public class PEBoardPost
    {
        public string Username { get; set; }
        public string AccountID { get; set; }
        public string CreateDate { get; set; }
        public string UpdateDate { get; set; }
        public long PostID { get; set; }
        public int ViewCount { get; set; }
        public int ReplyCount { get; set; }
        //CHAPTER 11
        public int VoteCount { get; set; }
        public bool IsAnswer { get; set; }
        public int Score { get; set; }
        public bool DisplayMarkAnswer { get; set; }

        public string ReplyByUsername { get; set; }
        public string ReplyByAccountID { get; set; }
        public string PageName { get; set; }

        //CHAPTER 12
        [Import]
        IContentFilterService _contentFilterService;
        private string _name;
        public string Name
        {
            get { return _contentFilterService.Filter(_name); }
            set { _name = value; }
        }

        private string _post;
        public string Post
        {
            get { return _contentFilterService.Filter(_post); }
            set { _post = value; }
        }
        
        public PEBoardPost(string n, string u, int aID, DateTime cDate, DateTime uDate, long pID, int vCount, int rCount, int voteCount, bool isAnswer, string r, int? rID, string post, string pgName, int accID, bool display = false, int score = 0)
        {
            MEFManager.Compose(this);

            Name = n;
            Username = u;
            AccountID = aID.ToString();
            CreateDate = cDate.ToString();
            UpdateDate = uDate.ToString();
            PostID = pID;
            ViewCount = vCount;
            ReplyCount = rCount;
            
            VoteCount = voteCount;
            IsAnswer = isAnswer;
            Score = score;
            DisplayMarkAnswer = display;

            ReplyByUsername = r;
            ReplyByAccountID = rID.HasValue? rID.Value.ToString(): "";
            Post = post;
            PageName = pgName;
        }
    }
}