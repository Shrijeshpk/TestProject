﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fisharoo.Web.HelperClasses
{
    public class PEStatusUpdate
    {
        public DateTime CreateDate { get; set; }
        public string Status { get; set; }

        public PEStatusUpdate(DateTime dt, string msg)
        {
            CreateDate = dt;
            Status = msg;
        }
    }
}