﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fisharoo.Web.HelperClasses
{
    public class PEFolder
    {
        public string Name { get; set; }
        public string Username { get; set; }
        public string Location { get; set; }
        public string Description { get; set; }
        public string FolderID { get; set; }
        public string FullPathToCoverImage { get; set; }

        public PEFolder(string name, string user, string loc, string desc, long ID, string path)
        {
            Name = name;
            Username = user;
            Location = loc;
            Description = desc;
            FolderID = ID.ToString();
            FullPathToCoverImage = path;
        }
    }
}