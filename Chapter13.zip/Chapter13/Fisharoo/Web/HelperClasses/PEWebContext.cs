﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Fisharoo.Entities;

namespace Fisharoo.Web.HelperClasses
{
    public class PEWebContext
    {
        public string RootUrl { get; set; }
        public string AlbumID { get; set; }
        public int FolderType { get; set; }
        public string AccountID { get; set; }

        public PEWebContext(string url, long albID, Folder.Types type, int accID)
        {
            RootUrl = url;
            AlbumID = albID.ToString();
            FolderType = (int)type;
            AccountID = accID.ToString();
        }
    }
}