﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Fisharoo.Web.HelperClasses
{
    public class PEFile
    {
        public string FileName { get; set; }
        public string Description { get; set; }
        public string Year { get; set; }
        public string Month { get; set; }
        public string FileSystemName { get; set; }
        public string FileID { get; set; }
        public string Extension { get; set; }

        public PEFile(string file, string desc, DateTime date, Guid sysName, long ID, string extn)
        {
            FileName = file;
            Description = desc;
            Year = date.Year.ToString();
            Month = date.Month.ToString();
            FileSystemName = sysName.ToString();
            FileID = ID.ToString();
            Extension = extn;
        }
    }
}