﻿using System;
using System.ComponentModel.Composition;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Common;
using Fisharoo.Interfaces;
using Fisharoo.Entities;

namespace Fisharoo.Web.Images.ProfileAvatar
{
    public partial class ProfileImage : System.Web.UI.Page
    {
        [Import]
        private IUserSession _userSession;
        [Import]
        private IAccountService _accountService;
        [Import]
        private IWebContext _webContext;

        private Int32 accountID;
        private Account account;
        private Profile profile;
        private string gravatarURL;
        private string defaultAvatar;
        private bool showGravatar;

        protected void Page_Load(object sender, EventArgs e)
        {
            MEFManager.Compose(this);

            //load an image by passed in accountid
            if (_webContext.AccountID > 0)
            {
                accountID = _webContext.AccountID;
                account = _accountService.GetAccountByID(accountID);
            }
            //get an image for the current user
            else
            {
                if (_userSession.LoggedIn && _userSession.CurrentUser != null)
                {
                    account = _userSession.CurrentUser as Account;
                }
            }

            //if account is not obtained, cannot proceed further
            if (account == null)
            {
                Response.Redirect("~/Images/ProfileAvatar/Male.jpg");
            }

            profile = account.Profile;

            //show the appropriate image
            if (_webContext.ShowGravatar || (profile != null && profile.UseGravatar == 1))
            {
                Response.Redirect(GetGravatarURL());
            }
            else if (profile != null && profile.Avatar != null)
            {
                Response.Clear();
                Response.ContentType = profile.AvatarMimeType;
                Response.BinaryWrite(profile.Avatar);
            }
            else
            {
                Response.Redirect("~/Images/ProfileAvatar/Male.jpg");
            }
        }

        public string GetGravatarURL()
        {
            defaultAvatar = Server.UrlPathEncode(_webContext.RootUrl + "Images/ProfileAvatar/Male.jpg");

            gravatarURL = "http://www.gravatar.com/avatar.php?";
            gravatarURL += "gravatar_id=" + account.Email.ToMD5Hash();
            gravatarURL += "&rating=r";
            gravatarURL += "&size=80";
            gravatarURL += "&default=" + defaultAvatar;
            return gravatarURL;
        }
    }
}
