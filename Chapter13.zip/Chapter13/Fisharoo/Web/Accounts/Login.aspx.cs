﻿using System;
using Fisharoo.Web.Accounts.Interfaces;
using Fisharoo.Web.Accounts.Presenters;

namespace Fisharoo.Web.Accounts
{
    public partial class Login : System.Web.UI.Page, ILogin
    {
        private LoginPresenter _presenter;
        protected void Page_Load(object sender, EventArgs e)
        {
            _presenter = new LoginPresenter();
            _presenter.Init(this);
        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            _presenter.Login(txtUsername.Text, txtPassword.Text);
        }

        protected void lbRecoverPassword_Click(object sender, EventArgs e)
        {
            _presenter.GoToRecoverPassword();
        }

        protected void lbRegister_Click(object sender, EventArgs e)
        {
            _presenter.GoToRegister();
        }

        public void DisplayMessage(string Message)
        {
            lblMessage.Text = Message;
        }
    }
}
