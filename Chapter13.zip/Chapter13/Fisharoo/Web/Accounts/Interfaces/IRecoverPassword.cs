namespace Fisharoo.Web.Accounts.Interfaces
{
    public interface IRecoverPassword
    {
        void ShowMessage(string Message);
        void ShowRecoverPasswordPanel(bool Value);
    }
}