using Fisharoo.Entities;
//using Fisharoo.Web.AccountProxy;

namespace Fisharoo.Web.Accounts.Interfaces
{
    public interface IRegister
    {
        void ShowErrorMessage(string Message);
        void ShowAccountCreatedPanel();
        void ShowCreateAccountPanel();
        void ToggleWizardIndex(int index);
        void LoadTerms(Term term);
        void LoadreCaptchaSetting(bool value);
        void LoadEmailAddressFromFriendInvitation(string Email);
    }
}