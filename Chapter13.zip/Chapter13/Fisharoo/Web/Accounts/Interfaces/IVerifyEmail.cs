namespace Fisharoo.Web.Accounts.Interfaces
{
    public interface IVerifyEmail
    {
        void ShowMessage(string Message);
    }
}