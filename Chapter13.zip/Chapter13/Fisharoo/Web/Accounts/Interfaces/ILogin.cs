namespace Fisharoo.Web.Accounts.Interfaces
{
    public interface ILogin
    {
        void DisplayMessage(string Message);
    }
}