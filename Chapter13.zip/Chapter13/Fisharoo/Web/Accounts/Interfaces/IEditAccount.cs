using Fisharoo.Web.AccountProxy;
using Fisharoo.Entities;
namespace Fisharoo.Web.Accounts.Interfaces
{
    public interface IEditAccount
    {
        void ShowMessage(bool Success, string Message, string userName);
        void LoadCurrentInformation(Account account);
    }
}