﻿using System;
using System.ComponentModel.Composition;
using Fisharoo.Common;
//using Fisharoo.DataAccess.Interfaces; //commented for SoA use case implementation
using Fisharoo.Interfaces;
using Fisharoo.Web.Accounts.Interfaces;
using Fisharoo.BusinessLogic.Interfaces; 
using Fisharoo.Web.AccountProxy;
using Fisharoo.Entities;


namespace Fisharoo.Web.Accounts.Presenters
{
    public class EditAccountPresenter
    {
        private Account account;
        private IEditAccount _view;
        [Import]
        private IUserSession _userSession;
        
        private AccountProxy.AccountServiceClient _accountService;

        [Import]
        private IRedirector _redirector;
        [Import]
        private IEmail _email;

        public EditAccountPresenter()
        {
            MEFManager.Compose(this);
        }

        public void Init(IEditAccount View, bool IsPostBack)
        {
            _view = View;

            if (_userSession.CurrentUser != null)
                account = _userSession.CurrentUser as Account;
            else 
                _redirector.GoToAccountLoginPage();

            if(!IsPostBack)
                LoadCurrentUser();
        }

        private void LoadCurrentUser()
        {
            Account currentUser = _userSession.CurrentUser as Account;
            _view.LoadCurrentInformation(currentUser);
        }

        public void UpdateAccount(string OldPassword, string NewPassword, string Username,
            string FirstName, string LastName, string Email, 
            string ZipCode, DateTime BirthDate)
        {
            //verify that this user is the same as the logged in user
            
            if (OldPassword.Encrypt(account.Username) == account.Password)
            {
                Account currentUser = _userSession.CurrentUser as Account;
                if (Email != currentUser.Email)
                {
                    if (!_accountService.EmailInUse(Email))
                    {
                        account.Email = Email;
                        //for development disable sending emails, so setting the following to true
                        //in production this will be set to false
#if DEBUG
                        account.EmailVerified = true;
#else
                        account.EmailVerified = false;
#endif
                        _email.SendEmailAddressVerificationEmail(account.Username, Email);                        
                    }
                    else
                    {
                        _view.ShowMessage(false, "The email you have entered is already in our system!", account.Username);
                        return;
                    }
                }

                if (!string.IsNullOrEmpty(NewPassword))
                    account.Password = NewPassword.Encrypt(account.Username);

                account.FirstName = FirstName;
                account.LastName = LastName;

                account.Zip = ZipCode;
                account.BirthDate = BirthDate;
                account.LastUpdateDate = DateTime.Now;
                _accountService.SaveAccount(account);
                _view.ShowMessage(true, "Your account has been updated!", account.Username);
            }
            else
            {
                _view.ShowMessage(false, "The password you entered doesn't match your current password!  Please try again.", account.Username);
            }
        }
    }
}
