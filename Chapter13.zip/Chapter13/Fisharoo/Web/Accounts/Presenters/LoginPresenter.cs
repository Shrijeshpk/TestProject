﻿// Account type is now referred to from the AccountProxy class
using System; //proxy for Account WCF Service
using System.ComponentModel.Composition;
using Fisharoo.Common;
using Fisharoo.Entities;
using Fisharoo.Interfaces;
using Fisharoo.Web.AccountProxy;
using Fisharoo.Web.Accounts.Interfaces;
using Fisharoo.Web.FriendProxy;

namespace Fisharoo.Web.Accounts.Presenters
{
    public class LoginPresenter
    {
        private ILogin _view;

        //This import is commented for WCF Service Implementation
        //[Import]
        //private IAccountService _accountService;
        private AccountProxy.AccountServiceClient _accountService;



        [Import]
        private IUserSession _userSession;
        [Import]
        private IRedirector _redirector;
        [Import]
        private IWebContext _webContext;
        //CHAPTER 13 //Commented for WCF Service implementation
        //[Import]
        //private IFriendService _friendService;
        
        //new bcoz of Service Implementation
        private FriendProxy.FriendServiceClient _friendService;
        [Import]
        private IEmail _email;

        public void Init(ILogin view)
        {
            _view = view;
            MEFManager.Compose(this);

            //CHAPTER 5
            if (!string.IsNullOrEmpty(_webContext.FriendshipRequest))
                _view.DisplayMessage("Login to add this friend!");

            _accountService = new AccountServiceClient();
            _friendService = new FriendServiceClient();

        }

        private void copyAccountAttributes(Account act, Account frndAct)
        {
            //copy attributes from act to frndAct 
        }

        public void Login(string username, string password)
        {
            
            Account account = _accountService.Login(username, password, false);
            //CHAPTER 13
            if (account != null)
            {
                if (account.EmailVerified)
                {
                    _userSession.LoggedIn = true;
                    _userSession.Username = username;
                    _userSession.CurrentUser = account;
                    

                    //CHAPTER 5
                    if (!string.IsNullOrEmpty(_webContext.FriendshipRequest))
                    {

                        if (!_friendService.CreateFriendFromFriendInvitation(new Guid(_webContext.FriendshipRequest), account, true))
                        //if (!_friendService.CreateFriendFromFriendInvitation(new Guid(_webContext.FriendshipRequest), tempaccount, true))
                        {
                            _view.DisplayMessage(@"The Friend invitation is not meant for the account 
                                                you are logging in with. Kindly login with the right account");
                        }
                    }

                    //CHAPTER 4
                    //added this check to redirect to profile if it is not yet filled out
                    Account currentUser = _userSession.CurrentUser as Account;
                    if (currentUser.Profile != null && currentUser.Profile.ProfileID > 0)
                        _redirector.GoToProfilesDefault();
                    else
                        _redirector.GoToProfilesManageProfile();
                }
                else
                {
                    _email.SendEmailAddressVerificationEmail(account.Username, account.Email);
                    _view.DisplayMessage(@"The login information you provided was correct 
                                                    but your email address has not yet been verified.  
                                                    We just sent another email verification email to you.  
                                                    Please follow the instructions in that email.");
                }
            }
            else
            {
                _view.DisplayMessage(@"The credentials you have entered are incorrect. Please try again!");
            }


        }

        public void GoToRegister()
        {
            _redirector.GoToAccountRegisterPage();
        }

        public void GoToRecoverPassword()
        {
            _redirector.GoToAccountRecoverPasswordPage();
        }
    }
}
