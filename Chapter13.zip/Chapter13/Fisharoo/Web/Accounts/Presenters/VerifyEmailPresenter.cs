﻿using System.ComponentModel.Composition;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Common;
using Fisharoo.Entities;
using Fisharoo.Interfaces;
using Fisharoo.Web.Accounts.Interfaces;

namespace Fisharoo.Web.Accounts.Presenters
{
    public class VerifyEmailPresenter
    {
        [Import]
        private IWebContext _webContext;
        [Import]
        private IAccountService _accountService;
        
        public void Init(IVerifyEmail _view)
        {
            MEFManager.Compose(this);

            string username = Cryptography.Decrypt(_webContext.UsernameToVerify, "verify");

            Account account = _accountService.GetAccountByUsername(username);

            if(account != null)
            {
                account.EmailVerified = true;
                _accountService.SaveAccount(account);
                _view.ShowMessage("Your email address has been successfully verified!");
            }
            else
            {
                _view.ShowMessage("There appears to be something wrong with your verification link!  Please try again.  If you are having issues by clicking on the link, please try copying the URL from your email and pasting it into your browser window.");
            }
        }
    }
}
