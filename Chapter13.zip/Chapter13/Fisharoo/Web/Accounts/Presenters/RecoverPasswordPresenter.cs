﻿using System.ComponentModel.Composition;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Common;
using Fisharoo.Entities;
using Fisharoo.Interfaces;
using Fisharoo.Web.Accounts.Interfaces;

namespace Fisharoo.Web.Accounts.Presenters
{
    public class RecoverPasswordPresenter
    {
        private IRecoverPassword _view;
        [Import]
        private IEmail _email;
        [Import]
        private IAccountService _accountService;

        public RecoverPasswordPresenter()
        {
            MEFManager.Compose(this);
        }

        public void Init(IRecoverPassword View)
        {
            _view = View;
        }

        public void RecoverPassword(string Email)
        {
            Account account = _accountService.GetAccountByEmail(Email);

            if(account != null)
            {
                _email.SendPasswordReminderEmail(account.Email, account.Password, account.Username);
                _view.ShowRecoverPasswordPanel(false);
                _view.ShowMessage("An email was sent to your account!");
            }
            else
            {
                _view.ShowRecoverPasswordPanel(true);
                _view.ShowMessage("We couldn't find the account you requested.");
            }
            
        }
    }
}
