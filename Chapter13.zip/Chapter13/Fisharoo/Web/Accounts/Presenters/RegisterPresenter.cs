﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using Fisharoo.Common;
using Fisharoo.Entities;
//using Fisharoo.Web.AccountProxy;
using Fisharoo.Interfaces;
using Fisharoo.Web.Accounts.Interfaces;
using Fisharoo.BusinessLogic.Interfaces;

namespace Fisharoo.Web.Accounts.Presenters
{
    public class RegisterPresenter
    {
        private IRegister _view;
        [Import]
        private IPermissionService _permissionService;
        [Import]
        private ITermService _termService;
        [Import]
        private IAccountService _accountService;
//        [Import]
        //private AccountProxy.AccountServiceClient _accountService;
        [Import]
        private IWebContext _webContext;
        [Import]
        private IEmail _email;
        [Import]
        private IConfiguration _configuration;
        [Import]
        IRedirector _redirector;
        //CHAPTER5
        [Import]
        private IFriendInvitationService _friendInvitationService;
        [Import]
        private IFriendService _friendService;
        
        private FriendInvitation friendInvitation;


        public void Init(IRegister View)
        {
            _view = View;
            MEFManager.Compose(this);

            _view.LoadTerms(_termService.GetCurrentTerm());
            _view.LoadreCaptchaSetting(_configuration.ReCaptcha);
            if (!string.IsNullOrEmpty(_webContext.FriendshipRequest))
            {
                friendInvitation = _friendInvitationService.GetFriendInvitationByGUID(new Guid(_webContext.FriendshipRequest));
                _view.LoadEmailAddressFromFriendInvitation(friendInvitation.Email);
            }
        }

        public void LoginLinkClicked()
        {
            _redirector.GoToAccountLoginPage();
        }

        public void Register(string Username, string Password,
            string FirstName, string LastName, string Email,
            string Zip, DateTime BirthDate, bool isCaptchaValid, bool AgreesWithTerms, Int32 TermID)
        {
            if (AgreesWithTerms)
            {
                if (isCaptchaValid)
                {
                    Account acc = new Account();
                    acc.FirstName = FirstName;
                    acc.LastName = LastName;
                    acc.Email = Email;
                    acc.BirthDate = BirthDate;
                    acc.Zip = Zip;
                    acc.Username = Username;
                    acc.Password = Password.Encrypt(Username);
                    acc.CreateDate = acc.LastUpdateDate = DateTime.Now;
                    acc.TermID = TermID;
                    //For development marked as verified already
#if DEBUG
                    acc.EmailVerified = true;
#else
                    acc.EmailVerified = false;
#endif

                    if (_accountService.EmailInUse(Email))
                    {
                        _view.ShowErrorMessage("This email is already in use!");
                        _view.ToggleWizardIndex(0);
                    }
                    else if (_accountService.UsernameInUse(Username))
                    {
                        _view.ShowErrorMessage("This username is already in use!");
                        _view.ToggleWizardIndex(0);
                    }
                    else
                    {
                        _accountService.SaveAccount(acc);
                        //Chapter 4 modification: Add permission for registered users as well
                        Permission pubPermission = _permissionService.GetPermissionByName("PUBLIC");
                        Permission regPermission = _permissionService.GetPermissionByName("REGISTERED");
                        Account newAccount = _accountService.GetAccountByEmail(Email);

                        _accountService.AddPermission(newAccount, pubPermission);
                        _accountService.AddPermission(newAccount, regPermission);

                        //CHAPTER 5
                        //if this registration came via a friend request...
                        if (friendInvitation != null)
                        {
                            _friendService.CreateFriendFromFriendInvitation(new Guid(_webContext.FriendshipRequest), newAccount, false);
                        }

                        _email.SendEmailAddressVerificationEmail(acc.Username, acc.Email);
                        _view.ShowAccountCreatedPanel();
                    }
                }
                else
                {
                    _view.ShowErrorMessage("Your entry doesn't match the reCAPTCHA image.  Please try again.");
                }
            }
            else
            {
                _view.ToggleWizardIndex(2);
                _view.ShowErrorMessage("You can't create an account on this site if you don't agree with our terms!");
            }
        }
    }
}
