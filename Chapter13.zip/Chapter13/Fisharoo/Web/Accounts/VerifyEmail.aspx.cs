﻿using System;
using Fisharoo.Web.Accounts.Interfaces;
using Fisharoo.Web.Accounts.Presenters;

namespace Fisharoo.Web.Accounts
{
    public partial class VerifyEmail : System.Web.UI.Page, IVerifyEmail
    {
        private VerifyEmailPresenter _presenter;

        protected void Page_Load(object sender, EventArgs e)
        {
            _presenter = new VerifyEmailPresenter();
            _presenter.Init(this);
        }

        public void ShowMessage(string Message)
        {
            lblMsg.Text = Message;
        }
    }
}
