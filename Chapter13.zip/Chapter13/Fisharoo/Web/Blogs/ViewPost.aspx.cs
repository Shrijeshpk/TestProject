﻿using System;
using Fisharoo.Entities;
using Fisharoo.Web.Blogs.Interfaces;
using Fisharoo.Web.Blogs.Presenters;

namespace Fisharoo.Web.Blogs
{
    public partial class ViewPost : System.Web.UI.Page, IViewPost
    {
        private ViewPostPresenter _presenter;
        protected void Page_Load(object sender, EventArgs e)
        {
            _presenter = new ViewPostPresenter();
            string username = Page.RouteData.Values["username"] as string;
            string blogpage = Page.RouteData.Values["blogpage"] as string;
            _presenter.Init(this, username, blogpage);
        }

        public void LoadPost(Blog blog)
        {
            //navigation URL will follow the URL routing pattern
            linkProfile.NavigateUrl = Page.GetRouteUrl("ProfileRoute", new { username = blog.Account.Username });

            lblTitle.Text = blog.Title;
            lblPost.Text = blog.Post;
            imgAvatar.ImageUrl += "?AccountID=" + blog.AccountID.ToString();
            lblCreated.Text = blog.CreateDate.ToString();
            lblUpdated.Text = blog.UpdateDate.ToString();
        }
    }
}
