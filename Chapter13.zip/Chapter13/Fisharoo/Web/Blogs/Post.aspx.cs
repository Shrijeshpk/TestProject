﻿using System;
using Fisharoo.Entities;
using Fisharoo.Web.Blogs.Interfaces;
using Fisharoo.Web.Blogs.Presenters;

namespace Fisharoo.Web.Blogs
{
    public partial class Post : System.Web.UI.Page, IPost 
    {
        private PostPresenter _presenter;
        protected void Page_Load(object sender, EventArgs e)
        {
            _presenter = new PostPresenter();
            _presenter.Init(this, IsPostBack);
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            Blog blog = new Blog();
            if (litBlogID.Text != "")
                blog.BlogID = Convert.ToInt64(litBlogID.Text);
            blog.IsPublished = chkIsPublished.Checked;
            blog.PageName = txtPageName.Text;
            blog.Post = txtPost.Text;
            blog.Subject = txtSubject.Text;
            blog.Title = txtTitle.Text;
            _presenter.SavePost(blog);
        }

        public void LoadPost(Blog blog)
        {
            txtTitle.Text = blog.Title;
            txtSubject.Text = blog.Subject;
            txtPost.Text = blog.Post;
            txtPageName.Text = blog.PageName;
            chkIsPublished.Checked = blog.IsPublished;
            litBlogID.Text = blog.BlogID.ToString();
        }

        public void ShowError(string ErrorMessage)
        {
            lblErrorMessage.Text = ErrorMessage;
        }

        public void UpdateID(long blogID)
        {
            litBlogID.Text = blogID.ToString();
        }
    }
}
