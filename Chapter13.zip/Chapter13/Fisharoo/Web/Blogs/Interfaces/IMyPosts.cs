﻿using System.Collections.Generic;
using Fisharoo.Web.HelperClasses;

namespace Fisharoo.Web.Blogs.Interfaces
{
    public interface IMyPosts
    {
        void LoadBlogs(List<PEBlog> Blogs);
    }
}
