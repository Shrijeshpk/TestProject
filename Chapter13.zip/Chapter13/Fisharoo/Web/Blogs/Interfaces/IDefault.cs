﻿using System.Collections.Generic;
using Fisharoo.Web.HelperClasses;

namespace Fisharoo.Web.Blogs.Interfaces
{
    public interface IDefault
    {
        void LoadBlogs(List<PEBlog> Blogs);
    }
}
