﻿using Fisharoo.Entities;

namespace Fisharoo.Web.Blogs.Interfaces
{
    public interface IPost
    {
        void LoadPost(Blog blog);
        void ShowError(string ErrorMessage);
        void UpdateID(long blogID);
    }
}
