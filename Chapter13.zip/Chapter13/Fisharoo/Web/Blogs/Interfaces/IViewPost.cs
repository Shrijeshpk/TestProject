﻿using Fisharoo.Entities;

namespace Fisharoo.Web.Blogs.Interfaces
{
    public interface IViewPost
    {
        void LoadPost(Blog blog);
    }
}
