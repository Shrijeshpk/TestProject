﻿using System.ComponentModel.Composition;
using Fisharoo.Common;
using Fisharoo.Web.Blogs.Interfaces;
using System.Collections.Generic;
using Fisharoo.Web.HelperClasses;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Entities;

namespace Fisharoo.Web.Blogs.Presenters
{
    public class DefaultPresenter
    {
        private IDefault _view;
        [Import]
        private IBlogService _blogService;

        public DefaultPresenter()
        {
            MEFManager.Compose(this);
        }

        public void Init(IDefault View)
        {
            _view = View;
            List<Blog> list = _blogService.GetLatestBlogs();
            _view.LoadBlogs(Translator.BlogToPEBlog(list));
        }
    }
}
