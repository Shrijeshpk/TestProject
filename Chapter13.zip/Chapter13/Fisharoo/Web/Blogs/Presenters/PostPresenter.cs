﻿using System.ComponentModel.Composition;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Common;
using Fisharoo.Interfaces;
using Fisharoo.Web.Blogs.Interfaces;
using Fisharoo.Entities;

namespace Fisharoo.Web.Blogs.Presenters
{
    public class PostPresenter
    {
        [Import]
        private IBlogService _blogService;
        [Import]
        private IWebContext _webContext;

        private IPost _view;
        public PostPresenter()
        {
            MEFManager.Compose(this);
        }

        public void Init(IPost View, bool IsPostBack)
        {
            _view = View;
            if (!IsPostBack)
            {
                if (_webContext.BlogID > 0)
                {
                    _view.LoadPost(_blogService.GetBlogByBlogID(_webContext.BlogID));
                }
            }
        }

        public void SavePost(Blog blog)
        {
            bool result = true;
            if (blog.BlogID == 0)
            {
                //if blog already saved once, the ID will be > 0
                result = _blogService.CheckPageNameIsUnique(blog);
            }
            if (result)
            {
                Account currentUser = _webContext.CurrentUser as Account;
                blog.AccountID = currentUser.AccountID;
                long blogID = _blogService.SaveBlog(blog);
                _view.UpdateID(blogID);
                _view.ShowError("Blog is saved!");
            }
            else
            {
                _view.ShowError("The page name you have chosen is in use.  Please choose a different page name!");
            }
        }
    }
}
