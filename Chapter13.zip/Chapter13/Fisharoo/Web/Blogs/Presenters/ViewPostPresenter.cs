﻿using System.ComponentModel.Composition;
using Fisharoo.Common;
using Fisharoo.Web.Blogs.Interfaces;
using Fisharoo.Entities;
using Fisharoo.BusinessLogic.Interfaces;

namespace Fisharoo.Web.Blogs.Presenters
{
    public class ViewPostPresenter
    {
        private IViewPost _view;
        [Import]
        private IBlogService _blogService;
        [Import]
        private IAccountService _accountService;


        public ViewPostPresenter()
        {
            MEFManager.Compose(this);
        }

        public void Init(IViewPost View, string username, string blogpage)
        {
            _view = View;

            Account account = _accountService.GetAccountByUsername(username);
            _view.LoadPost(_blogService.GetBlogByPageName(blogpage, account.AccountID));
        }
    }
}
