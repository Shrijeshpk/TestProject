﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using Fisharoo.Common;
using Fisharoo.Entities;
using Fisharoo.Interfaces;
using Fisharoo.Web.Blogs.Interfaces;
using Fisharoo.Web.HelperClasses;
using Fisharoo.BusinessLogic.Interfaces;

namespace Fisharoo.Web.Blogs.Presenters
{
    public class MyPostsPresenter
    {
        private IMyPosts _view;
        [Import]
        private IBlogService _blogService;
        [Import]
        private IWebContext _webContext;
        [Import]
        private IRedirector _redirector;

        public MyPostsPresenter()
        {
            MEFManager.Compose(this);
        }

        public void Init(IMyPosts View)
        {
            _view = View;
            Account currentUser = _webContext.CurrentUser as Account;
            List<Blog> list = _blogService.GetBlogsByAccountID(currentUser.AccountID);
            _view.LoadBlogs(Translator.BlogToPEBlog(list));
        }

        public void EditBlog(Int64 BlogID)
        {
            _redirector.GoToBlogsPostEdit(BlogID);
        }

        public void DeletedBlog(Int64 BlogID)
        {
            _blogService.DeleteBlog(BlogID);
            Init(_view);
        }
    }
}
