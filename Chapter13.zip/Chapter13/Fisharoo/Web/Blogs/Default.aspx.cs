﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using Fisharoo.Web.Blogs.Interfaces;
using Fisharoo.Web.Blogs.Presenters;
using Fisharoo.Web.HelperClasses;

namespace Fisharoo.Web.Blogs
{
    public partial class Default : System.Web.UI.Page, IDefault
    {
        private DefaultPresenter _presenter;
        public Default()
        { 
            _presenter = new DefaultPresenter();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            _presenter.Init(this);
        }

        public void LoadBlogs(List<PEBlog> Blogs)
        {
            lvBlogs.DataSource = Blogs;
            lvBlogs.DataBind();
        }

        public void lvBlogs_ItemDataBound(object sender, ListViewItemEventArgs e)
        {
            Literal litBlogID = e.Item.FindControl("litBlogID") as Literal;
            HyperLink linkTitle = e.Item.FindControl("linkTitle") as HyperLink;
            Literal litPageName = e.Item.FindControl("litPageName") as Literal;
            Literal litUsername = e.Item.FindControl("litUsername") as Literal;
            //navigation URL will follow the URL routing pattern
            linkTitle.NavigateUrl = Page.GetRouteUrl("BlogRoute", new { username = litUsername.Text, blogpage = litPageName.Text });
        }
    }
}
