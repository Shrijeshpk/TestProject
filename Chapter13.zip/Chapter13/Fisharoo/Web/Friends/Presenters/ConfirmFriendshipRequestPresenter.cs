﻿using System;
using System.ComponentModel.Composition;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Common;
using Fisharoo.Entities;
using Fisharoo.Interfaces;
using Fisharoo.Web.Friends.Interfaces;

namespace Fisharoo.Web.Friends.Presenters
{
    public class ConfirmFriendshipRequestPresenter
    {
        private IConfirmFriendshipRequest _view;
        [Import]
        private IWebContext _webContext;
        [Import]
        private IFriendInvitationService _friendInvitationService;
        [Import]
        private IAccountService _accountService;
        [Import]
        private IConfiguration _configuration;
        [Import]
        private IRedirector _redirector;

        public ConfirmFriendshipRequestPresenter()
        {
            MEFManager.Compose(this);
        }

        public void Init(IConfirmFriendshipRequest view)
        {
            _view = view;
            if (!string.IsNullOrEmpty(_webContext.FriendshipRequest))
            {
                FriendInvitation friendInvitation =
                    _friendInvitationService.GetFriendInvitationByGUID(new Guid(_webContext.FriendshipRequest));
                if(friendInvitation != null)
                {
                    //TODO:Discuss: In Tabbed IE, session is shared across tabs. so the logged
                    //in user may not be the one for which the friendship request is sent
                    //do we want to do anything about it?
                    if (_webContext.CurrentUser != null)
                        LoginClick();

                    Account account = _accountService.GetAccountByID(friendInvitation.AccountID);
                    _view.ShowConfirmPanel(true);
                    _view.LoadDisplay(_webContext.FriendshipRequest, account.AccountID, account.FirstName, account.LastName, _configuration.SiteName );
                }
                else
                {
                    _view.ShowConfirmPanel(false);
                    _view.ShowMessage("There was an error validating your invitation.");
                }
            }
        }

        public void LoginClick()
        {
            _redirector.GoToAccountLoginPage(_webContext.FriendshipRequest);
        }

        public void RegisterClick()
        {
            _redirector.GoToAccountRegisterPage(_webContext.FriendshipRequest);
        }
    }
}
