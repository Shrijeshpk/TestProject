﻿using System.ComponentModel.Composition;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Common;
using Fisharoo.Entities;
using Fisharoo.Interfaces;
using Fisharoo.Web.Friends.Interfaces;

namespace Fisharoo.Web.Friends.Presenters
{
    public class InviteFriendsPresenter
    {
        private IInviteFriends _view;
        [Import]
        private IUserSession _userSession;
        [Import]
        private IEmail _email;
        [Import]
        private IAccountService _accountService;
        [Import]
        private IWebContext _webContext;

        private Account _account;
        private Account _accountToInvite;

        public void Init(IInviteFriends view)
        {
            _view = view;
            MEFManager.Compose(this);

            _account = _userSession.CurrentUser as Account;

            if (_account != null)
            {
                _view.DisplayToData(_account.FirstName + " " + _account.LastName + " &lt;" + _account.Email + "&gt;");

                if (_webContext.AccoundIdToInvite > 0)
                {
                    _accountToInvite = _accountService.GetAccountByID(_webContext.AccoundIdToInvite);

                    if (_accountToInvite != null)
                    {
                        SendInvitation(_accountToInvite.Email,
                                       _account.FirstName + " " + _account.LastName + " would like to be your friend!");
                        _view.ShowMessage(_accountToInvite.Username + " has been sent a friend request!");
                        _view.TogglePnlInvite(false);
                    }
                }
            }
        }

        public void SendInvitation(string ToEmailArray, string Message)
        {
            string resultMessage = "Invitations sent to the following recipients:<BR>";
            Account account = _userSession.CurrentUser as Account;
            resultMessage += _email.SendInvitations(account.AccountID, account.FirstName, account.LastName, ToEmailArray, Message);
            _view.ShowMessage(resultMessage);
            _view.ResetUI();
        }
    }
}
