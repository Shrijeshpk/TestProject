﻿using System.ComponentModel.Composition;
using System.IO;
using System.Web;
using Fisharoo.Common;
using Fisharoo.Entities;
using Fisharoo.Interfaces;
using Fisharoo.Web.Friends.Interfaces;

namespace Fisharoo.Web.Friends.Presenters
{
    public class OutlookCsvImporterPresenter
    {
        private IOutlookCsvImporter _view;
        [Import]
        private IEmail _email;
        [Import]
        private IUserSession _userSession;
        
        public OutlookCsvImporterPresenter()
        {
            MEFManager.Compose(this);
        }

        public void Init(IOutlookCsvImporter view)
        {
            _view = view;
        }

        public void ParseEmails(HttpPostedFile file)
        {
            using (Stream s = file.InputStream)
            {
                StreamReader sr = new StreamReader(s);
                string contacts = sr.ReadToEnd();

                _view.ShowParsedEmail(_email.ParseEmailsFromText(contacts));
            }
        }

        public void InviteContacts(string ToEmailArray)
        {
            Account account = _userSession.CurrentUser as Account;
            string result = _email.SendInvitations(account.AccountID, account.FirstName, account.LastName, ToEmailArray, "");
            _view.ShowInvitationResult(result);
        }
    }
}
