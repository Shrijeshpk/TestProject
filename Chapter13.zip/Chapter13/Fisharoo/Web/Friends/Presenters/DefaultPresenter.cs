﻿using System.ComponentModel.Composition;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Common;
using Fisharoo.Interfaces;
using Fisharoo.Web.Friends.Interfaces;
using Fisharoo.Entities;

namespace Fisharoo.Web.Friends.Presenters
{
    public class DefaultPresenter
    {
        private IDefault _view;
        [Import]
        private IFriendService _friendService;
        [Import]
        private IUserSession _userSession;

        public DefaultPresenter()
        {
            MEFManager.Compose(this);
        }

        public void Init(IDefault view)
        {
            _view = view;
            LoadDisplay();
        }

        public void LoadDisplay()
        {
            Account currentUser = _userSession.CurrentUser as Account;
            _view.LoadDisplay(_friendService.GetFriendsAccountsByAccountID(currentUser.AccountID));
        }
    }
}
