namespace Fisharoo.Web.Friends.Interfaces
{
    public interface IInviteFriends
    {
        void DisplayToData(string To);
        void ShowMessage(string Message);
        void ResetUI();
        void TogglePnlInvite(bool IsVisible);
    }
}