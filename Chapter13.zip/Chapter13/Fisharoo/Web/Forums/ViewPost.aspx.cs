﻿using System;
using System.Collections.Generic;
using System.Web.UI.WebControls;
using Fisharoo.Web.Forums.Interfaces;
using Fisharoo.Web.Forums.Presenters;
using Fisharoo.Web.HelperClasses;

namespace Fisharoo.Web.Forums
{
    public partial class ViewPost : System.Web.UI.Page, IViewPost
    {
        private ViewPostPresenter _presenter;

        protected void Page_Load(object sender, EventArgs e)
        {
            _presenter = new ViewPostPresenter();
            string categoryname = Page.RouteData.Values["categoryname"] as string;
            string forumname = Page.RouteData.Values["forumname"] as string;
            int postID = Convert.ToInt32(Page.RouteData.Values["postid"]);
            _presenter.Init(this, IsPostBack, categoryname, forumname, postID);
        }

        public void LoadData(PEBoardPost Thread, List<PEBoardPost> Posts, string CategoryName, string ForumName, int Score)
        {
            linkForumName.NavigateUrl = Page.GetRouteUrl("ForumRoute", new
                                                    {
                                                        categoryname = CategoryName,
                                                        forumname = ForumName
                                                    });

            linkUsername.Text = Thread.Username;
            linkUsername.NavigateUrl = "~/" + Thread.Username;
            lblCreateDate.Text = Thread.CreateDate;
            lblThreadTitle.Text = Thread.Name;
            //CHAPTER 11
            voteQuestion.PostID = Thread.PostID;
            voteQuestion.Count = Thread.VoteCount;
            medalUser.Score = Score;

            lblPost.Text = Thread.Post;
            imgProfile.ImageUrl = "/images/profileavatar/profileimage.aspx?AccountID=" + Thread.AccountID.ToString();
            //to reply one needs to login
            if (_presenter.IsUserLoggedIn())
            {
                linkReply.Text = "Reply";
                linkReply.NavigateUrl = Page.GetRouteUrl("ReplyThreadRoute", new 
                                                        {
                                                            categoryname = CategoryName,
                                                            forumname = ForumName,
                                                            postid = Thread.PostID.ToString()
                                                        });
            }
            else
            {
                linkReply.Text = "Login to Reply";
                linkReply.NavigateUrl = "/Accounts/Login.aspx";
            }

            repPosts.DataSource = Posts;
            repPosts.DataBind();
        }

        public void lbCategory_Click(object sender, EventArgs e)
        {
            _presenter.GoToCategory();
        }
    }
}