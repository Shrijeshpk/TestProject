﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.Web.HelperClasses;

namespace Fisharoo.Web.Forums.Interfaces
{
    public interface IPost
    {
        void SetDisplay(PEBoardPost post, string CategoryName, string ForumName);
        void SetErrorMessage(string Message);
    }
}
