﻿using System.Collections.Generic;
using Fisharoo.Web.HelperClasses;

namespace Fisharoo.Web.Forums.Interfaces
{
    public interface IDefault
    {
        void LoadCategories(List<PEBoardCategory> Categories);
    }
}
