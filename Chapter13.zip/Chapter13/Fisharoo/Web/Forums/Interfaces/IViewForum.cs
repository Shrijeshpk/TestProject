﻿using System;
using System.Collections.Generic;
using Fisharoo.Web.HelperClasses;

namespace Fisharoo.Web.Forums.Interfaces
{
    public interface IViewForum
    {
        void LoadDisplay(List<PEBoardPost> Threads, string CategoryName, string ForumName, Int32 ForumID);
    }
}
