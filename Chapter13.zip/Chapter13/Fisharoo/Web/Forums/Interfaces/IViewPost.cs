﻿using System.Collections.Generic;
using Fisharoo.Web.HelperClasses;

namespace Fisharoo.Web.Forums.Interfaces
{
    public interface IViewPost
    {
        void LoadData(PEBoardPost Thread, List<PEBoardPost> Posts, string CategoryName, string ForumName, int Score);
    }
}
