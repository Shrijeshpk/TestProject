﻿using System;
using System.ComponentModel.Composition;
using System.Web.Routing;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Common;
using Fisharoo.Entities;
using Fisharoo.Interfaces;
using Fisharoo.Web.Forums.Interfaces;
using Fisharoo.Web.HelperClasses;

namespace Fisharoo.Web.Forums.Presenters
{
    public class PostPresenter
    {
        private IPost _view;
        [Import]
        private IBoardPostService _postService;
        [Import]
        private IBoardForumService _forumService;
        [Import]
        private IBoardCategoryService _categoryService;
        [Import]
        private IRedirector _redirector;
        [Import]
        private IWebContext _webContext;
        [Import]
        private IAlertService _alertService;
        [Import]
        private IAccountService _accountService;
        [Import]
        private IGroupService _groupService;

        public PostPresenter()
        {
            MEFManager.Compose(this);
        }

        public void Init(IPost View, bool IsPostBack, string categoryName, string forumName, int postID)
        {
            _view = View;
            if (!IsPostBack)
            {
                PEBoardPost post = null;
                if (postID > 0)
                {
                    //CHAPTER 11
                    BoardPost bp = _postService.GetPostByID(postID);
                    int score = _accountService.GetAccountByID(bp.AccountID).Score;
                    post = Translator.BoardPostToPEBoardPost(bp, score);
                }

                _view.SetDisplay(post, categoryName, forumName);
            }
        }

        public void Save(BoardPost post, string forumName, long postID)
        {
            BoardForum forum = _forumService.GetForumByName(forumName);
            Boolean newPost = false;
            //is new thread
            if (postID == 0)
            {
                post.ForumID = forum.ForumID;
                post.IsThread = true;
                newPost = true;
            }
            //is reply post
            else
            {
                BoardPost postToReplyToo = _postService.GetPostByID(postID);
                if (postToReplyToo.IsThread)
                    post.ThreadID = postToReplyToo.PostID;
                else
                    post.ThreadID = postToReplyToo.ThreadID;

                post.ForumID = postToReplyToo.ForumID;
            }
            post.CreateDate = DateTime.Now;
            post.UpdateDate = DateTime.Now;
            Account currentUser = _webContext.CurrentUser as Account;
            post.AccountID = currentUser.AccountID;
            post.Username = currentUser.Username;
            post.ReplyCount = 0;
            post.ViewCount = 0;

            post.PostID = _postService.SavePost(post);

            Account act = _accountService.GetAccountByID(currentUser.AccountID);

            //providing score based if replying to post
            if (!newPost)
            {
              _accountService.SaveAccount(act, BoardPost.ScoreInput.ReplyPost);
            }

            
            BoardCategory category = _categoryService.GetCategoryByCategoryID(forum.CategoryID);
            BoardPost thread;
            if (post.IsThread)
                thread = _postService.GetPostByID(post.PostID);
            else
                thread = _postService.GetPostByID((long)post.ThreadID);

            //CHAPTER 10
            //is this forum part of a group?
            Group group = _groupService.GetGroupByForumID(forum.ForumID);

            //add an alert to the filter
            if (post.IsThread)
            {
                //CHAPTER 10
                //is this a group forum?
                if (group != null)
                    _alertService.AddNewBoardThreadAlert(category, forum, thread, group);
                else
                    _alertService.AddNewBoardThreadAlert(category, forum, thread);
            }
            else
            {
                //CHAPTER 10
                //is this a group forum?
                if (group != null)
                    _alertService.AddNewBoardPostAlert(category, forum, post, thread, group);
                else
                    _alertService.AddNewBoardPostAlert(category, forum, post, thread);
            }

            //TODO: the following is not constructed using route format
            //_redirector.GoToForumsViewPost(forum.Name, category.Name, thread.PostID);
            RouteValueDictionary values = new RouteValueDictionary
                                            {
                                                {"categoryname", category.Name},
                                                {"forumname", forum.Name},
                                                {"postid", thread.PostID}
                                            };
            VirtualPathData vpd = RouteTable.Routes.GetVirtualPath(null, "ThreadRoute", values);
            _redirector.GoToForumsViewPost(vpd.VirtualPath);
        }
    }
}
