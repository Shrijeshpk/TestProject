﻿using System.ComponentModel.Composition;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Common;
using Fisharoo.Interfaces;
using Fisharoo.Web.Forums.Interfaces;
using System.Collections.Generic;
using Fisharoo.Web.HelperClasses;
using Fisharoo.Entities;

namespace Fisharoo.Web.Forums.Presenters
{
    public class DefaultPresenter
    {
        [Import]
        private IBoardService _boardService;
        [Import]
        private IRedirector _redirector;
        
        private IDefault _view;
        public DefaultPresenter()
        {
            MEFManager.Compose(this);
        }

        public void Init(IDefault View)
        {
            _view = View;
            List<BoardCategory> list = _boardService.GetCategoriesWithForums();
            _view.LoadCategories(Translator.BoardCategoryToPEBoardCategory(list));
        }
    }
}
