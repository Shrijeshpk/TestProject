﻿using System.ComponentModel.Composition;
using Fisharoo.Common;
using Fisharoo.Web.Forums.Interfaces;
using Fisharoo.Entities;
using System.Collections.Generic;
using Fisharoo.Web.HelperClasses;
using Fisharoo.Interfaces;
using Fisharoo.BusinessLogic.Interfaces;

namespace Fisharoo.Web.Forums.Presenters
{
    public class ViewPostPresenter
    {
        private IViewPost _view;
        [Import]
        private IWebContext _webContext;
        [Import]
        private IBoardPostService _postService;
        [Import]
        private IBoardForumService _forumService;
        [Import]
        private IBoardCategoryService _categoryService;
        [Import]
        private IRedirector _redirector;
        //CHAPTER 11
        [Import]
        private IAccountService _accountService;
        
        public ViewPostPresenter()
        {
            MEFManager.Compose(this);
        }

        public void Init(IViewPost View, bool IsPostBack, string categoryname, string forumname, int postID)
        {
            _view = View;
            if (!IsPostBack)
            {
                LoadData(categoryname, forumname, postID);
            }
        }

        public bool IsUserLoggedIn()
        {
            return _webContext.LoggedIn;
        }

        private void LoadData(string categoryname, string forumname, int postID)
        {
            List<BoardPost> list = _postService.GetPostsByThreadID(postID);
            BoardPost bp = _postService.GetPostByID(postID);
            
            //CHAPTER 11
            Account currentUser = _webContext.CurrentUser as Account;
            bool displayMarkAnswer = IsUserLoggedIn() && (bp.AccountID == currentUser.AccountID) ? true : false;
            int score = _accountService.GetAccountByID(bp.AccountID).Score;

            _view.LoadData(Translator.BoardPostToPEBoardPost(bp, score), Translator.BoardPostToPEBoardPost(list, _accountService, displayMarkAnswer), categoryname, forumname, score);
        }

        public void GoToCategory()
        {
            _redirector.GoToForumDefaultView();
        }
    }
}
