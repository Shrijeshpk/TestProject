﻿using System.Collections.Generic;
using System.ComponentModel.Composition;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Common;
using Fisharoo.Entities;
using Fisharoo.Interfaces;
using Fisharoo.Web.Forums.Interfaces;
using Fisharoo.Web.HelperClasses;

namespace Fisharoo.Web.Forums.Presenters
{
    public class ViewForumPresenter
    {
        [Import]
        private IBoardPostService _postService;
        [Import]
        private IWebContext _webContext;
        [Import]
        private IBoardForumService _forumService;
        [Import]
        private IRedirector _redirector;
        //CHAPTER 11
        [Import]
        private IAccountService _accountService;

        private IViewForum _view;
        public ViewForumPresenter()
        {
            MEFManager.Compose(this);
        }

        public void Init(IViewForum view, string categoryName, string forumName)
        {
            _view = view;
            LoadThreads(categoryName, forumName);
        }

        public bool IsUserLoggedIn()
        {
            return _webContext.LoggedIn;
        }


        private void LoadThreads(string categoryName, string forumName)
        {
            BoardForum forum = _forumService.GetForumByName(forumName);
            List<BoardPost> list = _postService.GetThreadsByForumID(forum.ForumID);
            //CHAPTER  11
            _view.LoadDisplay(Translator.BoardPostToPEBoardPost(list, _accountService), categoryName, forumName, forum.ForumID);
        }

        public void GoToCategory()
        {
            _redirector.GoToForumDefaultView();
        }
    }
}
