﻿using System;
using Fisharoo.Entities;
using Fisharoo.Web.Forums.Interfaces;
using Fisharoo.Web.Forums.Presenters;
using Fisharoo.Web.HelperClasses;

namespace Fisharoo.Web.Forumss
{
    public partial class Post : System.Web.UI.Page, IPost
    {
        private PostPresenter _presenter;
        protected void Page_Load(object sender, EventArgs e)
        {
            _presenter = new PostPresenter();
            string categoryname = Page.RouteData.Values["categoryname"] as string;
            string forumname = Page.RouteData.Values["forumname"] as string;
            int postID = 0;
            //could be a reply in which case postid is valid, or a new post in which there is no postid
            if(Page.RouteData.Values.ContainsKey("postid"))
                postID = Convert.ToInt32(Page.RouteData.Values["postid"]);
            
            _presenter.Init(this, IsPostBack, categoryname, forumname, postID);
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            BoardPost post = new BoardPost();
            post.Name = txtName.Text;
            post.Post = txtPost.Text;
            _presenter.Save(post, linkForumName.Text, Convert.ToInt64(litPostID.Text));
        }

        public void SetDisplay(PEBoardPost post, string CategoryName, string ForumName)
        {
            linkForumName.NavigateUrl = Page.GetRouteUrl("ForumRoute", new
                                                            {
                                                                categoryname = CategoryName,
                                                                forumname = ForumName
                                                            });


            if (post != null)
            {
                txtName.Text = post.Name;
                txtName.Enabled = false;
                litPostID.Text = post.PostID.ToString();
            }
            else
            {
                txtName.Enabled = true;
                litPostID.Text = "0";
            }
        }

        public void SetErrorMessage(string Message)
        {
            lblMessage.Text = Message;
        }
    }
}