using System.ComponentModel.Composition;
using Fisharoo.BusinessLogic.Interfaces;
using Fisharoo.Common;
using Fisharoo.Interfaces;


public partial class Files_ReceiveFiles : System.Web.UI.Page
{
    [Import]
    private IWebContext _webContext;
    [Import]
    private IUploadService _uploadService;

    protected void Page_Load(object sender, System.EventArgs e)
    {
        MEFManager.Compose(this);

        //CHAPTER 10
        _uploadService.UploadPhotos(_webContext.FileTypeID, _webContext.AccountID, _webContext.Files, _webContext.AlbumID);
    }
}
