﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.Objects.SqlClient;
using Fisharoo.DataAccess.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Repositories
{
    //CHAPTER 7
    [Export(typeof(IFolderRepository))]
    public class FolderRepository : IFolderRepository
    {
        private Connection conn;
        public FolderRepository()
        {
            conn = new Connection();
        }

        public List<Folder> GetFoldersByAccountID(Int32 AccountID)
        {
            List<Folder> result = new List<Folder>();
            using(FisharooDataContext dc = conn.GetContext())
            {
                var account = dc.Accounts.Where(a => a.AccountID == AccountID).FirstOrDefault();

                IEnumerable<Folder> folders = (from f in dc.Folders
                                               where f.AccountID == AccountID
                                               orderby f.CreateDate descending 
                                               select f);
                foreach (Folder folder in folders)
                {
                    var fullPath = (from f in dc.Files.Include("FileType")
                                    join ft in dc.FileTypes
                                    on f.FileTypeID equals ft.FileTypeID
                                    where f.DefaultFolderID == folder.FolderID
                                    select f).FirstOrDefault();
                    if (fullPath != null)
                    {
                        String FullPathToCoverImage = fullPath.CreateDate.Year.ToString() + fullPath.CreateDate.Month.ToString()
                                                      + "/" + fullPath.FileSystemName.ToString() + "__S." + fullPath.FileType.Name;
                        folder.FullPathToCoverImage = FullPathToCoverImage;
                    }
                    else
                        folder.FullPathToCoverImage = "default.jpg";
                    if(account != null)
                        folder.Username = account.Username;
                }
                result = folders.ToList();
            }
            return result;
        }

        public List<Folder> GetFriendsFolders(List<Friend> Friends)
        {
            List<Folder> result = new List<Folder>();
            foreach (Friend friend in Friends)
            {
                if (result.Count < 50)
                {
                    List<Folder> folders = GetFoldersByAccountID(friend.MyFriendsAccountID);
                    IEnumerable<Folder> result2 = result.Union(folders);
                    result = result2.ToList();
                }
                else 
                    break;
            }
            return result;
        }

        public Folder GetFolderByID(Int64 FolderID)
        {
            Folder folder;
            using(FisharooDataContext dc = conn.GetContext())
            {
                folder = dc.Folders.Where(f => f.FolderID == FolderID).FirstOrDefault();
            }
            return folder;
        }

        public Int64 SaveFolder(Folder folder)
        {
            Int64 result = 0;
            using (FisharooDataContext dc = conn.GetContext())
            {
                if (folder.FolderID > 0)
                {
                    dc.Folders.Attach(new Folder { FolderID = folder.FolderID });
                    dc.Folders.ApplyCurrentValues(folder);
                }
                else
                {
                    folder.CreateDate = DateTime.Now;
                    dc.Folders.AddObject(folder);
                }

                dc.SaveChanges();
                result = folder.FolderID;
            }
            return result;
        }

        public void DeleteFolder(Folder folder)
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                dc.Folders.DeleteObject(dc.Folders.Where(f => f.FolderID.Equals(folder.FolderID))
                                                  .FirstOrDefault());
                dc.SaveChanges();
            }
        }
    }
}