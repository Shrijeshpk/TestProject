﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Repositories
{
    [Export(typeof(IAlertRepository))]
    public class AlertRepository : IAlertRepository
    {
        private Connection conn;
        public AlertRepository()
        {
            conn = new Connection();
        }

        public List<Alert> GetAlertsByAccountID(Int32 AccountID)
        {
            List<Alert> result;
            using(FisharooDataContext dc = conn.GetContext())
            {
                IEnumerable<Alert> alerts = (from a in dc.Alerts
                                             where a.AccountID == AccountID
                                             orderby a.CreateDate descending
                                             select a).Take(40);
                result = alerts.ToList();
            }
            return result;
        }

        public void SaveAlert(Alert alert)
        {
            using(FisharooDataContext dc = conn.GetContext())
            {
                if(alert.AlertID > 0)
                {
                    dc.Alerts.Attach(new Alert { AlertID = alert.AlertID });
                    dc.Alerts.ApplyCurrentValues(alert);
                    dc.SaveChanges();
                }
                else
                {
                    alert.CreateDate = DateTime.Now;
                    dc.Alerts.AddObject(alert);
                }
                dc.SaveChanges();
            }
        }

        public void DeleteAlert(Alert alert)
        {
            using(FisharooDataContext dc = conn.GetContext())
            {
                dc.Alerts.DeleteObject(dc.Alerts.Where
                                      (al=>al.AlertID.Equals(alert.AlertID)).FirstOrDefault());
                dc.SaveChanges();
            }
        }

        //CHAPTER 13
        public void DeleteAlerts(List<int> alertIDs)
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                foreach (int i in alertIDs)
                {
                    dc.Alerts.DeleteObject(dc.Alerts.Where
                                      (al => al.AlertID.Equals(i.ToString())).FirstOrDefault());
                    dc.SaveChanges();
                }
            }
        }

    }
}
