﻿using System.Linq;
using Fisharoo.DataAccess.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Repositories
{
    [Export(typeof(ITermRepository))]
    public class TermRepository : ITermRepository
    {
        private Connection conn;

        public TermRepository()
        {
            conn = new Connection();
        }

        public Term GetCurrentTerm()
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                Term term = (from t in dc.Terms
                            orderby t.CreateDate descending
                            select t).FirstOrDefault();
                return term;
                
            }
        }

        public void SaveTerm(Term term)
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                if (term.TermID > 0)
                {
                    dc.Terms.Attach(new Term { TermID = term.TermID});
                    dc.Terms.AddObject(term);
                }
                else
                {
                    dc.Terms.AddObject(term);
                }
                dc.SaveChanges();
            }
        }

        public void DeleteTerm(Term term)
        {
            using(FisharooDataContext dc = conn.GetContext())
            {
                dc.DeleteObject(dc.Terms.Where(t=>t.TermID.Equals(term.TermID)).FirstOrDefault());
                dc.SaveChanges();
            }
        }
    }
}
