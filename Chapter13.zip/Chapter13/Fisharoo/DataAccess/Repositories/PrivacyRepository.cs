﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.Entities;
using Fisharoo.DataAccess.Interfaces;
using System.ComponentModel.Composition;

namespace Fisharoo.DataAccess
{
    //CHAPTER 4
    [Export(typeof(IPrivacyRepository))]
    public class PrivacyRepository : IPrivacyRepository
    {
        private Connection conn;
        public PrivacyRepository()
        {
            conn = new Connection();
        }

        public List<PrivacyFlagType> GetPrivacyFlagTypes()
        {
            List<PrivacyFlagType> result;
            using(FisharooDataContext dc = conn.GetContext())
            {
                IEnumerable<PrivacyFlagType> query = dc.PrivacyFlagTypes.OrderBy(pft => pft.SortOrder);
                result = query.ToList();
            }
            return result;
        }

        public List<VisibilityLevel> GetVisibilityLevels()
        {
            List<VisibilityLevel> result;
            using(FisharooDataContext dc = conn.GetContext())
            {
                IEnumerable<VisibilityLevel> query = dc.VisibilityLevels;
                result = query.ToList();
            }
            return result;
        }

        public List<PrivacyFlag> GetPrivacyFlagsByProfileID(Int32 ProfileID)
        {
            List<PrivacyFlag> result;
            using(FisharooDataContext dc = conn.GetContext())
            {
                IEnumerable<PrivacyFlag> query = dc.PrivacyFlags.Where(pf => pf.ProfileID == ProfileID);
                result = query.ToList();
            }
            return result;
        }

        public void SavePrivacyFlag(PrivacyFlag privacyFlag)
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                if (privacyFlag.PrivacyFlagID > 0)
                {
                    dc.PrivacyFlags.Attach(new PrivacyFlag { PrivacyFlagID = privacyFlag.PrivacyFlagID });
                    dc.PrivacyFlags.ApplyCurrentValues(privacyFlag);
                }
                else
                {
                    dc.PrivacyFlags.AddObject(privacyFlag);
                }
                dc.SaveChanges();
            }
        }
    }
}
