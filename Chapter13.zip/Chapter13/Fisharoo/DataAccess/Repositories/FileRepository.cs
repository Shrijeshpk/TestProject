﻿using System;
using System.Collections.Generic;
//using System.IO;
using System.Linq;
using System.Text;
using Fisharoo.DataAccess.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.Entities;
using Fisharoo.DataAccess;

namespace Fisharoo.DataAccess.Repositories
{
    //CHAPTER 7
    [Export(typeof(IFileRepository))]
    public class FileRepository : IFileRepository
    {
        private Connection conn;
        
        public FileRepository()
        {
            conn = new Connection();
        }

        public File GetFileByID(Int64 FileID)
        {
            File file;
            using(FisharooDataContext dc = conn.GetContext())
            {
                file = dc.Files.Where(f => f.FileID == FileID).FirstOrDefault();
                if (file != null)
                {
                    var fileType = dc.FileTypes.Where(ft => ft.FileTypeID == file.FileTypeID).FirstOrDefault();
                    file.Extension = fileType.Name;
                }
            }
            return file;
        }

        public File GetFileByFileSystemName(Guid FileSystemName)
        {
            File file;
            using (FisharooDataContext dc = conn.GetContext())
            {
                file = dc.Files.Where(f => f.FileSystemName == FileSystemName).FirstOrDefault();
                if (file != null)
                {
                    var fileType = dc.FileTypes.Where(ft => ft.FileTypeID == file.FileTypeID).FirstOrDefault();
                    file.Extension = fileType.Name;
                }
            }
            return file;
        }

        //CHAPTER 12 - Modified
        public List<File> GetFilesByFolderID(Int64 FolderID)
        {
            List<File> result;
            using (FisharooDataContext dc = conn.GetContext())
            {
                //invokes the stored procedure to filter out result for eliminating flagged and approved files while displaying all files
                result = dc.pr_GetModeratedFiles(FolderID).ToList();
                
                foreach (File file in result)
                {
                    var fileType = dc.FileTypes.Where(ft => ft.FileTypeID == file.FileTypeID).FirstOrDefault();
                    file.Extension = fileType.Name;
                }
            }
            return result;
        }

        public void UpdateDescriptions(Dictionary<int,string> fileDescriptions)
        {
            using(FisharooDataContext dc = conn.GetContext())
            {
                List<Int64> fileIDs = fileDescriptions.Select(f => Convert.ToInt64(f.Key)).Distinct().ToList();
                IEnumerable<File> files = dc.Files.Where(f => fileIDs.Contains(f.FileID));
                foreach (File file in files)
                {
                    file.Description = fileDescriptions.Where(f=>f.Key==file.FileID).Select(f=>f.Value).FirstOrDefault();
                }
                dc.SaveChanges();
            }
        }

        public Int64 SaveFile(File file)
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                if (file.FileID > 0)
                {
                    dc.Files.Attach(new File { FileID = file.FileID });
                    dc.Files.ApplyCurrentValues(file);
                }
                else
                {
                    file.CreateDate = DateTime.Now;
                    dc.Files.AddObject(file);
                }
                dc.SaveChanges();
            }
            return file.FileID;
        }

        public void DeleteFilesInFolder(string filePath, Folder folder)
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                List<File> files = GetFilesByFolderID(folder.FolderID);
                foreach (File file in files)
                {
                    DeleteFileFromFileSystem(filePath, folder, file);
                }
                //Entity Framework 4 doesnt support any method to bulk delete, hence only way is to iterate through resultset
                //and delete one by one, another way is to use dc.ExecuteStoreQuery() and pass SQL String 
                //dc.ExecuteStoreQuery() is efficient but doesnt use LINQ syntax
                var ListOffiles = dc.Files.Where(f => f.DefaultFolderID == folder.FolderID).ToList();
                foreach (File f in ListOffiles)
                {
                    dc.Files.DeleteObject(f);
                }
                dc.SaveChanges();
            }
        }

        public void DeleteFile(string filePath, File file)
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                Folder folder = dc.Folders.Where(f => f.FolderID == file.DefaultFolderID).FirstOrDefault();
                DeleteFileFromFileSystem(filePath, folder, file);
                dc.Files.DeleteObject(dc.Files.Where(f => f.DefaultFolderID == folder.FolderID).FirstOrDefault());
                dc.SaveChanges();
            }
        }

        private void DeleteFileFromFileSystem(string filePath, Folder folder, File file)
        {
            string path = "";
            switch (file.FileTypeID)
            {
                case 1:
                case 2:
                case 7:
                    path = "Photos\\";
                    break;
                case 3:
                case 4:
                    path = "Audios\\";
                    break;
                case 5:
                case 8:
                case 6:
                    path = "Videos\\";
                    break;
            }

            string fullPath = filePath + "Files\\" + path + folder.CreateDate.Year.ToString() + folder.CreateDate.Month.ToString() + "\\";
            
            if (System.IO.Directory.Exists(fullPath))
            {
                if (System.IO.File.Exists(fullPath + file.FileSystemName + "__o." + file.Extension))
                    System.IO.File.Delete(fullPath + file.FileSystemName + "__o." + file.Extension);
                if (System.IO.File.Exists(fullPath + file.FileSystemName + "__t." + file.Extension))
                    System.IO.File.Delete(fullPath + file.FileSystemName + "__t." + file.Extension);
                if (System.IO.File.Exists(fullPath + file.FileSystemName + "__s." + file.Extension))
                    System.IO.File.Delete(fullPath + file.FileSystemName + "__s." + file.Extension);
                if (System.IO.File.Exists(fullPath + file.FileSystemName + "__m." + file.Extension))
                    System.IO.File.Delete(fullPath + file.FileSystemName + "__m." + file.Extension);
                if (System.IO.File.Exists(fullPath + file.FileSystemName + "__l." + file.Extension))
                    System.IO.File.Delete(fullPath + file.FileSystemName + "__l." + file.Extension);

                if (System.IO.Directory.GetFiles(fullPath).Count() == 0)
                    System.IO.Directory.Delete(fullPath);
            }
        }
    }
}