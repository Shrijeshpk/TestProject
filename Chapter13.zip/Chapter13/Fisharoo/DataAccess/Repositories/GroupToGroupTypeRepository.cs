﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Entities;
using System.ComponentModel.Composition;

namespace Fisharoo.DataAccess.Repositories
{
    //CHAPTER 10
    [Export(typeof(IGroupToGroupTypeRepository))]
    public class GroupToGroupTypeRepository : IGroupToGroupTypeRepository
    {
        private Connection conn;
        public GroupToGroupTypeRepository()
        {
            conn = new Connection();
        }

        public void SaveGroupTypesForGroup(List<long> SelectedGroupTypeIDs, int GroupID)
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                //get a list of current selections
                List<long> currentTypes =
                    dc.GroupToGroupTypes.Where(gt => gt.GroupID == GroupID).Select(gt => gt.GroupTypeID).ToList();

                //make a list of items to delete
                List<long> itemsToDelete = currentTypes.Where(ct => !SelectedGroupTypeIDs.Contains(ct)).ToList();

                //make a list of items to insert
                List<long> itemsToInsert =
                    SelectedGroupTypeIDs.Where(s => !currentTypes.Contains(s)).ToList();

                //delete grouptogrouptypes
                
                List<GroupToGroupType> GrptoGrupType= dc.GroupToGroupTypes.Where(g => itemsToDelete.Contains(g.GroupTypeID)
                                                                                 && g.GroupID == GroupID).ToList();
                foreach (GroupToGroupType gptogpt in GrptoGrupType)
                {
                    dc.GroupToGroupTypes.DeleteObject(gptogpt);
                }

                //create the actual objects to insert and insert
                foreach (long l in itemsToInsert)
                {
                    GroupToGroupType g = new GroupToGroupType() { GroupID = GroupID, GroupTypeID = l };
                    dc.GroupToGroupTypes.AddObject(g);
                }
                dc.SaveChanges();
            }
        }

        public void SaveGroupToGroupType(GroupToGroupType groupToGroupType)
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                if (dc.GroupToGroupTypes.Where(gt => gt.GroupID == groupToGroupType.GroupID 
                                               && gt.GroupTypeID == groupToGroupType.GroupTypeID).FirstOrDefault() == null)
                {
                    dc.GroupToGroupTypes.AddObject(groupToGroupType);
                    dc.SaveChanges();
                }
            }
        }
        
        public void DeleteGroupToGroupType(GroupToGroupType groupToGroupType )
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                dc.GroupToGroupTypes.Attach(groupToGroupType);
                dc.GroupToGroupTypes.DeleteObject(groupToGroupType);
                dc.SaveChanges();
            }
        }
    }
}
