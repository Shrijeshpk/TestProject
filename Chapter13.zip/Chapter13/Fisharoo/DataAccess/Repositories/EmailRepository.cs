﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Entities;
using System.ComponentModel.Composition;

namespace Fisharoo.DataAccess.Repositories
{
    //CHAPTER 13
    [Export(typeof(IEmailRepository))]
    public class EmailRepository : IEmailRepository
    {
        private Connection conn;
        public EmailRepository()
        {
            conn = new Connection();
        }

        public void Save(MailQueue_Receiving MailQueue)
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                dc.MailQueue_Receiving.AddObject(MailQueue);
                dc.SaveChanges();
            }
        }

     
        public List<pr_MailQueue_SwapReceivingAndWorking_GetWorking_Result> GetMailQueueToProcess()
        {
            List<pr_MailQueue_SwapReceivingAndWorking_GetWorking_Result> results = new List<pr_MailQueue_SwapReceivingAndWorking_GetWorking_Result>();
            using (FisharooDataContext dc = conn.GetContext())
            {
                results = dc.pr_MailQueue_SwapReceivingAndWorking_GetWorking().ToList();
            }
            return results;
        }

        public void MoveMailQueueWorkingToHistory()
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                dc.pr_MailQueue_MoveWorkingToHistory();
            }
        }
    }
}
