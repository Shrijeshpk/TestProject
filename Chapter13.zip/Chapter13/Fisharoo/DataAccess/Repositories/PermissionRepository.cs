﻿using System;
using System.Collections.Generic;
using System.Linq;
using Fisharoo.DataAccess.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Repositories
{
    [Export(typeof(IPermissionRepository))]
    public class PermissionRepository : IPermissionRepository
    {
        private Connection conn;
        public PermissionRepository()
        {
            conn = new Connection();    
        }

        public List<Permission> GetPermissionsByAccountID(Int32 AccountID)
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                
                var permissions = from p in dc.Permissions
                                    join ap in dc.AccountPermissions on p.PermissionID equals ap.PermissionID
                                    join a in dc.Accounts on ap.AccountID equals a.AccountID
                                    where a.AccountID == AccountID
                                    select p;
                
                return permissions.ToList();
            }
        }

        //Chapter 4 modification. Changed from list to single object for below methods
        public Permission GetPermissionByName(string Name)
        {
            Permission result;
            using (FisharooDataContext dc = conn.GetContext())
            {
                result = dc.Permissions.Where(p => p.Name == Name).FirstOrDefault();
            }

            return result;
        }

        //Chapter 4 modification. Changed from list to single object for below methods
        public Permission GetPermissionByID(Int32 PermissionID)
        {
            Permission result;

            using (FisharooDataContext dc = conn.GetContext())
            {
                result = dc.Permissions.Where(p => p.PermissionID == PermissionID).FirstOrDefault();
            }

            return result;
        }

        public void SavePermission(Permission permission)
        {
            using(FisharooDataContext dc = conn.GetContext())
            {
                if(permission.PermissionID > 0)
                {
                    dc.Permissions.Attach(new Permission{PermissionID = permission.PermissionID});
                    dc.Permissions.ApplyCurrentValues(permission);
                }
                else
                {
                    dc.Permissions.ApplyCurrentValues(permission);
                }
                dc.SaveChanges();
            }
        }

        public void DeletePermission(Permission permission)
        {
            using(FisharooDataContext dc = conn.GetContext())
            {
                dc.DeleteObject(dc.Permissions.Where
                               (pm=>pm.PermissionID.Equals(permission.PermissionID)).FirstOrDefault());
                dc.SaveChanges();

            }
        }
    }
}
