﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.DataAccess.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Repositories
{
    [Export(typeof(IBoardCategoryRepository))]
    public class BoardCategoryRepository : IBoardCategoryRepository
    {
        private Connection _conn;
        public BoardCategoryRepository()
        {
            _conn = new Connection();
        }

        public BoardCategory GetCategoryByCategoryID(Int32 CategoryID)
        {
            BoardCategory result;
            using (FisharooDataContext dc = _conn.GetContext())
            {
                result = dc.BoardCategorys.Where(c => c.CategoryID == CategoryID).FirstOrDefault();
            }
            return result;
        }

        public BoardCategory GetCategoryByPageName(string PageName)
        {
            BoardCategory category = new BoardCategory();
            using (FisharooDataContext dc = _conn.GetContext())
            {
                category = dc.BoardCategorys.Where(bc => bc.PageName == PageName).FirstOrDefault();
            }
            return category;
        }
        
        public BoardCategory GetCategoryByName(string Name)
        {
            BoardCategory category = new BoardCategory();
            using (FisharooDataContext dc = _conn.GetContext())
            {
                category = dc.BoardCategorys.Where(bc => bc.Name == Name).FirstOrDefault();
            }
            return category;
        }

        //CHAPTER 10
        public List<BoardCategory> GetAllCategories()
        {
            List<BoardCategory> result ;
            using (FisharooDataContext dc = _conn.GetContext())
            {
                IEnumerable<BoardCategory> categories = dc.BoardCategorys.Where(c => c.CategoryID != 4); //don't get the groups category
                result = categories.ToList();
            }
            return result;
        }

        public Int32 SaveCategory(BoardCategory category)
        {
            using (FisharooDataContext dc = _conn.GetContext())
            {
                if (category.CategoryID > 0)
                {
                    dc.BoardCategorys.Attach(new BoardCategory { CategoryID = category.CategoryID });
                    dc.BoardCategorys.ApplyCurrentValues(category);
                }
                else
                {
                    dc.BoardCategorys.AddObject(category);
                }
                dc.SaveChanges();
            }
            return category.CategoryID;
        }

        public void DeleteCategory(BoardCategory category)
        {
            using (FisharooDataContext dc = _conn.GetContext())
            {
                dc.BoardCategorys.Attach(category);
                dc.BoardCategorys.DeleteObject(category);
                dc.SaveChanges();
            }
        }
    }
}
