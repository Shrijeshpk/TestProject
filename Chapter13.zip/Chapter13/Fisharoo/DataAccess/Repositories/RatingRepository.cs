﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.DataAccess.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Repositories
{
    [Export(typeof(IRatingRepository))]
    public class RatingRepository : IRatingRepository
    {
        private Connection conn;
        public RatingRepository()
        {
            conn = new Connection();
        }

        public bool HasRatedBefore(int SystemObjectID, long SystemObjectRecordID, int AccountID)
        {
            bool result = false;
            using(FisharooDataContext dc = conn.GetContext())
            {
                if (dc.Ratings.Where(r => r.SystemObjectID == SystemObjectID && 
                    r.SystemObjectRecordID == SystemObjectRecordID && 
                    r.CreatedByAccountID == AccountID).Count() > 0)
                    result = true;
            }
            return result;
        }

        public int GetCurrentRating(int SystemObjectID, long SystemObjectRecordID)
        {
            double result;
            using(FisharooDataContext dc = conn.GetContext())
            {
                if (dc.Ratings.Where(r => r.SystemObjectID == SystemObjectID && r.SystemObjectRecordID == SystemObjectRecordID).Count() > 0)
                    result =
                        dc.Ratings.Where(
                            r => r.SystemObjectID == SystemObjectID && r.SystemObjectRecordID == SystemObjectRecordID).
                            Select(r => r.Score).Average();
                else
                    result = 0;
            }
            return Convert.ToInt32(result);
        }

        public void SaveRatings(List<Rating> ratings)
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                //Unlike Linq to SQL, Linq to Entities donot allow expresion comparison hence first retrieving value in temp variable
                int varCreatedByAccountID = ratings[0].CreatedByAccountID;

                // get a list of items that have been rated before
                List<long> previouslyRatedSystemObjectRecordIDs = (dc.Ratings.Where
                                                                  (r => r.CreatedByAccountID == varCreatedByAccountID)
                                                                  .Select(r => r.SystemObjectRecordID)).ToList();


                foreach (Rating rating in ratings)
                {
                    //be sure that this user has not already rated this particular system object before
                    if (!previouslyRatedSystemObjectRecordIDs.Contains(rating.SystemObjectRecordID))
                    dc.Ratings.AddObject(rating);
                }
                dc.SaveChanges();
            }
        }

        public long SaveRating(Rating rating)
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                if (rating.RatingID > 0)
                {
                    dc.Ratings.Attach(rating);
                    dc.Ratings.ApplyCurrentValues(rating);
                }
                else
                {
                    dc.Ratings.AddObject(rating);
                }
                dc.SaveChanges();
            }
            return rating.RatingID;
        }

        public void DeleteRating(Rating rating)
        {
            using(FisharooDataContext dc = conn.GetContext())
            {
                dc.Ratings.Attach(rating);
                dc.Ratings.DeleteObject(rating);
                dc.SaveChanges();
            }
        }
    }
}
