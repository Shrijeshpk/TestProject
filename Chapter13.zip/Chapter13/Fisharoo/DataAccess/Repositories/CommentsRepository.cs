﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.DataAccess.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Repositories
{
    [Export(typeof(ICommentsRepository))]
    public class CommentsRepository : ICommentsRepository
    {
        private Connection conn;
        public CommentsRepository()
        {
            conn = new Connection();
        }

        public Comment GetCommentByID(long CommentID)
        {
            Comment result = null;
            using(FisharooDataContext dc = conn.GetContext())
            {
                result = dc.Comments.Where(c => c.CommentID == CommentID).FirstOrDefault();
            }
            return result;
        }

        public List<Comment> GetCommentsBySystemObject(int SystemObjectID, long SystemObjectRecordID)
        {
            List<Comment> results = null;
            using(FisharooDataContext dc = conn.GetContext())
            {
                results =
                    dc.Comments.Where(
                        c => c.SystemObjectID == SystemObjectID && c.SystemObjectRecordID == SystemObjectRecordID).
                        OrderByDescending(c => c.CreateDate).
                        ToList();
            }
            return results;
        }

        public long SaveComment(Comment comment)
        {
            using(FisharooDataContext dc = conn.GetContext())
            {
                if (comment.CommentID > 0)
                {
                    dc.Comments.Attach(comment);
                    dc.Comments.ApplyCurrentValues(comment);
                }
                else
                {
                    dc.Comments.AddObject(comment);
                }
                dc.SaveChanges();
            }
            return comment.CommentID;
        }

        public void DeleteComment(Comment comment)
        {
            using(FisharooDataContext dc = conn.GetContext())
            {
                dc.Comments.Attach(comment);
                dc.Comments.DeleteObject(comment);
                dc.SaveChanges();
            }
        }
    }
}
