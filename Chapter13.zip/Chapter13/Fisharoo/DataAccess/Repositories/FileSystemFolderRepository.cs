﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.DataAccess.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Repositories
{
    //CHAPTER 7
    [Export(typeof(IFileSystemFolderRepository))]
    public class FileSystemFolderRepository : IFileSystemFolderRepository
    {
        private Connection _conn;
        public FileSystemFolderRepository()
        {
            _conn = new Connection();
        }

        public FileSystemFolder GetFileSystemFolderByID(Int32 FileSystemFolderID)
        {
            throw new Exception("GetFileSystemFolderByID is not implemented!");
        }

        public void SaveFileSystemFolder(FileSystemFolder FileSystemFolder)
        {
            throw new Exception("SaveFileSystemFolder is not implemented!");
        }

        public void DeleteFileSystemFolder(FileSystemFolder FileSystemFolder)
        {
            throw new Exception("DeleteFileSystemFolder is not implemented!");
        }
    }
}