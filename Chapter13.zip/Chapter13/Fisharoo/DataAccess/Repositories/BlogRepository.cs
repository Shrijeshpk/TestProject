﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Repositories
{
    [Export(typeof(IBlogRepository))]
    public class BlogRepository : IBlogRepository
    {
        private Connection _conn;
        public BlogRepository()
        {
            _conn = new Connection();
        }

        //CHAPTER 13
        public List<Blog> GetBlogsForIndexing(int PageNumber)
        {
            List<Blog> results = new List<Blog>();
            using (FisharooDataContext dc = _conn.GetContext())
            {
                results = dc.Blogs.Skip(100 * (PageNumber - 1)).Take(100).ToList();
            }
            return results;
        }

        public Blog GetBlogByPageName(string PageName, Int32 AccountID)
        {
            Blog result = new Blog();
            using(FisharooDataContext dc = _conn.GetContext())
            {
                result = dc.Blogs.Include("Account").Where(b => b.PageName == PageName && b.AccountID == AccountID).FirstOrDefault();
                //we can do this since there will be only one result
                result.account = result.Account;
            }
            return result;
        }

        public Blog GetBlogByBlogID(Int64 BlogID)
        {
            Blog result = null;
            using (FisharooDataContext dc = _conn.GetContext())
            {
                result = dc.Blogs.Include("Account").Where(b => b.BlogID == BlogID).FirstOrDefault();
                //we can do this since there will be only one result
                result.account = result.Account;
            }
            return result;
        }

        public List<Blog> GetLatestBlogs()
        {
            List<Blog> result = new List<Blog>();    
            using(FisharooDataContext dc = _conn.GetContext())
            {
                IEnumerable<Blog> blogs = (from b in dc.Blogs
                                           where b.IsPublished
                                           orderby b.UpdateDate descending
                                           select b).Take(30);
                IEnumerable<Account> accounts =
                    dc.Accounts.Where(a => blogs.Select(b => b.AccountID).Distinct().Contains(a.AccountID));
                foreach (Blog blog in blogs)
                {
                    blog.Account = accounts.Where(a => a.AccountID == blog.AccountID).FirstOrDefault();
                    blog.account = blog.Account; //this is done to access account outside ObjectContext
                }
                result = blogs.ToList();
            }
            return result;
        }

        public List<Blog> GetBlogsByAccountID(Int32 AccountID)
        {
            List<Blog> result = new List<Blog>();
            using(FisharooDataContext dc = _conn.GetContext())
            {
                IEnumerable<Blog> blogs = dc.Blogs.Where(b => b.AccountID == AccountID).OrderByDescending(b => b.CreateDate);
                Account account = dc.Accounts.Where(a => a.AccountID == AccountID).FirstOrDefault();
                foreach (Blog blog in blogs)
                {
                    blog.Account = account;
                    blog.account = account;
                }
                result = blogs.ToList();
            }
            return result;
        }

        public bool CheckPageNameIsUnique(Blog blog)
        {
            blog = CleanPageName(blog);
            bool result = true;
            using(FisharooDataContext dc = _conn.GetContext())
            {
                int count = dc.Blogs.Where(b => b.PageName == blog.PageName 
                            && b.AccountID == blog.AccountID).Count();
                if(count > 0)
                    result = false;
            }
            return result;
        }

        private Blog CleanPageName(Blog blog)
        {
            blog.PageName = blog.PageName.Replace(" ", "-").Replace("!", "")
                            .Replace("&", "").Replace("?", "").Replace(",", "").Replace(".", "");
            return blog;
        }

        public Int64 SaveBlog(Blog blog)
        {
            blog = CleanPageName(blog);
            string post = blog.Post.Replace("<body>", "").Replace("<br /></body>", "").Replace("<html>", "")
                          .Replace("</html>", "").Replace("<head>", "").Replace("</head>", "");
            blog.Post = post;
            using (FisharooDataContext dc = _conn.GetContext())
            {
                if (blog.BlogID > 0)
                {
                    blog.UpdateDate = DateTime.Now;
                    dc.Blogs.Attach(new Blog { BlogID = blog.BlogID });
                    dc.Blogs.ApplyCurrentValues(blog);
                }
                else
                {
                    blog.CreateDate = DateTime.Now;
                    blog.UpdateDate = DateTime.Now;
                    dc.Blogs.AddObject(blog);
                }
                dc.SaveChanges();
            }
            return blog.BlogID;
        }

        public void DeleteBlog(Int64 BlogID)
        {
            using (FisharooDataContext dc = _conn.GetContext())
            {
                Blog blog = dc.Blogs.Where(b => b.BlogID == BlogID).FirstOrDefault();
                dc.Blogs.DeleteObject(blog);
                dc.SaveChanges();
            }
        }

        public void DeleteBlog(Blog blog)
        {
            using (FisharooDataContext dc = _conn.GetContext())
            {
                dc.Blogs.Attach(blog);
                dc.Blogs.DeleteObject(blog);
                dc.SaveChanges();
            }
        }
    }
}
