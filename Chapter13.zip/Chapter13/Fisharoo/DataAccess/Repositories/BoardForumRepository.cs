﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Repositories
{
    [Export(typeof(IBoardForumRepository))]
    public class BoardForumRepository : IBoardForumRepository
    {
        private Connection _conn;
        public BoardForumRepository()
        {
            _conn = new Connection();
        }

        //CHAPTER 10
        public BoardForum GetForumByGroupID(Int32 GroupID)
        {
            BoardForum result;
            using (FisharooDataContext dc = _conn.GetContext())
            {
                BoardForum forum = (from f in dc.BoardForums
                                    join gf in dc.GroupForums on f.ForumID equals gf.ForumID
                                    where gf.GroupID == GroupID
                                    select f).FirstOrDefault();
                result = forum;
            }
            return result;
        }

        public BoardForum GetForumByID(Int32 ForumID)
        {
            BoardForum result;
            using(FisharooDataContext dc = _conn.GetContext())
            {
                BoardForum forum = dc.BoardForums.Where(f => f.ForumID == ForumID).FirstOrDefault();
                result = forum;
            }
            return result;
        }

        public BoardForum GetForumByPageName(string PageName)
        {
            BoardForum result;
            using (FisharooDataContext dc = _conn.GetContext())
            {
                BoardForum forum = dc.BoardForums.Where(f => f.PageName == PageName).FirstOrDefault();
                result = forum;
            }
            return result;
        }
        
        public BoardForum GetForumByName(string Name)
        {
            BoardForum result;
            using (FisharooDataContext dc = _conn.GetContext())
            {
                BoardForum forum = dc.BoardForums.Where(f => f.Name == Name).FirstOrDefault();
                result = forum;
            }
            return result;
        }

        public List<BoardForum> GetForumsByCategoryID(Int32 CategoryID)
        {
            List<BoardForum> results;
            using(FisharooDataContext dc = _conn.GetContext())
            {
                IEnumerable<BoardForum> forums = dc.BoardForums.Where(f => f.CategoryID == CategoryID);
                results = forums.ToList();
            }
            return results;
        }

        public List<BoardForum> GetAllForums()
        {
            List<BoardForum> results;
            using(FisharooDataContext dc = _conn.GetContext())
            {
                IEnumerable<BoardForum> forums = dc.BoardForums;
                results = forums.ToList();
            }
            return results;
        }

        public Int32 SaveForum(BoardForum boardForum)
        {
            using (FisharooDataContext dc = _conn.GetContext())
            {
                if (boardForum.ForumID > 0)
                {
                    dc.BoardForums.Attach(new BoardForum { ForumID = boardForum.ForumID });
                    dc.BoardForums.ApplyCurrentValues(boardForum);
                }
                else
                {
                    dc.BoardForums.AddObject(boardForum);
                }
                dc.SaveChanges();
            }
            return boardForum.ForumID;
        }

        public void DeleteForum(BoardForum boardForum)
        {
            using (FisharooDataContext dc = _conn.GetContext())
            {
                dc.BoardForums.Attach(boardForum);
                dc.BoardForums.DeleteObject(boardForum);
                dc.SaveChanges();
            }
        }
    }
}
