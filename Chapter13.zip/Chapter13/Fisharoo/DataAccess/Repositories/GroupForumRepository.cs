﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Repositories
{
    //CHAPTER 10
    [Export(typeof(IGroupForumRepository))]
    public class GroupForumRepository : IGroupForumRepository
    {
        private Connection conn;
        public GroupForumRepository()
        {
            conn = new Connection();
        }

        public int GetGroupIdByForumID(int ForumID)
        {
            int result = 0;
            using(FisharooDataContext dc = conn.GetContext())
            {
                result = dc.GroupForums.Where(gf => gf.ForumID == ForumID).Select(gf => gf.GroupID).FirstOrDefault();
            }
            return result;
        }

        public void SaveGroupForum(GroupForum groupForum)
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                if (dc.GroupForums.Where(gf => gf.ForumID == groupForum.ForumID
                                         && gf.GroupID == groupForum.GroupID).FirstOrDefault() == null)
                {
                    dc.GroupForums.AddObject(groupForum);
                    dc.SaveChanges();
                }
            }
        }

        public void DeleteGroupForum(int ForumID, int GroupID)
        {
            //usually only one row will match
            using (FisharooDataContext dc = conn.GetContext())
            {
                dc.GroupForums.DeleteObject(dc.GroupForums.Where(gf => gf.GroupID == GroupID && gf.ForumID == ForumID).FirstOrDefault());
                dc.SaveChanges();
            }
        }

        public void DeleteGroupForum(GroupForum groupForum)
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                dc.GroupForums.Attach(groupForum);
                dc.GroupForums.DeleteObject(groupForum);
                dc.SaveChanges();
            }
        }
    }
}
