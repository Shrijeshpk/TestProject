﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Repositories
{
    [Export(typeof(IAccountRepository))]
    public class AccountRepository : IAccountRepository
    {
        private Connection conn;

        public AccountRepository()
        {
            conn = new Connection();
        }

        //CHAPTER 10
        public List<Account> GetApprovedAccountsByGroupID(int GroupID, int PageNumber, int NumberOfRecordsInPage)
        {
            List<Account> result = null;
            using (FisharooDataContext dc = conn.GetContext())
            {
                IEnumerable<Account> accounts = (from a in dc.Accounts
                                                 join m in dc.GroupMembers on a.AccountID equals m.AccountID
                                                 where m.GroupID == GroupID && m.IsApproved
                                                 orderby a.AccountID
                                                 select a).Skip((NumberOfRecordsInPage * (PageNumber - 1)))
                                                 .Take(NumberOfRecordsInPage);
                result = accounts.ToList();
            }
            return result;
        }

        //CHAPTER 10
        public List<Account> GetAccountsToApproveByGroupID(int GroupID)
        {
            List<Account> result = null;
            using (FisharooDataContext dc = conn.GetContext())
            {
                IEnumerable<Account> accounts = (from a in dc.Accounts
                                                 join m in dc.GroupMembers on a.AccountID equals m.AccountID
                                                 where m.GroupID == GroupID && !m.IsApproved
                                                 select a);
                result = accounts.ToList();
            }
            return result;
        }


        public Account GetAccountByID(int AccountID)
        {
            Account account = null;

            using (FisharooDataContext dc = conn.GetContext())
            {
                account = (from a in dc.Accounts.Include("AccountPermissions.Permission").Include("Profiles")
                           where a.AccountID == AccountID
                           select a).FirstOrDefault();

                SetNavigationalProperties(account);

            }
            return account;
        }

        public Account GetAccountByEmail(string Email)
        {
            Account account = null;

            using (FisharooDataContext dc = conn.GetContext())
            {
                account = (from a in dc.Accounts.Include("AccountPermissions.Permission").Include("Profiles")
                           where a.Email.Equals(Email)
                           select a).FirstOrDefault();
                if (account != null)
                {
                SetNavigationalProperties(account);
                }
            }
            return account;
        }

        //CHAPTER 5
        public List<Account> SearchAccounts(string SearchText)
        {
            List<Account> result = new List<Account>();
            using (FisharooDataContext dc = conn.GetContext())
            {
                IEnumerable<Account> accounts = from a in dc.Accounts
                                                where (a.FirstName + " " + a.LastName).Contains(SearchText) ||
                                                    a.Email.Contains(SearchText) ||
                                                    a.Username.Contains(SearchText)
                                                select a;
                result = accounts.ToList();
            }
            return result;
        }

        public Account GetAccountByUsername(string Username)
        {
            Account account = null;

            using (FisharooDataContext dc = conn.GetContext())
            {
                account = (from a in dc.Accounts.Include("AccountPermissions.Permission").Include("Profiles")
                    where a.Username.Equals(Username)
                    select a).FirstOrDefault();
                if (account != null)
                {
                    SetNavigationalProperties(account);
                }
            }

            return account;
        }

        public void AddPermission(Account account, Permission permission)
        {
            using(FisharooDataContext dc = conn.GetContext())
            {
                AccountPermission ap = new AccountPermission();
                ap.AccountID = account.AccountID;
                ap.PermissionID = permission.PermissionID;
                dc.AccountPermissions.AddObject(ap);                         
                dc.SaveChanges();
            }
        }


        public void SaveAccount(Account account)
        {
            using(FisharooDataContext dc = conn.GetContext())
            {
                if(account.AccountID > 0)
                {
                    dc.Accounts.Attach(new Account { AccountID = account.AccountID });
                    dc.Accounts.ApplyCurrentValues(account);
                }
                else
                {
                    dc.Accounts.AddObject(account);
                }
                dc.SaveChanges();
            }
        }

        public void DeleteAccount(Account account)
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                dc.Accounts.DeleteObject(dc.Accounts.Where
                                        (ac=>ac.AccountID.Equals(account.AccountID)).FirstOrDefault());
                dc.SaveChanges();
             }
        }

        public List<Account> GetAllAccounts(Int32 PageNumber)
        {
            IEnumerable<Account> accounts = null;

            using (FisharooDataContext dc = conn.GetContext())
            {
                 accounts = (from a in dc.Accounts
                             orderby a.Username
                             select a).Skip((PageNumber - 1) * 10).Take(10);
            }
            return accounts.ToList();
        }
        
        private static void SetNavigationalProperties(Account account)
        {
            foreach (AccountPermission ap in account.AccountPermissions)
            {
                account.Permissions.Add(ap.Permission);
            }
            account.Profile = account.Profiles.FirstOrDefault();
            //need to set values within the Profile object as well
            if (account.Profile != null)
            {
                foreach (ProfileAttribute item in account.Profile.ProfileAttributes)
                {
                    account.Profile.Attributes.Add(item);
                    item.profileAttributeType = item.ProfileAttributeType;
                }
                account.Profile.levelOfExperienceType = account.Profile.LevelOfExperienceType;
            }
        }

    }
}
