﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.DataAccess.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Repositories
{
    //CHAPTER 5
    [Export(typeof(IFriendRepository))]
    public class FriendRepository : IFriendRepository
    {
        private Connection conn;
        public FriendRepository()
        {
            conn = new Connection();
        }

        public Friend GetFriendByID(Int32 FriendID)
        {
            Friend result;

            using(FisharooDataContext dc = conn.GetContext())
            {
                result = dc.Friends.Where(f => f.FriendID == FriendID).FirstOrDefault();
            }

            return result;
        }

        public List<Friend> GetFriendsByAccountID(Int32 AccountID)
        {
            List<Friend> result = new List<Friend>();
            using (FisharooDataContext dc = conn.GetContext())
            {
                //Get my friends direct relationship
                IEnumerable<Friend> friends = (from f in dc.Friends
                                               where f.AccountID == AccountID &&
                                               f.MyFriendsAccountID != AccountID
                                               select f).Distinct();
                result = friends.ToList();

               
                ////Getmy friends indirect relationship

                IEnumerable<Friend> friends2 = (from f in dc.Friends
                                                where f.MyFriendsAccountID == AccountID &&
                                                f.AccountID != AccountID
                                                select f).Distinct();

                foreach (Friend f in friends2)
                {
                    if (f != null)
                    {
                        var tempFriendsAccountId = f.MyFriendsAccountID;
                        var tempAccountId = f.AccountID;
                        f.AccountID = tempFriendsAccountId;
                        f.MyFriendsAccountID = tempAccountId;
                        result.Add(f);
                    }
                }
            }
            return result;
        }

        public List<Account> GetFriendsAccountsByAccountID(Int32 AccountID)
        {
            List<Friend> friends = GetFriendsByAccountID(AccountID);
            List<int> accountIDs = new List<int>();
            foreach (Friend friend in friends)
            {
                accountIDs.Add(friend.MyFriendsAccountID);
            }

            List<Account> result = new List<Account>();
            using(FisharooDataContext dc = conn.GetContext())
            {
                IEnumerable<Account> accounts = from a in dc.Accounts 
                                                where accountIDs.Contains(a.AccountID)
                                                select a;
                result = accounts.ToList();
            }
            return result;
        }

        public void SaveFriend(Friend friend)
        {
           using(FisharooDataContext dc = conn.GetContext())
           {
                if(friend.FriendID > 0)
                {
                    dc.Friends.Attach(new Friend { FriendID = friend.FriendID });
                    dc.Friends.ApplyCurrentValues(friend);
                }
                else
                {
                    friend.CreateDate = DateTime.Now;
                    dc.Friends.AddObject(friend);
                }
                dc.SaveChanges();
            }
        }

        public void DeleteFriend(Friend friend)
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                dc.Friends.DeleteObject(friend);
                dc.SaveChanges();
            }
        }

        public void DeleteFriendByID(Int32 AccountIDToRemoveFriendFrom, Int32 FriendIDToRemove)
        {
            List<Friend> workingList = new List<Friend>();
            using(FisharooDataContext dc = conn.GetContext())
            {
                //get all friend relationships
                IEnumerable<Friend> friends = from f in dc.Friends
                                    where (f.AccountID == AccountIDToRemoveFriendFrom &&
                                    f.MyFriendsAccountID == FriendIDToRemove) ||
                                    (f.AccountID == FriendIDToRemove &&
                                    f.MyFriendsAccountID == AccountIDToRemoveFriendFrom)
                                    select f;

                workingList = friends.ToList();
            }

            foreach (Friend friend in workingList)
            {
                DeleteFriend(friend);
            }
        }
    }
}
