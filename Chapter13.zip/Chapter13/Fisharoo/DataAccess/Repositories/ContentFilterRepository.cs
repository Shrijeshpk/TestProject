﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.DataAccess.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Repositories
{
    //CHAPTER 12
    [Export(typeof(IContentFilterRepository))]
    public class ContentFilterRepository : IContentFilterRepository
    {
        private Connection _conn;
        public ContentFilterRepository()
        {
            _conn = new Connection();
        }

        public List<ContentFilter> GetContentFilters()
        {
            List<ContentFilter> filters = new List<ContentFilter>();
            using (FisharooDataContext dc = _conn.GetContext())
            {
                filters = dc.ContentFilters.ToList();
            }
            return filters;
        }
    }
}
