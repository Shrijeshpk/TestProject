﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Fisharoo.DataAccess.Interfaces;
using System.ComponentModel.Composition;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Repositories
{
    [Export(typeof(ISystemObjectTagRepository))]
    public class SystemObjectTagRepository : ISystemObjectTagRepository
    {
        private Connection conn;
        public SystemObjectTagRepository()
        {
            conn = new Connection();
        }

        public List<SystemObjectTagWithObject> GetSystemObjectsByTagID(int TagID)
        {
            List<SystemObjectTagWithObject> result = new List<SystemObjectTagWithObject>();
            List<SystemObjectTag> tags;

            List<Account> accounts;
            List<Profile> profiles;
            List<Blog> blogs;
            List<BoardPost> posts;
            List<File> files;
            List<FileType> fileTypes;
            List<Folder> folders;
            List<Group> groups;
            List<long> SystemObjectTags;

            using (FisharooDataContext dc = conn.GetContext())
            {
                tags =
                    dc.SystemObjectTags.Where(sot => sot.TagID == TagID).
                    OrderByDescending(sot => sot.CreateDate).ToList();

                SystemObjectTags = GetSystemObjectSpecificTags(1, tags);
                accounts = dc.Accounts.Where(a => SystemObjectTags.Contains(a.AccountID)).ToList();
                
                SystemObjectTags = GetSystemObjectSpecificTags(2, tags);
                profiles = dc.Profiles.Where(a => SystemObjectTags.Contains(a.AccountID)).ToList();

                SystemObjectTags = GetSystemObjectSpecificTags(3, tags);
                blogs = dc.Blogs.Where( b=> SystemObjectTags.Contains(b.BlogID)).ToList();

                SystemObjectTags = GetSystemObjectSpecificTags(4, tags);    
                posts = dc.BoardPosts.Where(bp => SystemObjectTags.Contains(bp.PostID)).ToList();

                SystemObjectTags = GetSystemObjectSpecificTags(5, tags);    
                files = dc.Files.Where(f => SystemObjectTags.Contains(f.FileID)).ToList();
                
                fileTypes = dc.FileTypes.ToList();
                for (int i = 0; i < files.Count(); i++)
                {
                    files[i].Extension =
                        fileTypes.Where(ft => ft.FileTypeID == files[i].FileTypeID).Select(ft => ft.Name).FirstOrDefault();
                }

                List<long> tempfiles = files.Select(f => f.DefaultFolderID).ToList();
                folders = dc.Folders.Where(folder => tempfiles.Contains(folder.FolderID)).ToList();
                

                SystemObjectTags = GetSystemObjectSpecificTags(6, tags);
                groups = dc.Groups.Where(g => SystemObjectTags.Contains(g.GroupID)).ToList();
            }

            foreach (SystemObjectTag tag in tags)
            {
                switch (tag.SystemObjectID)
                {
                    case 1:
                        result.Add(new SystemObjectTagWithObject() { SystemObjectTag = tag, Account = accounts.Where(a => a.AccountID == tag.SystemObjectRecordID).FirstOrDefault() });
                        break;

                    case 2:
                        result.Add(new SystemObjectTagWithObject() { SystemObjectTag = tag, Profile = profiles.Where(p => p.ProfileID == tag.SystemObjectRecordID).FirstOrDefault() });
                        break;

                    case 3:
                        result.Add(new SystemObjectTagWithObject() { SystemObjectTag = tag, Blog = blogs.Where(b => b.BlogID == tag.SystemObjectRecordID).FirstOrDefault() });
                        break;

                    case 4:
                        result.Add(new SystemObjectTagWithObject() { SystemObjectTag = tag, BoardPost = posts.Where(p => p.PostID == tag.SystemObjectRecordID).FirstOrDefault() });
                        break;

                    case 5:
                        //need to get the file for use in getting the folder as well
                        File file = files.Where(f => f.FileID == tag.SystemObjectRecordID).FirstOrDefault();
                        result.Add(new SystemObjectTagWithObject()
                        {
                            SystemObjectTag = tag,
                            File = file,
                            Folder =
                                folders.Where(f => f.FolderID == file.DefaultFolderID).FirstOrDefault()
                        });
                        break;

                    case 6:
                        result.Add(new SystemObjectTagWithObject() { SystemObjectTag = tag, Group = groups.Where(g => g.GroupID == tag.SystemObjectRecordID).FirstOrDefault() });
                        break;
                }
            }
            return result;
        }

        public long SaveSystemObjectTag(SystemObjectTag tag)
        {
            using(FisharooDataContext dc = conn.GetContext())
            {
                if(tag.SystemObjectTagID > 0)
                {
                    dc.SystemObjectTags.Attach(tag);
                    dc.SystemObjectTags.ApplyCurrentValues(tag);
                }
                else if (dc.SystemObjectTags.Where(sot => sot.CreatedByAccountID == tag.CreatedByAccountID &&
                    sot.SystemObjectID == tag.SystemObjectID &&
                    sot.SystemObjectRecordID == tag.SystemObjectRecordID &&
                    sot.TagID == tag.TagID).FirstOrDefault() == null)
                {
                    dc.SystemObjectTags.AddObject(tag);
                }
                dc.SaveChanges();
            }
            return tag.SystemObjectTagID;
        }

        public void DeleteSystemObjectTag(SystemObjectTag tag)
        {
            using(FisharooDataContext dc = conn.GetContext())
            {
                dc.SystemObjectTags.Attach(tag);
                dc.SystemObjectTags.DeleteObject(tag);
                dc.SaveChanges();
            }
        }

        private List<long> GetSystemObjectSpecificTags(int SystemObjectId, List<SystemObjectTag> tags)
        {
            return tags.Where(t => t.SystemObjectID == SystemObjectId).Select(t => t.SystemObjectRecordID).ToList();
        }
    }
}
