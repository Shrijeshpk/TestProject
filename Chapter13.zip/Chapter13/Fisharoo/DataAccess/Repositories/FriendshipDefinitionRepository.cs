﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Repositories
{
    //CHAPTER 5
    [Export(typeof(IFriendshipDefinitionRepository))]
    public class FriendshipDefinitionRepository : IFriendshipDefinitionRepository
    {
        private Connection conn;
        public FriendshipDefinitionRepository()
        {
            conn = new Connection();
        }

        public FriendshipDefinition GetFriendshipDefinitionByID(Int32 FriendshipDefinitionID)
        {
            FriendshipDefinition result;
            using(FisharooDataContext dc = conn.GetContext())
            {
                result = dc.FriendshipDefinitions.Where(fd => fd.FriendshipDefinitionID == FriendshipDefinitionID).FirstOrDefault();
            }
            return result;
        }

        public List<FriendshipDefinition> GetFriendshipDefinitionsByFriendID(Int32 FriendID)
        {
            List<FriendshipDefinition> result = new List<FriendshipDefinition>();
            using(FisharooDataContext dc = conn.GetContext())
            {
                IEnumerable<FriendshipDefinition> friendshipDefinitions = dc.FriendshipDefinitions.Where(fd => fd.FriendID == FriendID);
                result = friendshipDefinitions.ToList();
            }
            return result;
        }

        public void SaveFriendshipDefinition(FriendshipDefinition friendshipDefinition)
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                if (friendshipDefinition.FriendshipDefinitionID > 0)
                {
                    dc.FriendshipDefinitions.Attach(new FriendshipDefinition 
                                                   {FriendshipDefinitionID = friendshipDefinition.FriendshipDefinitionID });
                    dc.FriendshipDefinitions.ApplyCurrentValues(friendshipDefinition);
                }
                else
                {
                    friendshipDefinition.CreateDate = DateTime.Now;
                    dc.FriendshipDefinitions.AddObject(friendshipDefinition);
                }
                dc.SaveChanges();
            }
        }

        public void DeleteFriendshipDefinintion(FriendshipDefinition friendshipDefinition)
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                dc.FriendshipDefinitions.DeleteObject(dc.FriendshipDefinitions.Where
                                                     (fd=>fd.FriendshipDefinitionID.Equals
                                                     (friendshipDefinition.FriendshipDefinitionID)).FirstOrDefault());
                dc.SaveChanges();
            }
        }
    }
}
