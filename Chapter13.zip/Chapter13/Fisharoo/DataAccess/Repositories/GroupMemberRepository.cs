﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Repositories
{
    //CHAPTER 10
    [Export(typeof(IGroupMemberRepository))]
    public class GroupMemberRepository : IGroupMemberRepository
    {
        private Connection conn;
        public GroupMemberRepository()
        {
            conn = new Connection();
        }

        public List<int> GetMemberAccountIDsByGroupID(Int32 GroupID)
        {
            List<int> result = new List<int>();    
            using(FisharooDataContext dc = conn.GetContext())
            {
                result = dc.GroupMembers.Where(gm => gm.IsApproved && gm.GroupID == GroupID).Select(gm => gm.AccountID).ToList();
                result.Add(dc.Groups.Where(g => g.GroupID == GroupID).Select(gm => gm.AccountID).FirstOrDefault());
            }
            return result;
        }

        public bool IsMember(Int32 AccountID, Int32 GroupID)
        {
            bool result = false;
            using(FisharooDataContext dc = conn.GetContext())
            {
                if (dc.GroupMembers.Where(gm => gm.AccountID == AccountID && gm.GroupID == GroupID && gm.IsApproved).FirstOrDefault() != null)
                    result = true;
            }
            return result;
        }

        public bool IsAdministrator(Int32 AccountID, Int32 GroupID)
        {
            bool result = false;
            using(FisharooDataContext dc = conn.GetContext())
            {
                if (dc.GroupMembers.Where(gm => gm.AccountID == AccountID && 
                    gm.GroupID == GroupID && 
                    gm.IsAdmin && 
                    gm.IsApproved).FirstOrDefault() != null)
                    result = true;
            }
            return result;
        }

        public void DeleteGroupMembers(List<int> MembersToDelete, int GroupID)
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                IEnumerable<GroupMember> members =
                    dc.GroupMembers.Where(gm => MembersToDelete.Contains(gm.AccountID) && gm.GroupID == GroupID);
                foreach (GroupMember grpmember in members)
                {
                    dc.GroupMembers.DeleteObject(grpmember);
                }
                dc.SaveChanges();
            }
        }

        public void ApproveGroupMembers(List<int> MembersToApprove, int GroupID)
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                IEnumerable<GroupMember> members =
                    dc.GroupMembers.Where(gm => MembersToApprove.Contains(gm.AccountID) && gm.GroupID == GroupID);
                foreach (GroupMember member in members)
                {
                    member.IsApproved = true;
                }
                dc.SaveChanges();
            }
        }

        public void PromoteGroupMembersToAdmin(List<int> MembersToPromote, int GroupID)
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                IEnumerable<GroupMember> members =
                    dc.GroupMembers.Where(gm => MembersToPromote.Contains(gm.AccountID) && gm.GroupID == GroupID);
                foreach (GroupMember member in members)
                {
                    member.IsAdmin = true;
                }
                dc.SaveChanges();
            }
        }

        public void DemoteGroupMembersFromAdmin(List<int> MembersToDemote, int GroupID)
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                IEnumerable<GroupMember> members =
                    dc.GroupMembers.Where(gm => MembersToDemote.Contains(gm.AccountID) && gm.GroupID == GroupID);
                foreach (GroupMember member in members)
                {
                    member.IsAdmin = false;
                }
                dc.SaveChanges();
            }
        }

        public void SaveGroupMember(GroupMember groupMember)
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                if (dc.GroupMembers.Where(gm => gm.GroupID == groupMember.GroupID 
                                          && gm.AccountID == groupMember.AccountID).FirstOrDefault() == null)
                {
                    dc.GroupMembers.AddObject(groupMember);
                    Group group = dc.Groups.Where(g => g.GroupID == groupMember.GroupID).FirstOrDefault();
                    group.MemberCount++;
                    dc.SaveChanges();
                }
            }
        }
        
        public void DeleteAllGroupMembersForGroup(int GroupID)
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                dc.GroupMembers.DeleteObject(dc.GroupMembers.Where(gm => gm.GroupID == GroupID).FirstOrDefault());
                dc.SaveChanges();
            }
        }

        public void DeleteGroupMember(GroupMember groupMember)
        {
            using (FisharooDataContext dc = conn.GetContext())
            {
                dc.GroupMembers.Attach(groupMember);
                dc.GroupMembers.DeleteObject(groupMember);
                dc.SaveChanges();
            }
        }
        
    }
}
