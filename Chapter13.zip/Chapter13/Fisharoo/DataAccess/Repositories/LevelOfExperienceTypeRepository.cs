﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.Composition;
using Fisharoo.DataAccess.Interfaces;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess
{
    [Export(typeof(ILevelOfExperienceTypeRepository))]
    public class LevelOfExperienceTypeRepository : ILevelOfExperienceTypeRepository
    {
        private Connection conn;
        public LevelOfExperienceTypeRepository()
        {
            conn = new Connection();
        }

        public List<LevelOfExperienceType> GetAllLevelOfExperienceTypes()
        {
            List<LevelOfExperienceType> types;
            using(FisharooDataContext dc = conn.GetContext())
            {
                IEnumerable<LevelOfExperienceType> result = dc.LevelOfExperienceTypes.OrderBy(l => l.SortOrder);
                types = result.ToList();
            }
            return types;
        }

        public LevelOfExperienceType GetLevelOfExperienceTypeByID(int LevelOfExperienceTypeID)
        {
            LevelOfExperienceType result;
            using(FisharooDataContext dc = conn.GetContext())
            {
                result = dc.LevelOfExperienceTypes.Where
                         (l => l.LevelOfExperienceTypeID == LevelOfExperienceTypeID).FirstOrDefault();
            }
            return result;
        }

        public void SaveLevelOfExperienceType(LevelOfExperienceType levelOfExperienceType)
        {
            using(FisharooDataContext dc = conn.GetContext())
            {
                if(levelOfExperienceType.LevelOfExperienceTypeID > 0)
                {
                    dc.LevelOfExperienceTypes.Attach(new LevelOfExperienceType 
                                                    {LevelOfExperienceTypeID = levelOfExperienceType.LevelOfExperienceTypeID });
                    dc.LevelOfExperienceTypes.ApplyCurrentValues(levelOfExperienceType);
                }
                else
                {
                    dc.LevelOfExperienceTypes.AddObject(levelOfExperienceType);
                }
                dc.SaveChanges();
            }
        }

        public void DeleteLevelOfExperienceType(LevelOfExperienceType levelOfExperienceType)
        {
           
            using(FisharooDataContext dc = conn.GetContext())
            {
                dc.LevelOfExperienceTypes.DeleteObject(dc.LevelOfExperienceTypes.Where
                                                      (let=>let.LevelOfExperienceTypeID.Equals
                                                      (levelOfExperienceType.LevelOfExperienceTypeID)).FirstOrDefault());
                dc.SaveChanges();
            }
        }
    }
}
