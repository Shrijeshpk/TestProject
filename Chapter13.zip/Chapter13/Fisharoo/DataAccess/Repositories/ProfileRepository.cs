﻿using System;
using System.ComponentModel.Composition;
using System.Linq;
using Fisharoo.DataAccess.Interfaces;
using System.Collections.Generic;
using Fisharoo.Entities;


namespace Fisharoo.DataAccess.Repositories
{
    [Export(typeof(IProfileRepository))] 
    public class ProfileRepository : IProfileRepository
    {
        private Connection conn;
        public ProfileRepository()
        {
            conn = new Connection();
        }

        //CHAPTER 13
        public List<Profile> GetProfilesForIndexing(int PageNumber)
        {
            List<Profile> results = new List<Profile>();
            using (FisharooDataContext dc = conn.GetContext())
            {
                results = dc.Profiles.Skip(100 * (PageNumber - 1)).Take(100).ToList();
            }
            return results;
        }

        public Profile GetProfileByAccountID(int AccountID)
        {
            Profile profile;

            using (FisharooDataContext dc = conn.GetContext())
            {
                profile = (from p in dc.Profiles.Include("ProfileAttributes.ProfileAttributeType").Include("LevelOfExperienceType")
                           where p.AccountID == AccountID
                           select p).FirstOrDefault();
            }
            if (profile != null)
            {
                foreach (ProfileAttribute item in profile.ProfileAttributes)
                {
                    profile.Attributes.Add(item);
                    item.profileAttributeType = item.ProfileAttributeType;
                }
                profile.levelOfExperienceType = profile.LevelOfExperienceType;
            }

            return profile;
        }

        public Int32 SaveProfile(Profile profile)
        {
            Int32 profileID = 0;
            Boolean HasAttributeId = false;
            profile.LastUpdateDate = DateTime.Now;
            using(FisharooDataContext dc = conn.GetContext())
            {
                if (profile.ProfileID > 0)
                {
                    dc.Profiles.Attach(new Profile { ProfileID = profile.ProfileID }); 
                    dc.Profiles.ApplyCurrentValues(profile);
                    if (profile.Attributes != null)
                    {
                        foreach(ProfileAttribute item in profile.Attributes)
                        {
                            dc.ProfileAttributes.Attach(new ProfileAttribute
                                                        { ProfileAttributeID = item.ProfileAttributeID,
                                                        });
                            dc.ProfileAttributes.ApplyCurrentValues(item);
                        }
                    }
                }
                else
                {
                    profile.CreateDate = DateTime.Now;
                    //when working with new profile we don't expect attributes to be null, but check anyway
                    if (profile.Attributes != null)
                    {
                        foreach (ProfileAttribute item in profile.Attributes)
                        {
                            dc.ProfileAttributes.AddObject(new ProfileAttribute
                            {
                                ProfileAttributeID = item.ProfileAttributeID,
                                ProfileAttributeTypeID = item.ProfileAttributeTypeID,
                                ProfileID = item.ProfileID,
                                Response = item.Response,
                                CreateDate = item.CreateDate,
                                TimeStamp = item.TimeStamp
                            });
                            HasAttributeId = true;
                        }
                    }
                    dc.Profiles.AddObject(profile);
                }
                dc.SaveChanges();
                profileID = profile.ProfileID;
                if (HasAttributeId)
                {
                    var result = from pa in dc.ProfileAttributes.Include("ProfileAttributeType")
                                 where pa.ProfileID == profileID
                                 select pa;
                    profile.Attributes = result.ToList();
                    foreach (ProfileAttribute item in profile.ProfileAttributes)
                    {
                        item.profileAttributeType = item.ProfileAttributeType;
                    }
                }
            }
            return profileID;
        }

        public void DeleteProfile(Profile profile)
        {
            
            using (FisharooDataContext dc = conn.GetContext())
            {
                dc.Profiles.DeleteObject(dc.Profiles.Where(pf=>pf.ProfileID.Equals(profile.ProfileID)).FirstOrDefault());
                dc.SaveChanges();
            }
        }
    }
}
