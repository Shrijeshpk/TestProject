using System;
using System.Collections.Generic;
using Fisharoo.Entities;
namespace Fisharoo.DataAccess.Interfaces
{
    public interface IProfileRepository
    {
        Profile GetProfileByAccountID(int AccountID);
        Int32 SaveProfile(Profile profile);
        void DeleteProfile(Profile profile);
        //CHAPTER 13
        List<Profile> GetProfilesForIndexing(int PageNumber);
    }
}