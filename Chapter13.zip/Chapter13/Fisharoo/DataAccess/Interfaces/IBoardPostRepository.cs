using System;
using System.Collections.Generic;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Interfaces
{
    //CHAPTER 9
    public interface IBoardPostRepository
    {
        BoardPost GetPostByPageName(string PageName);
        BoardPost GetPostByID(long PostID);
        Int64 SavePost(BoardPost boardPost);
        void DeletePost(BoardPost boardPost);
        List<BoardPost> GetPostsByThreadID(Int64 ThreadID);
        List<BoardPost> GetThreadsByForumID(Int32 ForumID);
        bool CheckPostPageNameIsUnique(string PageName);
        //CHAPTER 10
        void DeletePostsByForumID(int ForumID);
    }
}