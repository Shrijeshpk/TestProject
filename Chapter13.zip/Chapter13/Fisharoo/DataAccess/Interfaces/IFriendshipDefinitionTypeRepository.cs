using System;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Interfaces
{
    public interface IFriendshipDefinitionTypeRepository
    {
        FriendshipDefinitionType GetFriendshipDefinitionTypeByID(Int32 FriendshipDefinitionTypeID);
    }
}