using System.Collections.Generic;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Interfaces
{
    //CHAPTER 11
    public interface ICommentsRepository
    {
        Comment GetCommentByID(long CommentID);
        List<Comment> GetCommentsBySystemObject(int SystemObjectID, long SystemObjectRecordID);
        long SaveComment(Comment comment);
        void DeleteComment(Comment comment);
    }
}