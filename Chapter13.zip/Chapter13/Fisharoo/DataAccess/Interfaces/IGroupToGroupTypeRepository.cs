using System.Collections.Generic;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Interfaces
{
    //CHAPTER 10
    public interface IGroupToGroupTypeRepository
    {
        void SaveGroupToGroupType(GroupToGroupType groupToGroupType);
        void DeleteGroupToGroupType(GroupToGroupType groupToGroupType );
        void SaveGroupTypesForGroup(List<long> SelectedGroupTypeIDs, int GroupID);
    }
}