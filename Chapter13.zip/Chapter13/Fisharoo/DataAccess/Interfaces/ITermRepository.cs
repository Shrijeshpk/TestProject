
using Fisharoo.Entities;
namespace Fisharoo.DataAccess.Interfaces
{
    public interface ITermRepository
    {
        Term GetCurrentTerm();
        void SaveTerm(Term term);
        void DeleteTerm(Term term);
    }
}