using System.Collections.Generic;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Interfaces
{
    //CHAPTER 11
    public interface ISystemObjectTagRepository
    {
        long SaveSystemObjectTag(SystemObjectTag tag);
        void DeleteSystemObjectTag(SystemObjectTag tag);
        List<SystemObjectTagWithObject> GetSystemObjectsByTagID(int TagID);
    }
}