
using Fisharoo.Entities;
namespace Fisharoo.DataAccess.Interfaces
{
    //CHAPTER 10
    public interface IGroupForumRepository
    {
        void SaveGroupForum(GroupForum groupForum);
        void DeleteGroupForum(GroupForum groupForum);
        int GetGroupIdByForumID(int ForumID);
        void DeleteGroupForum(int ForumID, int GroupID);
    }
}