using System;
using System.Collections.Generic;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Interfaces
{
    public interface IMessageRecipientRepository
    {
        List<MessageRecipient> GetMessageRecipientsByMessageID(Int32 MessageID);
        MessageRecipient GetMessageRecipientByID(Int32 MessageRecipientID);
        void SaveMessageRecipient(MessageRecipient messageRecipient);
        void DeleteMessageRecipient(MessageRecipient messageRecipient);
    }
}