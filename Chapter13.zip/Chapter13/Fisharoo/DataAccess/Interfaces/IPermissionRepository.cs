using System;
using System.Collections.Generic;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Interfaces
{
    public interface IPermissionRepository
    {
        List<Permission> GetPermissionsByAccountID(Int32 AccountID);
        //Chapter 4 modification. Changed from list to single object for below methods
        Permission GetPermissionByName(string Name);
        Permission GetPermissionByID(Int32 PermissionID);
        
        void SavePermission(Permission permission);
        void DeletePermission(Permission permission);
    }
}