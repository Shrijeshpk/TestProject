using System;
using System.Collections.Generic;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Interfaces
{
    public interface IFileRepository
    {
        File GetFileByID(Int64 FileID);
        File GetFileByFileSystemName(Guid FileSystemName);
        Int64 SaveFile(File file);
        void DeleteFilesInFolder(string FilePath, Folder folder);
        void DeleteFile(string FilePath, File file);
        List<File> GetFilesByFolderID(Int64 FolderID);
        void UpdateDescriptions(Dictionary<int, string> fileDescriptions);
        
    }
}