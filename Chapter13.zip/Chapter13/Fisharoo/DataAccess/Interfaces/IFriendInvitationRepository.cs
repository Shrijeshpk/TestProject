using System;
using System.Collections.Generic;
using Fisharoo.DataAccess;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Interfaces
{
    public interface IFriendInvitationRepository
    {
        List<FriendInvitation> GetFriendInvitationsByAccountID(Int32 AccountID);
        void SaveFriendInvitation(FriendInvitation friendInvitation);
        FriendInvitation GetFriendInvitationByGUID(Guid guid);
        void CleanUpFriendInvitationsForThisEmail(FriendInvitation friendInvitation);
    }
}