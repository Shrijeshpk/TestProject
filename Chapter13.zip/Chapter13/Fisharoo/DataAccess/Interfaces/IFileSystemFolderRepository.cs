using System;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Interfaces
{
    public interface IFileSystemFolderRepository
    {
        FileSystemFolder GetFileSystemFolderByID(Int32 FileSystemFolderID);
        void SaveFileSystemFolder(FileSystemFolder FileSystemFolder);
        void DeleteFileSystemFolder(FileSystemFolder FileSystemFolder);
    }
}