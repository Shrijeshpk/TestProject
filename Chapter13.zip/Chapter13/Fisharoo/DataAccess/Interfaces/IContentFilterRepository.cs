using System.Collections.Generic;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Interfaces
{
    //CHAPTER 12
    public interface IContentFilterRepository
    {
        List<ContentFilter> GetContentFilters();
    }
}