using System;
using System.Collections.Generic;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Interfaces
{
    public interface IBlogRepository
    {
        List<Blog> GetBlogsByAccountID(Int32 AccountID);
        Blog GetBlogByBlogID(Int64 BlogID);
        Int64 SaveBlog(Blog blog);
        void DeleteBlog(Blog blog);
        List<Blog> GetLatestBlogs();
        Blog GetBlogByPageName(string PageName, Int32 AccountID);
        bool CheckPageNameIsUnique(Blog blog);
        void DeleteBlog(Int64 BlogID);
        //CHAPTER 13
        List<Blog> GetBlogsForIndexing(int PageNumber);
    }
}