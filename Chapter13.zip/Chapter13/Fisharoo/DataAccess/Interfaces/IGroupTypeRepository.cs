using System;
using System.Collections.Generic;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Interfaces
{
    //CHAPTER 10
    public interface IGroupTypeRepository
    {
        GroupType GetGroupTypeByID(Int32 GroupTypeID);
        List<GroupType> GetGroupTypesByGroupID(Int32 GroupID);
        Int64 SaveGroupType(GroupType groupType);
        void DeleteGroupType(GroupType groupType);
        List<GroupType> GetAllGroupTypes();        
    }
}