using System;
using System.Collections.Generic;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Interfaces
{
    //CHAPTER 9
    public interface IBoardForumRepository
    {
        BoardForum GetForumByID(Int32 ForumID);
        BoardForum GetForumByPageName(string PageName);
        BoardForum GetForumByName(string Name);
        List<BoardForum> GetForumsByCategoryID(Int32 CategoryID);
        Int32 SaveForum(BoardForum boardForum);
        void DeleteForum(BoardForum boardForum);
        List<BoardForum> GetAllForums();
        //CHAPTER 10
        BoardForum GetForumByGroupID(Int32 GroupID);
    }
}