using System.Collections.Generic;
using Fisharoo.DataAccess.Repositories;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Interfaces
{
    //CHAPTER 12
    public interface IModerationRepository
    {
        List<Moderation> GetModerationsByAccountID(int AccountID);
        List<Moderation> GetModerationsGlobal();
        Moderation SaveModeration(Moderation moderation);
        void DeleteModeration(Moderation moderation);
        bool HasFlaggedThisAlready(int AccountID, int SystemObjectID, long SystemObjectRecordID);
        void SaveModerationResults(List<ModerationResult> results, int ActionByAccountID, string ActionByUsername);
    }
}