using System.Collections.Generic;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Interfaces
{
    //CHAPTER 11
    public interface IRatingRepository
    {
        void SaveRatings(List<Rating> ratings);
        long SaveRating(Rating rating);
        void DeleteRating(Rating rating);
        int GetCurrentRating(int SystemObjectID, long SystemObjectRecordID);
        bool HasRatedBefore(int SystemObjectID, long SystemObjectRecordID, int AccountID);
    }
}