using System;
using System.Collections.Generic;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Interfaces
{
    public interface IAlertRepository
    {
        List<Alert> GetAlertsByAccountID(Int32 AccountID);
        void SaveAlert(Alert alert);
        void DeleteAlert(Alert alert);
        //CHAPTER 13
        void DeleteAlerts(List<int> alertIDs);

    }
}