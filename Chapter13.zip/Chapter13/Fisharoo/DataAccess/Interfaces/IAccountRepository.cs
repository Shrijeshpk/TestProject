using System;
using System.Collections.Generic;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Interfaces
{
    public interface IAccountRepository
    {
        Account GetAccountByID(int AccountID);
        void SaveAccount(Account account);
        Account GetAccountByEmail(string Email);
        Account GetAccountByUsername(string Username);
        void AddPermission(Account account, Permission permission);
        List<Account> GetAllAccounts(Int32 PageNumber);
        //CHAPTER 5
        List<Account> SearchAccounts(string SearchText);
        //CHAPTER 10
        List<Account> GetApprovedAccountsByGroupID(int GroupID, int PageNumber, int NumberOfRecordsInPage);
        List<Account> GetAccountsToApproveByGroupID(int GroupID);

    }
}