using System.Collections.Generic;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess.Interfaces
{
    //CHAPTER 11
    public interface ISystemObjectRatingOptionsRepository
    {
        List<SystemObjectRatingOption> GetSystemObjectRatingOptionsBySystemObjectID(int SystemObjectID);
        int SaveSystemObjectRatingOption(SystemObjectRatingOption systemObjectRatingOption);
        void DeleteSystemObjectRatingOption(SystemObjectRatingOption systemObjectRatingOption);
    }
}