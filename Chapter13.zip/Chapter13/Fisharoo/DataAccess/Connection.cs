﻿using System.Configuration;
using Fisharoo.Entities;

namespace Fisharoo.DataAccess
{
    public class Connection
    {
        public FisharooDataContext GetContext()
        {
            FisharooDataContext fdc = new FisharooDataContext(ConfigurationManager.ConnectionStrings["FisharooDataContext"].ToString());
            return fdc;
        }
    }
}
